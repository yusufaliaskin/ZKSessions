import datetime
from django.test import TestCase
from django.utils import timezone
from apps.sessions.models import Session
from apps.audit.adapters.base import AuditEvent, AuditEventType
from apps.monitoring.services.session_monitor import SessionMonitorEngine


class SessionStateMachineTest(TestCase):
    def setUp(self):
        self.engine = SessionMonitorEngine(limit_hours=12)

    def test_scenario_1_logout_under_12h_purges_session(self):
        """Senaryo 1: 12 saatten az süren session logout olduğunda DB'den silinir, SMTP atılmaz."""
        login_time = timezone.now() - datetime.timedelta(hours=5)
        logout_time = timezone.now()

        login_event = AuditEvent(
            event_id="evt_login_1",
            event_type=AuditEventType.LOGIN,
            username="user01",
            sicil="12345",
            computer_name="PC001",
            event_time=login_time,
            session_id="sess_001"
        )
        self.engine._process_single_event(login_event)
        self.assertEqual(Session.objects.filter(session_id="sess_001").count(), 1)

        logout_event = AuditEvent(
            event_id="evt_logout_1",
            event_type=AuditEventType.LOGOUT,
            username="user01",
            sicil="12345",
            computer_name="PC001",
            event_time=logout_time,
            session_id="sess_001"
        )
        self.engine._process_single_event(logout_event)

        # Session should be completely deleted from DB
        self.assertEqual(Session.objects.filter(session_id="sess_001").count(), 0)

    def test_scenario_2_and_3_over_12h_marks_overdue_and_reports_once(self):
        """Senaryo 2 & 3: 12 saati aşan aktif session overdue=True işaretlenir, tekrar mail atılmaz."""
        login_time = timezone.now() - datetime.timedelta(hours=13)

        login_event = AuditEvent(
            event_id="evt_login_2",
            event_type=AuditEventType.LOGIN,
            username="user02",
            sicil="67890",
            computer_name="PC002",
            event_time=login_time,
            session_id="sess_002"
        )
        self.engine._process_single_event(login_event)

        # Run cycle check
        over_limit_count, sent, failed = self.engine._process_over_limit_sessions()
        self.assertEqual(over_limit_count, 1)

        session = Session.objects.get(session_id="sess_002")
        self.assertTrue(session.overdue)

    def test_scenario_4_logout_after_12h_preserves_session_no_second_mail(self):
        """Senaryo 4: 12 saati geçmiş kullanıcı logout olduğunda DB'de LOGGED_OUT olarak saklanır, 2. mail atılmaz."""
        login_time = timezone.now() - datetime.timedelta(hours=14)
        logout_time = timezone.now()

        login_event = AuditEvent(
            event_id="evt_login_3",
            event_type=AuditEventType.LOGIN,
            username="user03",
            sicil="11111",
            computer_name="PC003",
            event_time=login_time,
            session_id="sess_003"
        )
        self.engine._process_single_event(login_event)

        session = Session.objects.get(session_id="sess_003")
        session.report_send = True
        session.overdue = True
        session.save()

        logout_event = AuditEvent(
            event_id="evt_logout_3",
            event_type=AuditEventType.LOGOUT,
            username="user03",
            sicil="11111",
            computer_name="PC003",
            event_time=logout_time,
            session_id="sess_003"
        )
        self.engine._process_single_event(logout_event)

        # Session should still exist in DB as LOGGED_OUT
        session = Session.objects.get(session_id="sess_003")
        self.assertEqual(session.status, Session.STATUS_LOGGED_OUT)
        self.assertIsNotNone(session.logout_time)
        self.assertTrue(session.overdue)
        self.assertTrue(session.report_send)

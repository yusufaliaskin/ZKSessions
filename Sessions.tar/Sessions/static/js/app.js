// Ziraat Katılım — Session Monitor Premium v2.0
// Theme Toggle + 60s Live Polling + Glassmorphism SOC Engine

document.addEventListener("DOMContentLoaded", function () {
  var topbarToggleBtn = document.getElementById("sidebarToggleBtn");
  var themeToggleBtn = document.getElementById("themeToggleBtn");
  var globalPortal = document.getElementById("globalMiniFlyoutPortal");
  var searchInput = document.getElementById("topbarGlobalSearch");
  var searchDropdown = document.getElementById("globalSearchDropdown");

  // =========================================================================
  // 1. Sidebar State from LocalStorage
  // =========================================================================
  try {
    var savedState = localStorage.getItem("zk_sidebar_collapsed");
    if (savedState === "true") {
      document.body.classList.add("sidebar-collapsed");
      document.documentElement.classList.add("sidebar-collapsed");
    } else if (savedState === "false") {
      document.body.classList.remove("sidebar-collapsed");
      document.documentElement.classList.remove("sidebar-collapsed");
    }
  } catch (e) {}

  // =========================================================================
  // 2. Sidebar Collapse/Expand Toggle
  // =========================================================================
  function toggleSidebarRail() {
    var isCollapsed = document.body.classList.toggle("sidebar-collapsed");
    document.documentElement.classList.toggle("sidebar-collapsed", isCollapsed);
    if (globalPortal) hideGlobalPortal();
    try {
      localStorage.setItem("zk_sidebar_collapsed", isCollapsed ? "true" : "false");
    } catch (e) {}
  }

  var sidebarCollapseChevron = document.getElementById("sidebarCollapseChevron");
  var menuFilterInput = document.getElementById("sidebarMenuFilter");

  if (topbarToggleBtn) topbarToggleBtn.addEventListener("click", toggleSidebarRail);
  if (sidebarCollapseChevron) sidebarCollapseChevron.addEventListener("click", toggleSidebarRail);

  // In-menu filter search
  if (menuFilterInput) {
    menuFilterInput.addEventListener("input", function (e) {
      var q = e.target.value.toLowerCase().trim();
      var singleItems = document.querySelectorAll(".tree-single-wrap");
      var groups = document.querySelectorAll(".tree-group");

      if (!q) {
        singleItems.forEach(function (el) { el.style.display = ""; });
        groups.forEach(function (el) {
          el.style.display = "";
          el.querySelectorAll(".tree-sub-item").forEach(function (sub) { sub.style.display = ""; });
        });
        return;
      }

      singleItems.forEach(function (el) {
        var text = el.textContent.toLowerCase();
        el.style.display = text.includes(q) ? "" : "none";
      });

      groups.forEach(function (group) {
        var subItems = group.querySelectorAll(".tree-sub-item");
        var groupHeader = group.querySelector(".tree-group-header");
        var headerText = groupHeader ? groupHeader.textContent.toLowerCase() : "";
        var matchCount = 0;

        subItems.forEach(function (sub) {
          var subText = sub.textContent.toLowerCase();
          if (subText.includes(q) || headerText.includes(q)) {
            sub.style.display = "";
            matchCount++;
          } else {
            sub.style.display = "none";
          }
        });

        if (matchCount > 0 || headerText.includes(q)) {
          group.style.display = "";
          group.classList.add("open");
        } else {
          group.style.display = "none";
        }
      });
    });
  }

  // =========================================================================
  // 3. User Dropdown Menu & Theme Toggle
  // =========================================================================
  var userDropdownTrigger = document.getElementById("userDropdownTrigger");
  var userDropdownMenu = document.getElementById("userDropdownMenu");
  var dropdownThemeToggle = document.getElementById("dropdownThemeToggle");

  if (userDropdownTrigger && userDropdownMenu) {
    userDropdownTrigger.addEventListener("click", function (e) {
      e.stopPropagation();
      var isOpen = userDropdownMenu.classList.toggle("show");
      userDropdownTrigger.classList.toggle("active", isOpen);
    });

    document.addEventListener("click", function (e) {
      if (!userDropdownMenu.contains(e.target) && !userDropdownTrigger.contains(e.target)) {
        userDropdownMenu.classList.remove("show");
        userDropdownTrigger.classList.remove("active");
      }
    });
  }

  function getCurrentTheme() {
    return document.documentElement.getAttribute("data-theme") || "dark";
  }

  var transitionTimeout = null;

  function setTheme(theme, animate) {
    if (animate) {
      if (transitionTimeout) clearTimeout(transitionTimeout);
      document.documentElement.classList.add("theme-transitioning");
    }

    document.documentElement.setAttribute("data-theme", theme);
    try { localStorage.setItem("zk_theme", theme); } catch (e) {}

    // Update dropdown theme icon & label
    var themeIconSlot = document.getElementById("themeIconSlot");
    var themeLabelText = document.getElementById("themeLabelText");
    var miniThemeSwitch = document.getElementById("miniThemeSwitch");

    if (miniThemeSwitch) {
      miniThemeSwitch.classList.toggle("active", theme === "light");
    }

    if (themeIconSlot) {
      if (theme === "dark") {
        themeIconSlot.innerHTML = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>';
        if (themeLabelText) themeLabelText.textContent = "Koyu Tema";
      } else {
        themeIconSlot.innerHTML = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line></svg>';
        if (themeLabelText) themeLabelText.textContent = "Açık Tema";
      }
    }

    // Dispatch custom event for chart re-rendering
    window.dispatchEvent(new Event("themeChanged"));

    if (animate) {
      transitionTimeout = setTimeout(function () {
        document.documentElement.classList.remove("theme-transitioning");
      }, 400);
    }
  }

  if (dropdownThemeToggle) {
    dropdownThemeToggle.addEventListener("click", function (e) {
      e.stopPropagation();
      var current = getCurrentTheme();
      setTheme(current === "dark" ? "light" : "dark", true);
    });
  }

  // Initialize theme on load without triggering transition effect
  setTheme(getCurrentTheme(), false);

  // =========================================================================
  // 4. Global Floating Popover (Collapsed Sidebar)
  // =========================================================================
  var portalHideTimeout = null;

  function showGlobalPortal(triggerEl) {
    if (!document.body.classList.contains("sidebar-collapsed") || !globalPortal) return;
    if (portalHideTimeout) {
      clearTimeout(portalHideTimeout);
      portalHideTimeout = null;
    }

    var rect = triggerEl.getBoundingClientRect();
    var html = "";

    if (triggerEl.hasAttribute("data-portal-title")) {
      var title = triggerEl.getAttribute("data-portal-title");
      var url = triggerEl.getAttribute("data-portal-url");
      var isActive = triggerEl.getAttribute("data-portal-active") === "true";
      html = '<a href="' + url + '" class="global-flyout-item ' + (isActive ? "active" : "") + '">' + title + '</a>';
    } else if (triggerEl.hasAttribute("data-portal-group")) {
      var groupTitle = triggerEl.getAttribute("data-portal-group");
      var subItems = triggerEl.querySelectorAll(".tree-sub-item");
      html = '<div class="global-flyout-title">' + groupTitle + '</div>';
      subItems.forEach(function (sub) {
        var subHref = sub.getAttribute("href");
        var subText = sub.textContent.trim();
        var subActive = sub.classList.contains("active") ? "active" : "";
        html += '<a href="' + subHref + '" class="global-flyout-item ' + subActive + '">' + subText + '</a>';
      });
    }

    if (!html) return;

    globalPortal.innerHTML = html;
    globalPortal.style.left = (rect.right + 14) + "px";
    globalPortal.style.top = rect.top + "px";
    globalPortal.classList.add("visible");
  }

  function scheduleHideGlobalPortal() {
    if (portalHideTimeout) clearTimeout(portalHideTimeout);
    portalHideTimeout = setTimeout(function () {
      hideGlobalPortal();
    }, 140);
  }

  function hideGlobalPortal() {
    if (globalPortal) {
      globalPortal.classList.remove("visible");
      globalPortal.innerHTML = "";
    }
  }

  if (globalPortal) {
    globalPortal.addEventListener("mouseenter", function () {
      if (portalHideTimeout) clearTimeout(portalHideTimeout);
    });
    globalPortal.addEventListener("mouseleave", scheduleHideGlobalPortal);
  }

  var portalTriggers = document.querySelectorAll("[data-portal-title], [data-portal-group]");
  portalTriggers.forEach(function (el) {
    el.addEventListener("mouseenter", function () { showGlobalPortal(el); });
    el.addEventListener("mouseleave", scheduleHideGlobalPortal);
  });

  // =========================================================================
  // 5. Tree Accordion
  // =========================================================================
  document.addEventListener("click", function (e) {
    if (document.body.classList.contains("sidebar-collapsed")) return;

    var header = e.target.closest(".tree-group-header");
    if (!header) return;

    var group = header.closest(".tree-group");
    if (!group) return;

    var isOpen = group.classList.contains("open");

    document.querySelectorAll(".tree-group").forEach(function (g) {
      if (g !== group) g.classList.remove("open");
    });

    if (isOpen) {
      group.classList.remove("open");
    } else {
      group.classList.add("open");
    }
  });

  // =========================================================================
  // 6. Universal Table Sorter
  // =========================================================================
  initUniversalTableSorter();

  // =========================================================================
  // 7. Live Search Autocomplete
  // =========================================================================
  var searchDebounceTimer = null;

  if (searchInput && searchDropdown) {
    searchInput.addEventListener("input", function (e) {
      var query = e.target.value.trim();

      if (searchDebounceTimer) clearTimeout(searchDebounceTimer);

      if (query.length < 1) {
        searchDropdown.style.display = "none";
        searchDropdown.innerHTML = "";
        return;
      }

      searchDebounceTimer = setTimeout(function () {
        fetch("/api/quick-search/?q=" + encodeURIComponent(query))
          .then(function (res) { return res.json(); })
          .then(function (data) {
            var sessions = data.sessions || [];
            var auditEvents = data.audit_events || [];

            if (sessions.length === 0 && auditEvents.length === 0) {
              searchDropdown.innerHTML = '<div class="search-empty-note">"' + query + '" ile eşleşen sonuç bulunamadı.</div>';
              searchDropdown.style.display = "block";
              return;
            }

            var html = '';

            if (sessions.length > 0) {
              html += '<div class="search-section-label">Aktif &amp; Son Oturumlar (' + sessions.length + ')</div>';
              sessions.forEach(function (s) {
                var badgeCls = s.status_code === 'LOGGED_OUT' ? 'gray' : (s.status_code === 'ACTIVE' ? 'blue' : 'red');
                html += '<div class="search-item-row" onclick="openSessionDrawer(' + s.id + '); document.getElementById(\'globalSearchDropdown\').style.display=\'none\';">' +
                  '<div class="search-avatar-box">' + s.user_name.charAt(0).toUpperCase() + '</div>' +
                  '<div class="search-item-main">' +
                    '<div class="search-user-title"><b>' + s.user_name + '</b> <span class="search-user-sicil">Sicil: ' + s.sicil + '</span></div>' +
                    '<div class="search-device-line"><span class="agent-link">' + s.computer_name + '</span> &bull; Giriş: ' + s.login_time + ' &bull; Süre: <b>' + s.duration + '</b></div>' +
                  '</div>' +
                  '<div class="search-item-end">' +
                    '<span class="badge ' + badgeCls + '">' + s.status + '</span>' +
                    '<span class="search-arrow-icon">&#x203A;</span>' +
                  '</div>' +
                '</div>';
              });
            }

            if (auditEvents.length > 0) {
              html += '<div class="search-section-label" style="margin-top:6px;">Audit Güvenlik Günlükleri (' + auditEvents.length + ')</div>';
              auditEvents.forEach(function (a) {
                var isLogin = a.event_type === 'LOGIN';
                html += '<a href="' + a.detail_url + '" class="search-item-row audit-row" onclick="document.getElementById(\'globalSearchDropdown\').style.display=\'none\';">' +
                  '<div class="search-avatar-box audit ' + (isLogin ? 'login' : 'logout') + '">' + (isLogin ? 'IN' : 'OUT') + '</div>' +
                  '<div class="search-item-main">' +
                    '<div class="search-user-title"><b>' + a.user_name + '</b> <span class="search-user-sicil">ID: ' + a.event_id.substring(0, 14) + '...</span></div>' +
                    '<div class="search-device-line"><span class="agent-link">' + a.computer_name + '</span> &bull; Zaman: ' + a.event_time + '</div>' +
                  '</div>' +
                  '<div class="search-item-end">' +
                    '<span class="badge ' + (isLogin ? 'blue' : 'gray') + '">' + a.event_type + '</span>' +
                    '<span class="search-arrow-icon">&#x203A;</span>' +
                  '</div>' +
                '</a>';
              });
            }

            html += '<a href="/sessions/active/?q=' + encodeURIComponent(query) + '" class="search-dropdown-footer">Tüm Arama Sonuçlarını İncele &rarr;</a>';
            searchDropdown.innerHTML = html;
            searchDropdown.style.display = "block";
          })
          .catch(function () {
            searchDropdown.style.display = "none";
          });
      }, 150);
    });

    document.addEventListener("click", function (e) {
      if (!e.target.closest(".topbar-center-zone")) {
        searchDropdown.style.display = "none";
      }
    });
  }

  // =========================================================================
  // 8. Drawer + Escape Key
  // =========================================================================
  var overlay = document.getElementById("drawer-overlay");
  if (overlay) {
    overlay.addEventListener("click", closeDrawer);
  }
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") {
      closeDrawer();
      if (searchDropdown) searchDropdown.style.display = "none";
    }
  });

  // =========================================================================
  // 9. Initial Donut Render from Real Database State
  // =========================================================================
  var statsEl = document.getElementById("dashboardStatsData");
  if (statsEl) {
    var initActive = statsEl.getAttribute("data-active") || 0;
    var initOver = statsEl.getAttribute("data-overlimit") || 0;
    var initLogged = statsEl.getAttribute("data-loggedout") || 0;
    renderRealDonutChart(initActive, initOver, initLogged);
  }

  // =========================================================================
  // 10. Live Polling — Every 60 seconds (audit real-time)
  // =========================================================================
  setInterval(pollLiveStats, 60000);
});

// ============================================================================
// Universal Table Sorter Engine
// ============================================================================
function initUniversalTableSorter() {
  var tables = document.querySelectorAll(".data-table, .wazuh-siem-table");
  tables.forEach(function (table) {
    var headers = table.querySelectorAll("thead th");
    headers.forEach(function (th, colIndex) {
      var text = th.textContent.trim();
      if (!text || th.classList.contains("no-sort") || th.classList.contains("chevron-col")) return;

      th.classList.add("sortable-th");

      if (!th.querySelector(".sort-indicator-icon")) {
        var span = document.createElement("span");
        span.className = "sort-indicator-icon";
        span.innerHTML = "&#8645;";
        th.appendChild(span);
      }

      th.addEventListener("click", function (e) {
        if (e.target.tagName === "A" || e.target.tagName === "BUTTON") return;

        var tbody = table.querySelector("tbody");
        if (!tbody) return;

        var rows = Array.from(tbody.querySelectorAll("tr"));
        if (rows.length <= 1) return;

        var currentDir = th.getAttribute("data-sort-dir") || "none";
        var newDir = currentDir === "asc" ? "desc" : "asc";

        headers.forEach(function (otherTh) {
          otherTh.removeAttribute("data-sort-dir");
          otherTh.classList.remove("sort-asc", "sort-desc");
          var icon = otherTh.querySelector(".sort-indicator-icon");
          if (icon) icon.innerHTML = "&#8645;";
        });

        th.setAttribute("data-sort-dir", newDir);
        th.classList.add(newDir === "asc" ? "sort-asc" : "sort-desc");
        var icon = th.querySelector(".sort-indicator-icon");
        if (icon) icon.innerHTML = newDir === "asc" ? "&#9650;" : "&#9660;";

        rows.sort(function (rowA, rowB) {
          var cellA = rowA.children[colIndex];
          var cellB = rowB.children[colIndex];
          if (!cellA || !cellB) return 0;

          var valA = cellA.textContent.trim();
          var valB = cellB.textContent.trim();

          var dateA = parseDateTimeString(valA);
          var dateB = parseDateTimeString(valB);
          if (dateA !== null && dateB !== null) {
            return newDir === "asc" ? dateA - dateB : dateB - dateA;
          }

          var numA = parseNumberString(valA);
          var numB = parseNumberString(valB);
          if (numA !== null && numB !== null) {
            return newDir === "asc" ? numA - numB : numB - numA;
          }

          var cmp = valA.localeCompare(valB, "tr", { numeric: true, sensitivity: "base" });
          return newDir === "asc" ? cmp : -cmp;
        });

        rows.forEach(function (row) {
          tbody.appendChild(row);
        });
      });
    });
  });
}

function parseDateTimeString(str) {
  var match = str.match(/^(\d{1,2})\.(\d{1,2})\.(\d{4})(?:\s+(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?$/);
  if (match) {
    var d = parseInt(match[1], 10);
    var m = parseInt(match[2], 10) - 1;
    var y = parseInt(match[3], 10);
    var hh = match[4] ? parseInt(match[4], 10) : 0;
    var mm = match[5] ? parseInt(match[5], 10) : 0;
    var ss = match[6] ? parseInt(match[6], 10) : 0;
    return new Date(y, m, d, hh, mm, ss).getTime();
  }
  return null;
}

function parseNumberString(str) {
  var clean = str.replace(/,/g, "").replace(/[^\d.-]/g, "");
  if (!clean || isNaN(clean)) return null;
  return parseFloat(clean);
}

// ============================================================================
// Live Telemetry
// ============================================================================
function triggerLiveRefresh() {
  var spinIcon = document.getElementById("refreshSpinIcon");
  if (spinIcon) {
    spinIcon.classList.add("refresh-spinning");
    setTimeout(function () {
      spinIcon.classList.remove("refresh-spinning");
    }, 600);
  }
  pollLiveStats(true);
}

function pollLiveStats(isManual) {
  var timeRangeSelect = document.getElementById("dashboardTimeRange");
  var timeRange = timeRangeSelect ? timeRangeSelect.value : "24h";

  fetch("/api/live-stats/?time_range=" + encodeURIComponent(timeRange), {
    headers: { "X-Requested-With": "XMLHttpRequest" }
  })
    .then(function (r) { return r.ok ? r.json() : null; })
    .then(function (data) {
      if (!data) return;

      var kpiActive = document.getElementById("kpiActive");
      var kpiOver = document.getElementById("kpiOverLimit");
      var kpiSent = document.getElementById("kpiSent");
      var kpiTotal = document.getElementById("kpiTotal");

      if (kpiActive && data.active_sessions !== undefined) animateValue(kpiActive, data.active_sessions);
      if (kpiOver && data.over_limit !== undefined) animateValue(kpiOver, data.over_limit);
      if (kpiSent && data.reports_sent !== undefined) animateValue(kpiSent, data.reports_sent);
      if (kpiTotal && data.total_sessions !== undefined) animateValue(kpiTotal, data.total_sessions);

      // Update Donut Graph & Legend
      renderRealDonutChart(data.active_sessions, data.over_limit, data.logged_out_count);
    })
    .catch(function () {});
}

// Exact Mathematical SVG Donut Arc Renderer
function renderRealDonutChart(active, overlimit, loggedout) {
  var activeRing = document.getElementById("donutActiveRing");
  var overlimitRing = document.getElementById("donutOverlimitRing");
  var closedRing = document.getElementById("donutClosedRing");
  var donutCenter = document.getElementById("donutCenterCount");
  var legActive = document.getElementById("legendActiveCount");
  var legOver = document.getElementById("legendOverlimitCount");
  var legLogged = document.getElementById("legendLoggedoutCount");

  var activeVal = parseInt(active, 10) || 0;
  var overVal = parseInt(overlimit, 10) || 0;
  var loggedVal = parseInt(loggedout, 10) || 0;

  var safeActive = Math.max(0, activeVal - overVal);
  var total = safeActive + overVal + loggedVal;

  if (donutCenter) donutCenter.textContent = activeVal;
  if (legActive) legActive.textContent = "(" + activeVal + ")";
  if (legOver) legOver.textContent = "(" + overVal + ")";
  if (legLogged) legLogged.textContent = "(" + loggedVal + ")";

  var C = 289.026; // Circumference = 2 * PI * 46

  if (total === 0) {
    // Zero records: Reset all arcs to 0 so no fake colored slices appear
    if (activeRing) {
      activeRing.setAttribute("stroke-dasharray", "0 " + C);
      activeRing.setAttribute("stroke-dashoffset", "0");
    }
    if (overlimitRing) {
      overlimitRing.setAttribute("stroke-dasharray", "0 " + C);
      overlimitRing.setAttribute("stroke-dashoffset", "0");
    }
    if (closedRing) {
      closedRing.setAttribute("stroke-dasharray", "0 " + C);
      closedRing.setAttribute("stroke-dashoffset", "0");
    }
    return;
  }

  var L1 = (safeActive / total) * C;
  var L2 = (overVal / total) * C;
  var L3 = (loggedVal / total) * C;

  if (activeRing) {
    activeRing.setAttribute("stroke-dasharray", L1.toFixed(2) + " " + (C - L1).toFixed(2));
    activeRing.setAttribute("stroke-dashoffset", "0");
  }
  if (overlimitRing) {
    overlimitRing.setAttribute("stroke-dasharray", L2.toFixed(2) + " " + (C - L2).toFixed(2));
    overlimitRing.setAttribute("stroke-dashoffset", (-L1).toFixed(2));
  }
  if (closedRing) {
    closedRing.setAttribute("stroke-dasharray", L3.toFixed(2) + " " + (C - L3).toFixed(2));
    closedRing.setAttribute("stroke-dashoffset", (-(L1 + L2)).toFixed(2));
  }
}

// Dynamic Dashboard Time Filter Handler (Real Backend Audit Querying)
function onDashboardTimeFilterChange(timeRange) {
  var activityContainer = document.getElementById("activityBarsRow");
  var select1 = document.getElementById("dashboardTimeRange");
  var select2 = document.getElementById("donutTimeRangeSelect");

  // Sync both dropdowns
  if (select1 && select1.value !== timeRange) select1.value = timeRange;
  if (select2 && select2.value !== timeRange) select2.value = timeRange;

  if (activityContainer) {
    activityContainer.style.opacity = "0.4";
  }

  fetch("/api/live-stats/?time_range=" + encodeURIComponent(timeRange), {
    headers: { "X-Requested-With": "XMLHttpRequest" }
  })
    .then(function (r) { return r.json(); })
    .then(function (data) {
      if (activityContainer) {
        activityContainer.style.opacity = "1";
        
        var counts = data.hourly_counts || [];
        var labels = data.hours_labels || [];
        var maxCount = Math.max.apply(null, counts.concat([10]));

        var html = "";
        if (counts.length === 0) {
          html = '<div class="clean-list-empty" style="width:100%;"><span>Seçilen zaman aralığında aktivite kaydı bulunamadı.</span></div>';
        } else {
          for (var i = 0; i < counts.length; i++) {
            var c = counts[i];
            var lbl = labels[i] || "";
            var heightPct = c > 0 ? Math.max(8, Math.round((c / maxCount) * 100)) : 6;
            var fillClass = c > 5 ? "active-high" : (c > 0 ? "active-mid" : "");

            html += '<div class="activity-bar-col">' +
                      '<div class="activity-bar-track">' +
                        '<div class="activity-bar-fill ' + fillClass + '" style="height:' + heightPct + '%;" title="' + c + ' Oturum / Audit Olayı"></div>' +
                      '</div>' +
                      '<span class="activity-bar-month">' + lbl + '</span>' +
                    '</div>';
          }
        }
        activityContainer.innerHTML = html;
      }

      // Update KPI numbers & Real Donut
      renderRealDonutChart(data.active_sessions, data.over_limit, data.logged_out_count);
    })
    .catch(function (err) {
      if (activityContainer) activityContainer.style.opacity = "1";
    });
}

// Smooth number animation for KPI values
function animateValue(el, newVal) {
  var currentVal = parseInt(el.textContent, 10) || 0;
  if (currentVal === newVal) return;
  el.textContent = newVal;
  el.style.transition = "transform 0.25s ease, opacity 0.25s ease";
  el.style.transform = "scale(1.08)";
  el.style.opacity = "0.7";
  setTimeout(function() {
    el.style.transform = "scale(1)";
    el.style.opacity = "1";
  }, 250);
}

// ============================================================================
// Expandable Table Accordion for /sessions/active/
// ============================================================================
function toggleSessionAccordion(sessionId) {
  var accordionRow = document.getElementById("accordion-" + sessionId);
  var chevron = document.getElementById("chevron-" + sessionId);
  if (!accordionRow) return;

  var isHidden = accordionRow.style.display === "none" || !accordionRow.style.display;
  if (isHidden) {
    accordionRow.style.display = "table-row";
    if (chevron) chevron.style.transform = "rotate(90deg)";
  } else {
    accordionRow.style.display = "none";
    if (chevron) chevron.style.transform = "rotate(0deg)";
  }
}

// ============================================================================
// Telemetry Modal Tabs Switcher
// ============================================================================
function switchTelemetryTab(btn, tabId) {
  var container = btn.closest(".telemetry-detail-container");
  if (!container) return;

  var allBtns = container.querySelectorAll(".telemetry-tab-btn");
  var allPanes = container.querySelectorAll(".telemetry-tab-pane");

  allBtns.forEach(function (b) { b.classList.remove("active"); });
  allPanes.forEach(function (p) { p.classList.remove("active"); });

  btn.classList.add("active");
  var target = document.getElementById(tabId);
  if (target) target.classList.add("active");
}

// ============================================================================
// Centered Telemetry Modal Functions
// ============================================================================
function openSessionDrawer(sessionId) {
  openDrawer("/sessions/" + sessionId + "/");
}

function openDrawer(url) {
  var drawer = document.getElementById("drawer");
  var overlay = document.getElementById("drawer-overlay");
  var body = document.getElementById("drawer-body-content");
  if (!drawer || !body) return;

  body.innerHTML = '<div class="empty-state" style="padding:40px 20px;">Oturum güvenlik telemetrisi yükleniyor...</div>';
  overlay.classList.add("open");
  drawer.classList.add("open");

  fetch(url, { headers: { "X-Requested-With": "XMLHttpRequest" } })
    .then(function (r) { return r.text(); })
    .then(function (html) { body.innerHTML = html; })
    .catch(function () {
      body.innerHTML = '<div class="empty-state">Oturum detayları yüklenemedi.</div>';
    });
}

function closeDrawer() {
  var drawer = document.getElementById("drawer");
  var overlay = document.getElementById("drawer-overlay");
  if (drawer) drawer.classList.remove("open");
  if (overlay) overlay.classList.remove("open");
}

// Close modal on Escape key or backdrop click
document.addEventListener("keydown", function (e) {
  if (e.key === "Escape") closeDrawer();
});

var drawerOverlay = document.getElementById("drawer-overlay");
if (drawerOverlay) {
  drawerOverlay.addEventListener("click", closeDrawer);
}

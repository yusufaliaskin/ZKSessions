from django.core.management.base import BaseCommand
from apps.sessions.models import Session, SessionTimelineEvent
from apps.audit.models import AuditEventRecord, AuditCheckpoint
from apps.reporting.models import ReportHistory
from apps.monitoring.models import MonitoringCycleRun


class Command(BaseCommand):
    help = "Purge all mock/test sessions and audit records to start 100% clean with real audit server data."

    def handle(self, *args, **options):
        timeline_count = SessionTimelineEvent.objects.count()
        SessionTimelineEvent.objects.all().delete()

        report_count = ReportHistory.objects.count()
        ReportHistory.objects.all().delete()

        session_count = Session.objects.count()
        Session.objects.all().delete()

        audit_count = AuditEventRecord.objects.count()
        AuditEventRecord.objects.all().delete()

        checkpoint_count = AuditCheckpoint.objects.count()
        AuditCheckpoint.objects.all().delete()

        cycle_count = MonitoringCycleRun.objects.count()
        MonitoringCycleRun.objects.all().delete()

        self.stdout.write(
            self.style.SUCCESS(
                f"Successfully purged all test data:\n"
                f" - {session_count} Sessions removed\n"
                f" - {audit_count} Audit Event Records removed\n"
                f" - {report_count} Report Histories removed\n"
                f" - {timeline_count} Timeline Events removed\n"
                f" - {cycle_count} Monitoring Cycle Runs removed\n"
                f"System is now 100% clean and ready for real Audit Server ingestion."
            )
        )

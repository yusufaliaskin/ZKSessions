"""
SessionMonitorEngine — the ONE place all core business logic from the
specification lives (sections 2-15, 20-31, 70-74, 78-80, 98-99).

This is intentionally decoupled from Django views/HTTP: it must keep
running via Celery beat (or the management-command scheduler) whether or
not anyone has the dashboard open (RULE 13/14).

High level cycle (section 23):
  1. Check audit connection
  2. Read audit events (paginated, checkpointed)
  3. Process LOGIN events -> create sessions (idempotent)
  4. Process LOGOUT events -> complete sessions (retrying report if needed)
  5-7. Find active sessions over the configured hour limit needing a report
  8-9. Send SMTP reports, update report state
  10. (handled inline with step 4) complete logged-out sessions
  11. Update system stats / checkpoint
  12. Structured logging throughout
"""
from __future__ import annotations

import hashlib
import logging

from django.conf import settings
from django.db import transaction
from django.utils import timezone

from apps.audit.adapters.base import AuditEvent, AuditEventType
from apps.audit.adapters.factory import get_audit_reader
from apps.audit.models import AuditCheckpoint, AuditEventRecord
from apps.monitoring.models import MonitoringCycleRun
from apps.reporting.services.email_service import EmailReportService
from apps.sessions.models import Session, SessionTimelineEvent

logger = logging.getLogger("session_monitor")

CHECKPOINT_SOURCE = "default"


def _derive_session_id(username: str, computer: str, login_time) -> str:
    """Fallback deterministic session identity when the audit source does
    not provide its own session_id (section 13 dedup priority #3)."""
    raw = f"{username}|{computer}|{login_time.isoformat()}"
    return hashlib.sha1(raw.encode()).hexdigest()[:32]


class SessionMonitorEngine:
    def __init__(self, limit_hours: int | None = None):
        self.limit_hours = limit_hours or self._resolve_limit_hours()
        self.reader = get_audit_reader()
        self.report_service = EmailReportService(limit_hours=self.limit_hours)

    @staticmethod
    def _resolve_limit_hours() -> int:
        """Section 24/58 — the hour limit can be overridden from the
        Settings panel; fall back to the environment default otherwise."""
        try:
            from apps.settings_panel.models import SystemSettings

            return SystemSettings.load().session_limit_hours
        except Exception:  # noqa: BLE001 — settings table may not exist yet
            return settings.SESSION_LIMIT_HOURS

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------
    def run_cycle(self, triggered_by: str = "scheduler") -> MonitoringCycleRun:
        run = MonitoringCycleRun.objects.create(started_at=timezone.now(), triggered_by=triggered_by)
        logger.info("SCAN_STARTED triggered_by=%s", triggered_by)

        try:
            audit_connected = self._check_audit_connection()
            run.audit_connected = audit_connected

            if audit_connected:
                fetched, logins, logouts = self._read_and_process_audit_events()
                run.events_fetched = fetched
                run.logins_detected = logins
                run.logouts_detected = logouts
            else:
                logger.warning("AUDIT_DISCONNECTED — existing sessions are preserved")

            # Independent of audit connectivity: 12h detection & reporting
            # operate purely on our own database (RULE 10/30).
            over_limit_count, sent, failed = self._process_over_limit_sessions()
            run.over_limit_found = over_limit_count
            run.reports_sent = sent
            run.reports_failed = failed

            run.status = MonitoringCycleRun.SUCCESS
        except Exception as exc:  # noqa: BLE001 — a cycle failure must not crash the worker
            logger.exception("SCAN_FAILED error=%s", exc)
            run.status = MonitoringCycleRun.FAILED
            run.error_detail = str(exc)
        finally:
            run.finished_at = timezone.now()
            run.save()
            logger.info(
                "SCAN_COMPLETED status=%s logins=%s logouts=%s over_limit=%s sent=%s failed=%s duration=%.2fs",
                run.status, run.logins_detected, run.logouts_detected,
                run.over_limit_found, run.reports_sent, run.reports_failed,
                run.duration_seconds or 0.0,
            )
        return run

    # ------------------------------------------------------------------
    # Step 1: Audit connectivity (RULE 10 / section 30-31)
    # ------------------------------------------------------------------
    def _check_audit_connection(self) -> bool:
        checkpoint, _ = AuditCheckpoint.objects.get_or_create(source_name=CHECKPOINT_SOURCE)
        try:
            connected = self.reader.check_connection()
            error = ""
        except Exception as exc:  # noqa: BLE001
            connected = False
            error = str(exc)

        was_connected = checkpoint.is_connected
        checkpoint.is_connected = connected
        checkpoint.last_error = error
        checkpoint.save(update_fields=["is_connected", "last_error", "updated_at"])

        if connected and not was_connected:
            logger.info("AUDIT_CONNECTED")
        elif not connected and was_connected:
            logger.warning("AUDIT_DISCONNECTED error=%s", error)
        return connected

    # ------------------------------------------------------------------
    # Steps 2-4: read + process audit events (checkpointed & paginated)
    # ------------------------------------------------------------------
    def _read_and_process_audit_events(self):
        checkpoint, _ = AuditCheckpoint.objects.get_or_create(source_name=CHECKPOINT_SOURCE)
        now = timezone.now()

        if checkpoint.last_event_time:
            start_time = checkpoint.last_event_time
        else:
            start_time = now - timezone.timedelta(hours=settings.AUDIT_INITIAL_LOOKBACK_HOURS)

        fetched = 0
        logins = 0
        logouts = 0
        latest_event_time = checkpoint.last_event_time
        cursor = None
        page_size = settings.AUDIT_FETCH_PAGE_SIZE

        while True:
            result = self.reader.fetch_events(start_time, now, cursor=cursor, page_size=page_size)

            if not result.connected:
                # RULE 31 — a failed/empty page mid-scan must not wipe data;
                # simply stop this cycle's ingestion, checkpoint stays put.
                logger.warning("AUDIT_FETCH_INTERRUPTED error=%s", result.error)
                break

            # RULE 31 — an empty batch is a valid, no-op outcome.
            for event in result.events:
                fetched += 1
                try:
                    created_login, created_logout = self._process_single_event(event)
                    logins += 1 if created_login else 0
                    logouts += 1 if created_logout else 0
                except Exception as exc:  # noqa: BLE001 — section 98 isolation
                    logger.error("EVENT_PROCESSING_ERROR event_id=%s error=%s", event.event_id, exc)

                if latest_event_time is None or event.event_time > latest_event_time:
                    latest_event_time = event.event_time

            if not result.has_more:
                break
            cursor = result.next_cursor

        # Advance the checkpoint only after events in this window were
        # handled (section 74 — never advance before processing).
        checkpoint.last_cursor = ""
        checkpoint.last_event_time = latest_event_time or start_time
        checkpoint.last_successful_scan = now
        checkpoint.save(update_fields=["last_cursor", "last_event_time", "last_successful_scan", "updated_at"])

        return fetched, logins, logouts

    def _process_single_event(self, event: AuditEvent) -> tuple[bool, bool]:
        """Returns (login_created, logout_processed)."""
        record, created = AuditEventRecord.objects.get_or_create(
            event_id=event.event_id,
            defaults={
                "event_type": event.event_type.value,
                "session_ref": event.session_id or "",
                "user_name": event.username,
                "sicil": event.sicil,
                "computer_name": event.computer_name,
                "event_time": event.event_time,
                "raw_payload": event.raw_payload or {},
            },
        )
        if not created:
            # RULE 13/72 — the exact same audit event must never be
            # processed twice, even across restarts/pagination overlap.
            return False, False

        if event.event_type == AuditEventType.LOGIN:
            return self._handle_login(event), False
        elif event.event_type == AuditEventType.LOGOUT:
            return False, self._handle_logout(event)
        return False, False

    # ------------------------------------------------------------------
    # LOGIN handling (sections 2, 13, 14, 15)
    # ------------------------------------------------------------------
    def _handle_login(self, event: AuditEvent) -> bool:
        session_id = event.session_id or _derive_session_id(
            event.username, event.computer_name, event.event_time
        )
        with transaction.atomic():
            session, created = Session.objects.select_for_update().get_or_create(
                session_id=session_id,
                defaults={
                    "audit_login_event_id": event.event_id,
                    "user_name": event.username,
                    "sicil": event.sicil,
                    "computer_name": event.computer_name,
                    "login_time": event.event_time,
                    "last_seen": event.event_time,
                    "last_audit_event_time": event.event_time,
                    "status": Session.STATUS_ACTIVE,
                },
            )
            if created:
                SessionTimelineEvent.objects.create(
                    session=session,
                    event_type=SessionTimelineEvent.LOGIN,
                    event_time=event.event_time,
                    description=f"Login detected on {event.computer_name}",
                )
                logger.info(
                    "LOGIN_DETECTED user=%s computer=%s session_id=%s",
                    event.username, event.computer_name, session_id,
                )
            else:
                # RULE 13 — duplicate LOGIN event for an existing session.
                session.last_seen = max(filter(None, [session.last_seen, event.event_time]))
                session.last_audit_event_time = event.event_time
                session.save(update_fields=["last_seen", "last_audit_event_time", "updated_at"])
        return created

    # ------------------------------------------------------------------
    # LOGOUT handling (sections 5-11, RULE 3-10)
    # ------------------------------------------------------------------
    def _handle_logout(self, event: AuditEvent) -> bool:
        with transaction.atomic():
            session = self._find_active_session_for_logout(event)
            if session is None:
                logger.warning(
                    "LOGOUT_WITHOUT_MATCHING_SESSION user=%s computer=%s",
                    event.username, event.computer_name,
                )
                return False

            session = Session.objects.select_for_update().get(pk=session.pk)
            if session.logout_time is not None:
                # RULE 13-style idempotency for duplicate LOGOUT events.
                return False

            duration = event.event_time - session.login_time
            was_over_limit = (
                session.overdue or 
                session.report_send or 
                (duration >= timezone.timedelta(hours=self.limit_hours))
            )

            logger.info(
                "LOGOUT_DETECTED user=%s computer=%s session_id=%s duration=%s was_over_limit=%s",
                event.username, event.computer_name, session.session_id, duration, was_over_limit,
            )

            # Senaryo 1: 12 saat dolmadan logout (< 12h & report_send=False & overdue=False)
            # ➡️ DB kaydı tamamen silinir, SMTP atılmaz, rapor oluşturulmaz.
            if not was_over_limit and not session.report_send:
                session.delete()
                logger.info(
                    "SESSION_PURGED_UNDER_12H user=%s computer=%s session_id=%s duration=%s",
                    event.username, event.computer_name, session.session_id, duration,
                )
                return True

            # Senaryo 4: 12 saati geçmiş veya raporlanmış kullanıcı logout oluyor
            # ➡️ Logout zamanı DB'ye işlenir, son durum/rapor için DB'de tutulur, KESİNLİKLE ikinci SMTP atılmaz.
            session.logout_time = event.event_time
            session.audit_logout_event_id = event.event_id
            session.last_seen = event.event_time
            session.last_audit_event_time = event.event_time
            session.refresh_status(self.limit_hours, now=event.event_time)
            session.save(update_fields=[
                "logout_time", "audit_logout_event_id", "last_seen",
                "last_audit_event_time", "status", "overdue", "updated_at",
            ])

            SessionTimelineEvent.objects.create(
                session=session,
                event_type=SessionTimelineEvent.LOGOUT,
                event_time=event.event_time,
                description=f"Logout detected on {event.computer_name} after {duration}",
            )
        return True

    @staticmethod
    def _find_active_session_for_logout(event: AuditEvent):
        if event.session_id:
            session = Session.objects.filter(session_id=event.session_id, logout_time__isnull=True).first()
            if session:
                return session
        # Fallback: same user+computer, currently active, most recent login
        # RULE 15/16 — never match across different users/computers.
        return (
            Session.objects.filter(
                user_name=event.username,
                computer_name=event.computer_name,
                logout_time__isnull=True,
                login_time__lte=event.event_time,
            )
            .order_by("-login_time")
            .first()
        )

    # ------------------------------------------------------------------
    # Steps 5-9: 12 hour detection + SMTP reporting
    # ------------------------------------------------------------------
    def _process_over_limit_sessions(self):
        now = timezone.now()
        over_limit_qs = Session.objects.over_limit(self.limit_hours, now=now)
        over_limit_count = over_limit_qs.count()

        # Mark the OVER_LIMIT timeline transition once & set overdue=True
        for session in over_limit_qs.iterator():
            if not session.overdue:
                session.overdue = True
                session.refresh_status(self.limit_hours, now=now, save=True)

            if not session.timeline.filter(event_type=SessionTimelineEvent.OVER_LIMIT).exists():
                SessionTimelineEvent.objects.create(
                    session=session,
                    event_type=SessionTimelineEvent.OVER_LIMIT,
                    event_time=session.login_time + timezone.timedelta(hours=self.limit_hours),
                    description=f"Session exceeded {self.limit_hours} hour limit",
                )
                logger.info("SESSION_OVER_LIMIT session_id=%s user=%s", session.session_id, session.user_name)
            if session.status != Session.STATUS_OVER_LIMIT and not session.report_send:
                session.refresh_status(self.limit_hours, now=now, save=True)

        pending_qs = Session.objects.pending_report(self.limit_hours, now=now).values_list("pk", flat=True)
        sent = 0
        failed = 0
        for session_pk in list(pending_qs):
            try:
                ok = self.report_service.send_over_limit_report(session_pk)
                if ok:
                    sent += 1
                else:
                    failed += 1
            except Exception as exc:  # noqa: BLE001 — section 98 isolation
                failed += 1
                logger.error("REPORT_PROCESSING_ERROR session_pk=%s error=%s", session_pk, exc)

        return over_limit_count, sent, failed

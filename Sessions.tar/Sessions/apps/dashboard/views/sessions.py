from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.http import Http404
from django.shortcuts import render
from django.utils import timezone

from apps.sessions.models import Session
from apps.system_status.services import get_system_status

from ..utils import apply_ordering, apply_search, format_duration, paginate, severity_for_duration

SEARCH_FIELDS = ["user_name", "sicil", "computer_name", "session_id"]
SORTABLE_FIELDS = ["login_time", "user_name", "computer_name", "status", "report_time", "logout_time"]


def _render_session_list(request, queryset, title, subtitle, active_page):
    limit_hours = get_system_status()["session_limit_hours"]
    now = timezone.now()

    queryset = apply_search(queryset, request, SEARCH_FIELDS)
    queryset = apply_ordering(queryset, request, SORTABLE_FIELDS)

    date_filter = request.GET.get("date")
    if date_filter == "today":
        queryset = queryset.filter(login_time__date=now.date())
    elif date_filter == "24h":
        queryset = queryset.filter(login_time__gte=now - timezone.timedelta(hours=24))
    elif date_filter == "7d":
        queryset = queryset.filter(login_time__gte=now - timezone.timedelta(days=7))

    report_filter = request.GET.get("report")
    if report_filter == "reported":
        queryset = queryset.filter(report_send=True)
    elif report_filter == "pending":
        queryset = queryset.filter(report_send=False)
    elif report_filter == "failed":
        queryset = queryset.filter(report_send=False, report_attempts__gt=0)

    page_obj = paginate(request, queryset, per_page=20)

    rows = []
    for session in page_obj:
        duration = session.duration(now=now)
        rows.append({
            "session": session,
            "duration": format_duration(duration),
            "severity": severity_for_duration(duration, limit_hours) if session.is_active else "gray",
        })

    context = {
        "title": title,
        "subtitle": subtitle,
        "rows": rows,
        "page_obj": page_obj,
        "active_page": active_page,
        "limit_hours": limit_hours,
        "query_params": request.GET.urlencode(),
    }
    return render(request, "dashboard/sessions/list.html", context)


@login_required
def active_sessions(request):
    return _render_session_list(
        request, Session.objects.active(),
        "Active Sessions", "All sessions currently without a logout event",
        "sessions-active",
    )


@login_required
def over_12h_sessions(request):
    limit_hours = get_system_status()["session_limit_hours"]
    qs = Session.objects.over_limit(limit_hours)
    return _render_session_list(
        request, qs,
        "Over 12 Hours", f"Active sessions that exceeded the {limit_hours}-hour threshold",
        "sessions-over12h",
    )


@login_required
def recently_logged_out(request):
    qs = Session.objects.logged_out()
    return _render_session_list(
        request, qs,
        "Recently Logged Out", "Completed sessions (logout confirmed by audit)",
        "sessions-logged-out",
    )


@login_required
def session_detail(request, pk):
    try:
        session = Session.objects.prefetch_related("timeline", "reports").get(pk=pk)
    except Session.DoesNotExist:
        raise Http404

    limit_hours = get_system_status()["session_limit_hours"]
    now = timezone.now()
    duration = session.duration(now=now)
    deadline = session.login_time + timezone.timedelta(hours=limit_hours)

    # Fetch real raw audit event records associated with this session/user/computer
    from apps.audit.models import AuditEventRecord
    audit_events = AuditEventRecord.objects.filter(
        Q(session_ref=session.session_id) |
        Q(user_name=session.user_name, computer_name=session.computer_name)
    ).order_by("-event_time")[:15]

    exceeded_duration = None
    if session.is_active and duration.total_seconds() > (limit_hours * 3600):
        exceeded_seconds = duration.total_seconds() - (limit_hours * 3600)
        exceeded_duration = format_duration(timezone.timedelta(seconds=exceeded_seconds))

    context = {
        "session": session,
        "duration": format_duration(duration),
        "severity": severity_for_duration(duration, limit_hours) if session.is_active else "gray",
        "deadline": deadline,
        "exceeded_duration": exceeded_duration,
        "timeline": session.timeline.all(),
        "reports": session.reports.all(),
        "audit_events": audit_events,
        "limit_hours": limit_hours,
    }

    is_ajax = request.headers.get("x-requested-with") == "XMLHttpRequest"
    template = "dashboard/sessions/_detail_drawer.html" if is_ajax else "dashboard/sessions/detail.html"
    return render(request, template, context)

from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.shortcuts import render
from django.utils import timezone

from apps.monitoring.models import MonitoringCycleRun
from apps.system_status.models import SystemLogEntry
from apps.system_status.services import get_system_status

from ..utils import paginate


@login_required
def status(request):
    system_status = get_system_status(use_cache=False)
    recent_cycles = MonitoringCycleRun.objects.order_by("-started_at")[:15]
    return render(request, "dashboard/system/status.html", {
        "status": system_status,
        "recent_cycles": recent_cycles,
        "active_page": "system-status",
    })


@login_required
def logs(request):
    queryset = SystemLogEntry.objects.all().order_by("-created_at")
    
    # Calculate stats
    total_count = SystemLogEntry.objects.count()
    error_count = SystemLogEntry.objects.filter(level__in=["ERROR", "CRITICAL"]).count()
    warning_count = SystemLogEntry.objects.filter(level="WARNING").count()
    info_count = SystemLogEntry.objects.filter(level__in=["INFO", "DEBUG"]).count()

    level = request.GET.get("level", "").strip()
    if level in dict(SystemLogEntry.LEVEL_CHOICES):
        queryset = queryset.filter(level=level)

    q = request.GET.get("q", "").strip()
    if q:
        queryset = queryset.filter(Q(message__icontains=q) | Q(logger_name__icontains=q))

    page_obj = paginate(request, queryset, per_page=20)
    return render(request, "dashboard/system/logs.html", {
        "page_obj": page_obj,
        "selected_level": level,
        "levels": SystemLogEntry.LEVEL_CHOICES,
        "active_page": "system-logs",
        "q": q,
        "stats": {
            "total": total_count,
            "errors": error_count,
            "warnings": warning_count,
            "info": info_count,
        }
    })


@login_required
def smtp_status(request):
    from apps.reporting.models import ReportHistory

    system_status = get_system_status()
    recent_failures = ReportHistory.objects.filter(status=ReportHistory.FAILED).select_related("session").order_by("-updated_at")[:20]
    return render(request, "dashboard/system/smtp.html", {
        "status": system_status,
        "recent_failures": recent_failures,
        "active_page": "system-smtp",
    })


def get_host_hardware_metrics():
    import datetime
    import os
    import platform
    import socket
    import sys
    import psutil
    import django

    # CPU
    cpu_percent = psutil.cpu_percent(interval=None)
    cpu_logical = psutil.cpu_count(logical=True) or 1
    cpu_physical = psutil.cpu_count(logical=False) or 1
    try:
        cpu_freq = psutil.cpu_freq()
        current_ghz = round(cpu_freq.current / 1000, 2) if cpu_freq else 0
    except Exception:
        current_ghz = 0

    # Memory
    mem = psutil.virtual_memory()
    mem_total_gb = round(mem.total / (1024 ** 3), 2)
    mem_used_gb = round(mem.used / (1024 ** 3), 2)
    mem_free_gb = round(mem.available / (1024 ** 3), 2)
    mem_percent = mem.percent

    # Disk
    try:
        disk = psutil.disk_usage('/')
        disk_total_gb = round(disk.total / (1024 ** 3), 2)
        disk_used_gb = round(disk.used / (1024 ** 3), 2)
        disk_free_gb = round(disk.free / (1024 ** 3), 2)
        disk_percent = disk.percent
    except Exception:
        disk_total_gb, disk_used_gb, disk_free_gb, disk_percent = 0, 0, 0, 0

    # Network
    try:
        net_io = psutil.net_io_counters()
        bytes_sent_mb = round(net_io.bytes_sent / (1024 ** 2), 2)
        bytes_recv_mb = round(net_io.bytes_recv / (1024 ** 2), 2)
    except Exception:
        bytes_sent_mb, bytes_recv_mb = 0, 0

    # Network Interfaces
    interfaces = []
    try:
        addrs = psutil.net_if_addrs()
        stats = psutil.net_if_stats()
        for iface_name, addr_list in addrs.items():
            ipv4_list = [a.address for a in addr_list if a.family == socket.AF_INET]
            netmask_list = [a.netmask for a in addr_list if a.family == socket.AF_INET and a.netmask]
            if ipv4_list:
                is_up = stats[iface_name].isup if iface_name in stats else True
                speed = stats[iface_name].speed if iface_name in stats else 0
                interfaces.append({
                    "name": iface_name,
                    "ip": ipv4_list[0],
                    "netmask": netmask_list[0] if netmask_list else "255.255.255.0",
                    "is_up": is_up,
                    "speed": f"{speed} Mbps" if speed > 0 else "Otomatik"
                })
    except Exception:
        pass

    # System Info
    boot_time = datetime.datetime.fromtimestamp(psutil.boot_time())
    uptime_delta = datetime.datetime.now() - boot_time
    hours, remainder = divmod(int(uptime_delta.total_seconds()), 3600)
    minutes, seconds = divmod(remainder, 60)
    uptime_formatted = f"{hours}s {minutes}dk {seconds}sn"

    # Primary IP Address
    primary_ip = "127.0.0.1"
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        primary_ip = s.getsockname()[0]
        s.close()
    except Exception:
        try:
            primary_ip = socket.gethostbyname(socket.gethostname())
        except Exception:
            pass

    server_now = timezone.now().strftime("%d.%m.%Y %H:%M:%S")

    return {
        "cpu": {
            "percent": cpu_percent,
            "logical_cores": cpu_logical,
            "physical_cores": cpu_physical,
            "current_ghz": current_ghz,
        },
        "memory": {
            "total_gb": mem_total_gb,
            "used_gb": mem_used_gb,
            "free_gb": mem_free_gb,
            "percent": mem_percent,
        },
        "disk": {
            "total_gb": disk_total_gb,
            "used_gb": disk_used_gb,
            "free_gb": disk_free_gb,
            "percent": disk_percent,
        },
        "network": {
            "sent_mb": bytes_sent_mb,
            "recv_mb": bytes_recv_mb,
            "interfaces": interfaces,
            "primary_ip": primary_ip,
        },
        "system": {
            "hostname": socket.gethostname(),
            "os_name": platform.system(),
            "os_release": platform.release(),
            "os_version": platform.version(),
            "processor": platform.processor() or platform.machine(),
            "machine": platform.machine(),
            "primary_ip": primary_ip,
            "uptime": uptime_formatted,
            "boot_time": boot_time.strftime("%d.%m.%Y %H:%M:%S"),
            "python_version": sys.version.split()[0],
            "django_version": django.get_version(),
            "server_time": server_now,
            "timezone": "Europe/Istanbul",
        }
    }


@login_required
def resources(request):
    data = get_host_hardware_metrics()
    return render(request, "dashboard/system/resources.html", {
        "metrics": data,
        "active_page": "system-resources",
    })


@login_required
def resources_api(request):
    from django.http import JsonResponse
    data = get_host_hardware_metrics()
    return JsonResponse(data)


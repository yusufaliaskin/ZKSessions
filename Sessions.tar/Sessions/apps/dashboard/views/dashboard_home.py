from django.contrib.auth.decorators import login_required
from django.db.models import Count, Q
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
from django.utils import timezone
from datetime import timedelta
import csv

from apps.audit.models import AuditEventRecord
from apps.reporting.models import ReportHistory
from apps.sessions.models import Session
from apps.system_status.services import get_system_status

from ..utils import format_duration, severity_for_duration


def calculate_time_slots(now, time_range, start_date=None, end_date=None):
    """Calculates real histogram buckets and labels for the selected time range."""
    hours_labels = []
    hourly_counts = []
    
    if time_range == "1h":
        base_time = now - timedelta(minutes=55)
        for i in range(12):
            slot_start = base_time + timedelta(minutes=i*5)
            slot_end = slot_start + timedelta(minutes=5)
            cnt = Session.objects.filter(login_time__gte=slot_start, login_time__lt=slot_end).count()
            audit_cnt = AuditEventRecord.objects.filter(event_time__gte=slot_start, event_time__lt=slot_end).count()
            hours_labels.append(slot_start.strftime("%H:%M"))
            hourly_counts.append(cnt + audit_cnt)
    elif time_range == "6h":
        base_time = now - timedelta(hours=6)
        for i in range(12):
            slot_start = base_time + timedelta(minutes=i*30)
            slot_end = slot_start + timedelta(minutes=30)
            cnt = Session.objects.filter(login_time__gte=slot_start, login_time__lt=slot_end).count()
            audit_cnt = AuditEventRecord.objects.filter(event_time__gte=slot_start, event_time__lt=slot_end).count()
            hours_labels.append(slot_start.strftime("%H:%M"))
            hourly_counts.append(cnt + audit_cnt)
    elif time_range == "12h":
        base_time = now - timedelta(hours=11)
        for i in range(12):
            slot_start = base_time + timedelta(hours=i)
            slot_end = slot_start + timedelta(hours=1)
            cnt = Session.objects.filter(login_time__gte=slot_start, login_time__lt=slot_end).count()
            audit_cnt = AuditEventRecord.objects.filter(event_time__gte=slot_start, event_time__lt=slot_end).count()
            hours_labels.append(slot_start.strftime("%H:00"))
            hourly_counts.append(cnt + audit_cnt)
    elif time_range == "7d":
        base_time = now - timedelta(days=6)
        for i in range(7):
            slot_start = (base_time + timedelta(days=i)).replace(hour=0, minute=0, second=0)
            slot_end = slot_start + timedelta(days=1)
            cnt = Session.objects.filter(login_time__gte=slot_start, login_time__lt=slot_end).count()
            audit_cnt = AuditEventRecord.objects.filter(event_time__gte=slot_start, event_time__lt=slot_end).count()
            hours_labels.append(slot_start.strftime("%d.%m"))
            hourly_counts.append(cnt + audit_cnt)
    elif time_range == "30d":
        base_time = now - timedelta(days=29)
        for i in range(30):
            slot_start = (base_time + timedelta(days=i)).replace(hour=0, minute=0, second=0)
            slot_end = slot_start + timedelta(days=1)
            cnt = Session.objects.filter(login_time__gte=slot_start, login_time__lt=slot_end).count()
            audit_cnt = AuditEventRecord.objects.filter(event_time__gte=slot_start, event_time__lt=slot_end).count()
            if i % 3 == 0 or i == 29:
                hours_labels.append(slot_start.strftime("%d.%m"))
            else:
                hours_labels.append("")
            hourly_counts.append(cnt + audit_cnt)
    elif time_range == "custom" and start_date and end_date:
        try:
            from django.utils.dateparse import parse_datetime, parse_date
            s_dt = parse_datetime(start_date)
            if s_dt and timezone.is_naive(s_dt):
                s_dt = timezone.make_aware(s_dt)
            elif not s_dt and parse_date(start_date):
                s_dt = timezone.make_aware(timezone.datetime.combine(parse_date(start_date), timezone.datetime.min.time()))

            e_dt = parse_datetime(end_date)
            if e_dt and timezone.is_naive(e_dt):
                e_dt = timezone.make_aware(e_dt)
            elif not e_dt and parse_date(end_date):
                e_dt = timezone.make_aware(timezone.datetime.combine(parse_date(end_date), timezone.datetime.max.time()))

            if s_dt and e_dt and e_dt > s_dt:
                total_seconds = (e_dt - s_dt).total_seconds()
                num_slots = 12
                step_sec = total_seconds / num_slots
                for i in range(num_slots):
                    slot_start = s_dt + timedelta(seconds=i*step_sec)
                    slot_end = slot_start + timedelta(seconds=step_sec)
                    cnt = Session.objects.filter(login_time__gte=slot_start, login_time__lt=slot_end).count()
                    audit_cnt = AuditEventRecord.objects.filter(event_time__gte=slot_start, event_time__lt=slot_end).count()
                    hours_labels.append(slot_start.strftime("%d.%m %H:%M"))
                    hourly_counts.append(cnt + audit_cnt)
        except Exception:
            pass
            
    if not hours_labels:
        # Default 24h
        base_time = now - timedelta(hours=23)
        for i in range(24):
            slot_start = base_time + timedelta(hours=i)
            slot_end = slot_start + timedelta(hours=1)
            session_hits = Session.objects.filter(login_time__lt=slot_end).filter(
                Q(logout_time__isnull=True) | Q(logout_time__gte=slot_start)
            ).count()
            audit_hits = AuditEventRecord.objects.filter(event_time__gte=slot_start, event_time__lt=slot_end).count()
            if i % 2 == 0:
                hours_labels.append(slot_start.strftime("%H:00"))
            else:
                hours_labels.append("")
            hourly_counts.append(session_hits + audit_hits)
            
    return hours_labels, hourly_counts


@login_required
def index(request):
    status = get_system_status(use_cache=False)
    limit_hours = status.get("session_limit_hours", 12)
    now = timezone.now()

    # Time Range Filtering
    time_range = request.GET.get("time_range", "24h").strip()
    start_date_str = request.GET.get("start_date", "").strip()
    end_date_str = request.GET.get("end_date", "").strip()

    labels_map = {
        "1h": "Son 1 Saat",
        "6h": "Son 6 Saat",
        "12h": "Son 12 Saat",
        "24h": "Son 24 Saat",
        "7d": "Son 7 Gün",
        "30d": "Son 30 Gün",
        "custom": "Özel Tarih Aralığı",
    }
    time_range_label = labels_map.get(time_range, "Son 24 Saat")

    # 1. 100% Real Live Database Queries
    active_qs = Session.objects.active()
    over_limit_qs = Session.objects.over_limit(limit_hours, now=now)
    total_sessions_count = Session.objects.count()
    logged_out_count = Session.objects.filter(logout_time__isnull=False).count()
    reports_sent_count = ReportHistory.objects.filter(status=ReportHistory.SENT).count()
    reports_failed_count = ReportHistory.objects.filter(status=ReportHistory.FAILED).count()
    reports_pending_count = Session.objects.pending_report(limit_hours, now=now).count()

    stats = {
        "total_sessions": total_sessions_count,
        "active_sessions": active_qs.count(),
        "over_limit": over_limit_qs.count(),
        "reports_sent": reports_sent_count,
        "reports_pending": reports_pending_count,
        "reports_failed": reports_failed_count,
        "logged_out_count": logged_out_count,
        "auth_success": active_qs.count() + logged_out_count,
    }

    # 2. Real Donut Chart Breakdown
    safe_active_count = max(0, stats["active_sessions"] - stats["over_limit"])
    chart_distribution = {
        "Active Under 12h": safe_active_count,
        "Over 12h Alert": stats["over_limit"],
        "Closed / Logged Out": stats["logged_out_count"],
        "Report Dispatched": stats["reports_sent"],
    }

    # 3. Real Activity Histogram based on selected time range
    hours_labels, hourly_counts = calculate_time_slots(now, time_range, start_date_str, end_date_str)

    # 4. Critical Active Over-Limit Sessions (Max 4 real records, zero mock data)
    critical_sessions_qs = over_limit_qs.order_by("login_time")[:4]
    critical_sessions = []
    for s in critical_sessions_qs:
        dur = s.duration(now=now)
        dur_hours = round(dur.total_seconds() / 3600.0, 1)
        critical_sessions.append({
            "id": s.id,
            "user_name": s.user_name,
            "sicil": s.sicil,
            "computer_name": s.computer_name,
            "login_time": s.login_time,
            "duration": format_duration(dur),
            "duration_hours": dur_hours,
            "is_reported": s.report_send,
            "report_status": "Raporlandı" if s.report_send else ("Hata" if s.report_attempts > 0 else "Bekliyor"),
            "report_status_class": "completed" if s.report_send else "in-progress",
            "day_text": f"{dur_hours} saat aktif"
        })

    # 5. Recent Dispatched Reports (Max 4 real records, zero mock data)
    recent_reports_qs = ReportHistory.objects.select_related("session").order_by("-sent_at", "-created_at")[:4]
    recent_reports_list = []
    for r in recent_reports_qs:
        s = r.session
        dur = s.duration(now=now) if s else timedelta(0)
        dur_hours = round(dur.total_seconds() / 3600.0, 1)
        recent_reports_list.append({
            "user_name": s.user_name if s else "Bilinmeyen Kullanıcı",
            "computer_name": s.computer_name if s else "-",
            "time_label": (r.sent_at or r.created_at).strftime("%d %b %Y - %H:%M"),
            "metric_value": f"{dur_hours} saat" if s else "Raporlandı",
            "status": r.get_status_display(),
        })

    context = {
        "stats": stats,
        "chart_distribution": chart_distribution,
        "hours_labels": hours_labels,
        "hourly_counts": hourly_counts,
        "critical_sessions": critical_sessions,
        "recent_reports_list": recent_reports_list,
        "status": status,
        "time_range": time_range,
        "time_range_label": time_range_label,
        "start_date": start_date_str,
        "end_date": end_date_str,
        "active_page": "dashboard",
    }
    return render(request, "dashboard/index.html", context)


@login_required
def quick_search_api(request):
    """Real-time enterprise banking search API returning both sessions and audit events."""
    query = request.GET.get("q", "").strip()
    if not query or len(query) < 1:
        return JsonResponse({"sessions": [], "audit_events": [], "total_found": 0})

    now = timezone.now()

    # 1. Search Sessions
    sessions_qs = Session.objects.filter(
        Q(user_name__icontains=query) |
        Q(sicil__icontains=query) |
        Q(computer_name__icontains=query) |
        Q(session_id__icontains=query)
    ).order_by("-login_time")[:6]

    session_results = []
    for s in sessions_qs:
        dur = s.duration(now=now)
        session_results.append({
            "id": s.id,
            "user_name": s.user_name,
            "sicil": s.sicil,
            "computer_name": s.computer_name,
            "status": s.get_status_display(),
            "status_code": s.status,
            "duration": format_duration(dur),
            "login_time": s.login_time.strftime("%d.%m.%Y %H:%M:%S") if s.login_time else "",
            "is_over_limit": s.is_over_limit(12, now=now),
            "report_sent": s.report_send,
            "detail_url": f"/sessions/{s.id}/",
        })

    # 2. Search Audit Events
    audit_qs = AuditEventRecord.objects.filter(
        Q(user_name__icontains=query) |
        Q(sicil__icontains=query) |
        Q(computer_name__icontains=query) |
        Q(event_id__icontains=query) |
        Q(session_ref__icontains=query)
    ).order_by("-event_time")[:6]

    audit_results = []
    for a in audit_qs:
        audit_results.append({
            "id": a.id,
            "event_id": a.event_id,
            "event_type": a.event_type,
            "user_name": a.user_name,
            "sicil": a.sicil,
            "computer_name": a.computer_name,
            "event_time": a.event_time.strftime("%d.%m.%Y %H:%M:%S") if a.event_time else "",
            "session_ref": a.session_ref,
            "detail_url": f"/audit/{a.id}/",
        })

    total_found = len(session_results) + len(audit_results)

    return JsonResponse({
        "sessions": session_results,
        "audit_events": audit_results,
        "total_found": total_found,
    })


@login_required
def export_csv(request):
    """Direct CSV download for active and audit session events."""
    now = timezone.now()
    response = HttpResponse(content_type="text/csv; charset=utf-8")
    response["Content-Disposition"] = f'attachment; filename="ziraat_oturum_guvenlik_{now.strftime("%Y%m%d_%H%M%S")}.csv"'
    response.write("\ufeff")  # BOM for Excel compatibility

    writer = csv.writer(response)
    writer.writerow(["ID", "Kullanıcı Adı", "Sicil", "Cihaz Adı", "Giriş Zamanı", "Çıkış Zamanı", "Durum", "Rapor Gönderildi"])

    sessions = Session.objects.all().order_by("-login_time")[:5000]
    for s in sessions:
        writer.writerow([
            s.id,
            s.user_name,
            s.sicil,
            s.computer_name,
            s.login_time.strftime("%d.%m.%Y %H:%M:%S") if s.login_time else "",
            s.logout_time.strftime("%d.%m.%Y %H:%M:%S") if s.logout_time else "Aktif",
            s.get_status_display(),
            "Evet" if s.report_send else "Hayır",
        ])

    return response


@login_required
def live_stats_api(request):
    """Real-time JSON endpoint polled by the frontend for live Wazuh refresh & dynamic time filter updates."""
    status = get_system_status(use_cache=False)
    limit_hours = status.get("session_limit_hours", 12)
    now = timezone.now()

    time_range = request.GET.get("time_range", "24h").strip()
    start_date = request.GET.get("start_date", "").strip()
    end_date = request.GET.get("end_date", "").strip()

    active_count = Session.objects.active().count()
    over_limit_count = Session.objects.over_limit(limit_hours, now=now).count()
    logged_out_count = Session.objects.filter(logout_time__isnull=False).count()
    total_count = Session.objects.count()
    reports_sent = ReportHistory.objects.filter(status=ReportHistory.SENT).count()
    reports_failed = ReportHistory.objects.filter(status=ReportHistory.FAILED).count()
    reports_pending = Session.objects.pending_report(limit_hours, now=now).count()

    hours_labels, hourly_counts = calculate_time_slots(now, time_range, start_date, end_date)

    return JsonResponse({
        "timestamp": now.strftime("%Y-%m-%d %H:%M:%S"),
        "time_range": time_range,
        "active_sessions": active_count,
        "over_limit": over_limit_count,
        "logged_out_count": logged_out_count,
        "total_sessions": total_count,
        "reports_sent": reports_sent,
        "reports_pending": reports_pending,
        "reports_failed": reports_failed,
        "hours_labels": hours_labels,
        "hourly_counts": hourly_counts,
        "chart_distribution": {
            "Active Under 12h": max(0, active_count - over_limit_count),
            "Over 12h Alert": over_limit_count,
            "Closed / Logged Out": logged_out_count,
            "Report Dispatched": reports_sent,
        },
        "audit_connected": status.get("audit_connected", True),
        "worker_status": status.get("worker_status", "running"),
        "smtp_status": status.get("smtp_status", "connected"),
    })

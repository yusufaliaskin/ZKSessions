from django.urls import path

from .views import assets, audit, dashboard_home, reports, sessions, system

app_name = "dashboard"

urlpatterns = [
    path("", dashboard_home.index, name="index"),
    path("api/live-stats/", dashboard_home.live_stats_api, name="live_stats_api"),
    path("api/quick-search/", dashboard_home.quick_search_api, name="quick_search_api"),
    path("api/export-sessions/", dashboard_home.export_csv, name="export_csv"),

    path("sessions/active/", sessions.active_sessions, name="sessions_active"),
    path("sessions/over-12h/", sessions.over_12h_sessions, name="sessions_over12h"),
    path("sessions/logged-out/", sessions.recently_logged_out, name="sessions_logged_out"),
    path("sessions/<int:pk>/", sessions.session_detail, name="session_detail"),

    path("reports/sent/", reports.sent_reports, name="reports_sent"),
    path("reports/pending/", reports.pending_reports, name="reports_pending"),
    path("reports/failed/", reports.failed_reports, name="reports_failed"),
    path("reports/<int:pk>/", reports.report_detail, name="report_detail"),

    path("audit/events/", audit.all_events, name="audit_events"),
    path("audit/login/", audit.login_events, name="audit_login"),
    path("audit/logout/", audit.logout_events, name="audit_logout"),
    path("audit/<int:pk>/", audit.event_detail, name="audit_detail"),

    path("assets/computers/", assets.computers, name="computers"),
    path("assets/users/", assets.users, name="users"),

    path("system/status/", system.status, name="system_status"),
    path("system/resources/", system.resources, name="system_resources"),
    path("api/system-resources/", system.resources_api, name="system_resources_api"),
    path("system/logs/", system.logs, name="system_logs"),
    path("system/smtp/", system.smtp_status, name="system_smtp"),
]

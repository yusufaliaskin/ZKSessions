from django import forms

from .models import SystemSettings


class SystemSettingsForm(forms.ModelForm):
    monitor_interval_hours = forms.IntegerField(
        label="Tarama Periyodu (Saat)",
        min_value=1,
        max_value=168,
        widget=forms.NumberInput(attrs={
            "class": "custom-settings-input",
            "step": "1",
            "min": "1",
            "placeholder": "1",
        }),
    )

    class Meta:
        model = SystemSettings
        fields = ["session_limit_hours"]
        widgets = {
            "session_limit_hours": forms.NumberInput(attrs={
                "class": "custom-settings-input",
                "min": 1,
                "max": 168,
                "placeholder": "12",
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance and self.instance.pk:
            secs = self.instance.monitor_interval_seconds or 3600
            hours = max(1, int(round(secs / 3600.0)))
            self.fields["monitor_interval_hours"].initial = hours
            self.initial["monitor_interval_hours"] = hours

    def save(self, commit=True):
        instance = super().save(commit=False)
        hours = self.cleaned_data.get("monitor_interval_hours")
        if hours is not None:
            instance.monitor_interval_seconds = int(hours * 3600)
        if commit:
            instance.save()
        return instance




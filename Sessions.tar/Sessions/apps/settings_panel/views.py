from django.conf import settings as django_settings
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect, render

from apps.accounts.decorators import administrator_required
from apps.audit.adapters.factory import get_audit_reader, reset_audit_reader_cache
from apps.reporting.services.email_service import EmailReportService

from .forms import SystemSettingsForm
from .models import SystemSettings


def _mask(value: str) -> str:
    if not value:
        return "(not configured)"
    if len(value) <= 4:
        return "•" * len(value)
    return value[:2] + "•" * (len(value) - 4) + value[-2:]


@login_required
@administrator_required
def index(request):
    system_settings = SystemSettings.load()

    if request.method == "POST":
        action = request.POST.get("action", "save_settings")
        
        if action == "test_smtp":
            custom_recipient = request.POST.get("test_recipient", "").strip() or None
            success, msg = EmailReportService.send_test_email(recipient=custom_recipient)
            if success:
                messages.success(request, f"SMTP Test: {msg}")
            else:
                messages.error(request, f"SMTP Test: {msg}")
            return redirect("settings_panel:index")

        elif action == "test_audit":
            reset_audit_reader_cache()
            reader = get_audit_reader()
            try:
                is_connected = reader.check_connection()
                if is_connected:
                    messages.success(request, f"Audit Connection Success: Successfully connected via {reader.__class__.__name__}")
                else:
                    messages.error(request, f"Audit Connection Failed: Unable to verify connection via {reader.__class__.__name__}")
            except Exception as exc:
                messages.error(request, f"Audit Connection Error: {exc}")
            return redirect("settings_panel:index")

        else:
            form = SystemSettingsForm(request.POST, instance=system_settings)
            if form.is_valid():
                obj = form.save(commit=False)
                obj.updated_by = request.user.get_username()
                obj.save()
                messages.success(request, "Monitoring settings updated.")
                return redirect("settings_panel:index")
    else:
        form = SystemSettingsForm(instance=system_settings)

    smtp_info = {
        "host": django_settings.EMAIL_HOST or "(not configured)",
        "port": django_settings.EMAIL_PORT,
        "username": _mask(django_settings.EMAIL_HOST_USER),
        "from_email": django_settings.DEFAULT_FROM_EMAIL or "(not configured)",
        "recipients": ", ".join(django_settings.SESSION_REPORT_RECIPIENTS) or "(not configured)",
        "use_tls": django_settings.EMAIL_USE_TLS,
        "use_ssl": getattr(django_settings, "EMAIL_USE_SSL", False),
    }
    audit_info = {
        "backend": django_settings.AUDIT_BACKEND,
        "host": django_settings.AUDIT_HOST or "(not configured / using mock adapter)",
        "port": django_settings.AUDIT_PORT or "-",
        "username": _mask(django_settings.AUDIT_USERNAME),
        "db_name": getattr(django_settings, "AUDIT_DB_NAME", "") or "-",
        "api_url": getattr(django_settings, "AUDIT_API_URL", "") or "-",
    }

    return render(request, "dashboard/settings/index.html", {
        "form": form,
        "system_settings": system_settings,
        "smtp_info": smtp_info,
        "audit_info": audit_info,
        "active_page": "system-settings",
    })



"""
Core Session model — the heart of SESSION MONITOR (section 18-19, 79).

Design notes:
  * `logout_time`, `report_send` and `login_time` are the real source of
    truth. `status` is a *derived, denormalized* convenience column kept in
    sync by `refresh_status()` so it can be indexed/filtered/sorted cheaply
    for 5000+ rows, without turning it into a second source of truth.
  * A session is uniquely identified, in order of preference, by:
      1. session_id (if the audit system provides one)
      2. audit_event_id of its LOGIN event
      3. (user_name, computer_name, login_time) triple
    See RULE 8 / section 13 duplicate-login prevention.
"""
from django.db import models
from django.utils import timezone


class SessionQuerySet(models.QuerySet):
    def active(self):
        """RULE: a session is active until a real logout event arrives."""
        return self.filter(logout_time__isnull=True)

    def logged_out(self):
        return self.filter(logout_time__isnull=False)

    def over_limit(self, limit_hours: int, now=None):
        now = now or timezone.now()
        threshold = now - timezone.timedelta(hours=limit_hours)
        return self.active().filter(login_time__lte=threshold)

    def under_limit(self, limit_hours: int, now=None):
        now = now or timezone.now()
        threshold = now - timezone.timedelta(hours=limit_hours)
        return self.active().filter(login_time__gt=threshold)

    def pending_report(self, limit_hours: int, now=None):
        """Sessions that have crossed the limit but have not been reported
        yet — RULE 8/9: never send a duplicate report for report_send=True.
        """
        return self.over_limit(limit_hours, now).filter(report_send=False)

    def report_failed(self):
        return self.filter(report_send=False, report_attempts__gt=0, logout_time__isnull=True)


class Session(models.Model):
    STATUS_ACTIVE = "ACTIVE"
    STATUS_OVER_LIMIT = "OVER_12_HOURS"
    STATUS_REPORT_SENT = "REPORT_SENT"
    STATUS_LOGGED_OUT = "LOGGED_OUT"
    STATUS_CHOICES = [
        (STATUS_ACTIVE, "Active"),
        (STATUS_OVER_LIMIT, "Over Limit"),
        (STATUS_REPORT_SENT, "Report Sent"),
        (STATUS_LOGGED_OUT, "Logged Out"),
    ]

    # --- identity -----------------------------------------------------
    session_id = models.CharField(max_length=255, unique=True, db_index=True)
    audit_login_event_id = models.CharField(max_length=255, blank=True, default="", db_index=True)
    audit_logout_event_id = models.CharField(max_length=255, blank=True, default="", db_index=True)

    user_name = models.CharField(max_length=150, db_index=True)
    sicil = models.CharField(max_length=50, db_index=True)
    computer_name = models.CharField(max_length=150, db_index=True)

    # --- lifecycle ------------------------------------------------------
    login_time = models.DateTimeField(db_index=True)
    logout_time = models.DateTimeField(null=True, blank=True, db_index=True)

    overdue = models.BooleanField(default=False, db_index=True)
    report_time = models.DateTimeField(null=True, blank=True)
    report_send = models.BooleanField(default=False, db_index=True)
    report_attempts = models.PositiveIntegerField(default=0)
    last_report_error = models.TextField(blank=True, default="")

    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_ACTIVE, db_index=True)

    last_seen = models.DateTimeField(null=True, blank=True)
    last_audit_event_time = models.DateTimeField(null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = SessionQuerySet.as_manager()

    class Meta:
        ordering = ["-login_time"]
        indexes = [
            models.Index(fields=["user_name", "computer_name"]),
            models.Index(fields=["logout_time", "report_send"]),
            models.Index(fields=["login_time", "logout_time"]),
            models.Index(fields=["status"]),
            models.Index(fields=["overdue"]),
        ]

    def __str__(self):
        return f"{self.user_name}@{self.computer_name} ({self.session_id})"

    # -- derived, read-only helpers -------------------------------------
    @property
    def is_active(self) -> bool:
        return self.logout_time is None

    def duration(self, now=None):
        end = self.logout_time or (now or timezone.now())
        return end - self.login_time

    def is_over_limit(self, limit_hours: int, now=None) -> bool:
        if not self.is_active:
            return False
        now = now or timezone.now()
        return (now - self.login_time) >= timezone.timedelta(hours=limit_hours)

    def refresh_status(self, limit_hours: int, now=None, save=False):
        """Recompute the denormalized `status` & `overdue` columns from source-of-truth
        fields.
        """
        if self.logout_time is not None:
            self.status = self.STATUS_LOGGED_OUT
        elif self.report_send:
            self.status = self.STATUS_REPORT_SENT
            self.overdue = True
        elif self.is_over_limit(limit_hours, now=now):
            self.status = self.STATUS_OVER_LIMIT
            self.overdue = True
        else:
            self.status = self.STATUS_ACTIVE
            self.overdue = False
        if save:
            self.save(update_fields=["status", "overdue", "updated_at"])
        return self.status


class SessionTimelineEvent(models.Model):
    """Human-readable timeline entries backing the Session Detail drawer
    (section 48). Purely additive/local bookkeeping — never derived from or
    written back to the audit system.
    """

    LOGIN = "LOGIN"
    OVER_LIMIT = "OVER_LIMIT"
    REPORT_SENT = "REPORT_SENT"
    REPORT_FAILED = "REPORT_FAILED"
    LOGOUT = "LOGOUT"
    EVENT_CHOICES = [
        (LOGIN, "Login"),
        (OVER_LIMIT, "12 Hours Exceeded"),
        (REPORT_SENT, "Report Sent"),
        (REPORT_FAILED, "Report Failed"),
        (LOGOUT, "Logout"),
    ]

    session = models.ForeignKey(Session, related_name="timeline", on_delete=models.CASCADE)
    event_type = models.CharField(max_length=20, choices=EVENT_CHOICES)
    event_time = models.DateTimeField()
    description = models.CharField(max_length=255, blank=True, default="")

    class Meta:
        ordering = ["event_time"]
        indexes = [models.Index(fields=["session", "event_time"])]

    def __str__(self):
        return f"{self.session_id}:{self.event_type}@{self.event_time}"

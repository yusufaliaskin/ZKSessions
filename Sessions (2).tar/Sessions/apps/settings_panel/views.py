from django.conf import settings as django_settings
from django.contrib import messages
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import Group
from django.shortcuts import get_object_or_404, redirect, render

from apps.accounts.decorators import administrator_required
from apps.accounts.roles import ADMINISTRATOR, ALL_ROLES, OPERATOR, VIEWER, user_role
from apps.audit.adapters.factory import get_audit_reader, reset_audit_reader_cache
from apps.reporting.services.email_service import EmailReportService

from .forms import SystemFullConfigForm, UserAccountCreateForm, UserAccountEditForm
from .models import SystemSettings

User = get_user_model()


def _mask(value: str) -> str:
    if not value:
        return "(Yapılandırılmamış)"
    if len(value) <= 4:
        return "•" * len(value)
    return value[:2] + "•" * (len(value) - 4) + value[-2:]


def _assign_user_role(user, role_name: str):
    """Syncs Django User superuser/staff flags and Group membership according to role."""
    for r in ALL_ROLES:
        Group.objects.get_or_create(name=r)

    user.groups.remove(*Group.objects.filter(name__in=ALL_ROLES))

    if role_name == ADMINISTRATOR:
        user.is_superuser = True
        user.is_staff = True
        g = Group.objects.get(name=ADMINISTRATOR)
        user.groups.add(g)
    elif role_name == OPERATOR:
        user.is_superuser = False
        user.is_staff = True
        g = Group.objects.get(name=OPERATOR)
        user.groups.add(g)
    else:  # VIEWER
        user.is_superuser = False
        user.is_staff = False
        g = Group.objects.get(name=VIEWER)
        user.groups.add(g)
    user.save()


@login_required
@administrator_required
def index(request):
    """Unified single-hub administration & configuration center."""
    system_settings = SystemSettings.load()

    if request.method == "POST":
        action = request.POST.get("action", "save_settings")
        
        if action == "test_smtp":
            custom_recipient = request.POST.get("test_recipient", "").strip() or None
            success, msg = EmailReportService.send_test_email(recipient=custom_recipient)
            if success:
                messages.success(request, f"SMTP Testi Başarılı: {msg}")
            else:
                messages.error(request, f"SMTP Testi Hatası: {msg}")
            return redirect("settings_panel:index")

        elif action == "test_audit":
            reset_audit_reader_cache()
            reader = get_audit_reader()
            try:
                is_connected = reader.check_connection()
                if is_connected:
                    messages.success(request, f"Audit Bağlantısı Başarılı: {reader.__class__.__name__} üzerinden başarıyla doğrulandı.")
                else:
                    messages.error(request, f"Audit Bağlantısı Başarısız: {reader.__class__.__name__} ile bağlantı kurulamadı.")
            except Exception as exc:
                messages.error(request, f"Audit Bağlantı Hatası: {exc}")
            return redirect("settings_panel:index")

        else:
            form = SystemFullConfigForm(request.POST, instance=system_settings)
            if form.is_valid():
                obj = form.save(commit=False)
                obj.updated_by = request.user.get_username()
                obj.save()
                messages.success(request, "Tüm sistem yapılandırması (Eşikler, SMTP ve Audit) başarıyla güncellendi.")
                return redirect("settings_panel:index")
    else:
        form = SystemFullConfigForm(instance=system_settings)

    smtp_info = {
        "host": system_settings.smtp_host or django_settings.EMAIL_HOST or "(Yapılandırılmamış)",
        "port": system_settings.smtp_port or django_settings.EMAIL_PORT,
        "username": _mask(system_settings.smtp_user or django_settings.EMAIL_HOST_USER),
        "from_email": system_settings.smtp_from_email or django_settings.DEFAULT_FROM_EMAIL or "(Yapılandırılmamış)",
        "recipients": system_settings.smtp_recipients or ", ".join(django_settings.SESSION_REPORT_RECIPIENTS) or "(Yapılandırılmamış)",
        "use_tls": system_settings.smtp_use_tls,
        "use_ssl": system_settings.smtp_use_ssl,
    }
    audit_info = {
        "backend": system_settings.audit_backend or django_settings.AUDIT_BACKEND,
        "host": system_settings.audit_host or django_settings.AUDIT_HOST or "(Yapılandırılmamış / Mock Adaptör)",
        "port": system_settings.audit_port or django_settings.AUDIT_PORT or "-",
        "username": _mask(system_settings.audit_username or django_settings.AUDIT_USERNAME),
        "db_name": system_settings.audit_db_name or getattr(django_settings, "AUDIT_DB_NAME", "") or "-",
        "api_url": system_settings.audit_api_url or getattr(django_settings, "AUDIT_API_URL", "") or "-",
    }

    return render(request, "dashboard/settings/index.html", {
        "form": form,
        "system_settings": system_settings,
        "smtp_info": smtp_info,
        "audit_info": audit_info,
        "active_page": "system-settings",
    })


# ============================================================================
# Admin-Only Account Management Views
# ============================================================================

@login_required
@administrator_required
def account_list(request):
    """Lists all system portal user accounts with their assigned roles."""
    users_qs = User.objects.all().order_by("-is_superuser", "username")
    accounts_data = []
    for u in users_qs:
        role_label = user_role(u)
        accounts_data.append({
            "user": u,
            "role": role_label,
            "is_self": u.pk == request.user.pk,
        })

    return render(request, "dashboard/settings/accounts/list.html", {
        "accounts": accounts_data,
        "total_accounts": users_qs.count(),
        "active_page": "system-accounts",
    })


@login_required
@administrator_required
def account_create(request):
    """Provisions a new portal user account with role selection."""
    if request.method == "POST":
        form = UserAccountCreateForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data["username"]
            email = form.cleaned_data.get("email", "")
            first_name = form.cleaned_data.get("first_name", "")
            last_name = form.cleaned_data.get("last_name", "")
            password = form.cleaned_data["password"]
            role = form.cleaned_data["role"]
            is_active = form.cleaned_data.get("is_active", True)

            new_user = User.objects.create_user(
                username=username,
                email=email,
                password=password,
                first_name=first_name,
                last_name=last_name,
                is_active=is_active,
            )
            _assign_user_role(new_user, role)
            messages.success(request, f"'{username}' hesabı ({role} rolü ile) başarıyla oluşturuldu.")
            return redirect("settings_panel:account_list")
    else:
        form = UserAccountCreateForm()

    return render(request, "dashboard/settings/accounts/form.html", {
        "form": form,
        "is_edit": False,
        "title": "Yeni Hesap Tanımla",
        "active_page": "system-accounts",
    })


@login_required
@administrator_required
def account_edit(request, pk):
    """Edits an existing user account's profile, role, password, and active status."""
    target_user = get_object_or_404(User, pk=pk)

    if request.method == "POST":
        form = UserAccountEditForm(request.POST, user_instance=target_user)
        if form.is_valid():
            target_user.username = form.cleaned_data["username"]
            target_user.email = form.cleaned_data.get("email", "")
            target_user.first_name = form.cleaned_data.get("first_name", "")
            target_user.last_name = form.cleaned_data.get("last_name", "")
            target_user.is_active = form.cleaned_data.get("is_active", True)

            new_pwd = form.cleaned_data.get("new_password")
            if new_pwd:
                target_user.set_password(new_pwd)

            role = form.cleaned_data["role"]
            _assign_user_role(target_user, role)
            target_user.save()

            messages.success(request, f"'{target_user.username}' hesabı başarıyla güncellendi.")
            return redirect("settings_panel:account_list")
    else:
        current_role = user_role(target_user) or VIEWER
        form = UserAccountEditForm(
            initial={
                "username": target_user.username,
                "first_name": target_user.first_name,
                "last_name": target_user.last_name,
                "email": target_user.email,
                "role": current_role,
                "is_active": target_user.is_active,
            },
            user_instance=target_user,
        )

    return render(request, "dashboard/settings/accounts/form.html", {
        "form": form,
        "is_edit": True,
        "target_user": target_user,
        "title": f"Hesabı Düzenle: {target_user.username}",
        "active_page": "system-accounts",
    })


@login_required
@administrator_required
def account_toggle_status(request, pk):
    """Quickly toggle active/inactive status for a user."""
    target_user = get_object_or_404(User, pk=pk)
    if target_user.pk == request.user.pk:
        messages.error(request, "Kendi hesabınızı pasife alamazsınız.")
        return redirect("settings_panel:account_list")

    target_user.is_active = not target_user.is_active
    target_user.save(update_fields=["is_active"])
    status_str = "aktif edildi" if target_user.is_active else "donduruldu (pasif)"
    messages.success(request, f"'{target_user.username}' hesabı {status_str}.")
    return redirect("settings_panel:account_list")


@login_required
@administrator_required
def account_delete(request, pk):
    """Safely delete a user account."""
    target_user = get_object_or_404(User, pk=pk)
    if target_user.pk == request.user.pk:
        messages.error(request, "Kendi hesabınızı silemezsiniz.")
        return redirect("settings_panel:account_list")

    if target_user.username == "ya550047":
        messages.error(request, "Ana yönetici hesabı (ya550047) silinemez.")
        return redirect("settings_panel:account_list")

    deleted_name = target_user.username
    target_user.delete()
    messages.success(request, f"'{deleted_name}' hesabı sistemden kalıcı olarak silindi.")
    return redirect("settings_panel:account_list")

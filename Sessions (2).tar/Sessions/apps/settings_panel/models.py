"""
Operational & Dynamic configuration settings editable from the dashboard.
Allows changing SMTP, Audit, and threshold configurations dynamically without code changes.
"""
from django.conf import settings
from django.db import models


class SystemSettings(models.Model):
    # Monitoring & Limits
    session_limit_hours = models.PositiveIntegerField(default=12)
    monitor_interval_seconds = models.PositiveIntegerField(default=3600)

    # Dynamic SMTP Configuration
    smtp_host = models.CharField(max_length=255, blank=True, default="")
    smtp_port = models.PositiveIntegerField(default=587)
    smtp_user = models.CharField(max_length=255, blank=True, default="")
    smtp_password = models.CharField(max_length=255, blank=True, default="")
    smtp_from_email = models.CharField(max_length=255, blank=True, default="")
    smtp_recipients = models.TextField(blank=True, default="")
    smtp_use_tls = models.BooleanField(default=True)
    smtp_use_ssl = models.BooleanField(default=False)

    # Dynamic Audit Configuration
    audit_backend = models.CharField(
        max_length=255,
        blank=True,
        default="apps.audit.adapters.mock_adapter.MockAuditReader",
    )
    audit_host = models.CharField(max_length=255, blank=True, default="")
    audit_port = models.PositiveIntegerField(default=3306, null=True, blank=True)
    audit_username = models.CharField(max_length=255, blank=True, default="")
    audit_password = models.CharField(max_length=255, blank=True, default="")
    audit_db_name = models.CharField(max_length=255, blank=True, default="")
    audit_api_url = models.CharField(max_length=255, blank=True, default="")
    audit_api_token = models.CharField(max_length=255, blank=True, default="")

    updated_at = models.DateTimeField(auto_now=True)
    updated_by = models.CharField(max_length=150, blank=True, default="")

    class Meta:
        verbose_name = "System Settings"
        verbose_name_plural = "System Settings"

    def __str__(self):
        return "System Settings"

    def save(self, *args, **kwargs):
        self.pk = 1  # enforce singleton
        super().save(*args, **kwargs)

    @classmethod
    def load(cls) -> "SystemSettings":
        recipients_str = ", ".join(getattr(settings, "SESSION_REPORT_RECIPIENTS", []))
        obj, _ = cls.objects.get_or_create(
            pk=1,
            defaults={
                "session_limit_hours": getattr(settings, "SESSION_LIMIT_HOURS", 12),
                "monitor_interval_seconds": getattr(settings, "MONITOR_INTERVAL", 3600),
                "smtp_host": getattr(settings, "EMAIL_HOST", "") or "",
                "smtp_port": getattr(settings, "EMAIL_PORT", 587) or 587,
                "smtp_user": getattr(settings, "EMAIL_HOST_USER", "") or "",
                "smtp_from_email": getattr(settings, "DEFAULT_FROM_EMAIL", "") or "",
                "smtp_recipients": recipients_str,
                "smtp_use_tls": getattr(settings, "EMAIL_USE_TLS", True),
                "smtp_use_ssl": getattr(settings, "EMAIL_USE_SSL", False),
                "audit_backend": getattr(settings, "AUDIT_BACKEND", "apps.audit.adapters.mock_adapter.MockAuditReader"),
                "audit_host": getattr(settings, "AUDIT_HOST", "") or "",
                "audit_port": getattr(settings, "AUDIT_PORT", 3306) or 3306,
                "audit_username": getattr(settings, "AUDIT_USERNAME", "") or "",
                "audit_db_name": getattr(settings, "AUDIT_DB_NAME", "") or "",
                "audit_api_url": getattr(settings, "AUDIT_API_URL", "") or "",
            },
        )
        return obj

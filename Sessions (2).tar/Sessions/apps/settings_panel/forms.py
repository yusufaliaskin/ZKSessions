from django import forms
from .models import SystemSettings


class SystemSettingsForm(forms.ModelForm):
    monitor_interval_hours = forms.IntegerField(
        label="Tarama Periyodu (Saat)",
        min_value=1,
        max_value=168,
        widget=forms.NumberInput(attrs={
            "class": "custom-settings-input",
            "step": "1",
            "min": "1",
            "placeholder": "1",
        }),
    )

    class Meta:
        model = SystemSettings
        fields = ["session_limit_hours"]
        widgets = {
            "session_limit_hours": forms.NumberInput(attrs={
                "class": "custom-settings-input",
                "min": 1,
                "max": 168,
                "placeholder": "12",
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance and self.instance.pk:
            secs = self.instance.monitor_interval_seconds or 3600
            hours = max(1, int(round(secs / 3600.0)))
            self.fields["monitor_interval_hours"].initial = hours
            self.initial["monitor_interval_hours"] = hours

    def save(self, commit=True):
        instance = super().save(commit=False)
        hours = self.cleaned_data.get("monitor_interval_hours")
        if hours is not None:
            instance.monitor_interval_seconds = int(hours * 3600)
        if commit:
            instance.save()
        return instance


class SystemFullConfigForm(forms.ModelForm):
    monitor_interval_hours = forms.IntegerField(
        label="Tarama Periyodu (Saat)",
        min_value=1,
        max_value=168,
        widget=forms.NumberInput(attrs={
            "class": "custom-settings-input",
            "step": "1",
            "min": "1",
            "placeholder": "1",
        }),
    )

    class Meta:
        model = SystemSettings
        fields = [
            "session_limit_hours",
            "smtp_host",
            "smtp_port",
            "smtp_user",
            "smtp_password",
            "smtp_from_email",
            "smtp_recipients",
            "smtp_use_tls",
            "smtp_use_ssl",
            "audit_backend",
            "audit_host",
            "audit_port",
            "audit_username",
            "audit_password",
            "audit_db_name",
            "audit_api_url",
            "audit_api_token",
        ]
        widgets = {
            "session_limit_hours": forms.NumberInput(attrs={"class": "custom-settings-input", "min": 1, "max": 168}),
            "smtp_host": forms.TextInput(attrs={"class": "custom-settings-input", "placeholder": "mail.ziraatkatilim.com.tr"}),
            "smtp_port": forms.NumberInput(attrs={"class": "custom-settings-input", "placeholder": "587"}),
            "smtp_user": forms.TextInput(attrs={"class": "custom-settings-input", "placeholder": "session.alert@ziraatkatilim.com.tr"}),
            "smtp_password": forms.PasswordInput(attrs={"class": "custom-settings-input", "placeholder": "••••••••", "render_value": True}),
            "smtp_from_email": forms.TextInput(attrs={"class": "custom-settings-input", "placeholder": "session.alert@ziraatkatilim.com.tr"}),
            "smtp_recipients": forms.Textarea(attrs={"class": "custom-settings-input", "rows": 2, "style": "height:60px;padding:8px 12px;", "placeholder": "soc.alert@ziraatkatilim.com.tr, admin@ziraatkatilim.com.tr"}),
            "smtp_use_tls": forms.CheckboxInput(attrs={"style": "width:18px;height:18px;cursor:pointer;"}),
            "smtp_use_ssl": forms.CheckboxInput(attrs={"style": "width:18px;height:18px;cursor:pointer;"}),
            "audit_backend": forms.TextInput(attrs={"class": "custom-settings-input", "placeholder": "apps.audit.adapters.mock_adapter.MockAuditReader"}),
            "audit_host": forms.TextInput(attrs={"class": "custom-settings-input", "placeholder": "10.20.30.40 veya audit.internal"}),
            "audit_port": forms.NumberInput(attrs={"class": "custom-settings-input", "placeholder": "3306"}),
            "audit_username": forms.TextInput(attrs={"class": "custom-settings-input", "placeholder": "audit_reader"}),
            "audit_password": forms.PasswordInput(attrs={"class": "custom-settings-input", "placeholder": "••••••••", "render_value": True}),
            "audit_db_name": forms.TextInput(attrs={"class": "custom-settings-input", "placeholder": "bank_audit_events"}),
            "audit_api_url": forms.TextInput(attrs={"class": "custom-settings-input", "placeholder": "https://audit-gateway.internal/api/v1/events"}),
            "audit_api_token": forms.PasswordInput(attrs={"class": "custom-settings-input", "placeholder": "••••••••", "render_value": True}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance and self.instance.pk:
            secs = self.instance.monitor_interval_seconds or 3600
            hours = max(1, int(round(secs / 3600.0)))
            self.fields["monitor_interval_hours"].initial = hours
            self.initial["monitor_interval_hours"] = hours

    def save(self, commit=True):
        instance = super().save(commit=False)
        hours = self.cleaned_data.get("monitor_interval_hours")
        if hours is not None:
            instance.monitor_interval_seconds = int(hours * 3600)
        if commit:
            instance.save()
        return instance


class UserAccountCreateForm(forms.Form):
    """Admin-only form to provision a new user account with role selection."""
    username = forms.CharField(
        label="Sicil No / Kullanıcı Adı",
        max_length=150,
        widget=forms.TextInput(attrs={
            "class": "custom-settings-input",
            "placeholder": "Örn: ya550047 veya ahmet.yilmaz",
            "autocomplete": "off",
            "spellcheck": "false",
        }),
    )
    first_name = forms.CharField(
        label="Ad",
        max_length=150,
        required=False,
        widget=forms.TextInput(attrs={"class": "custom-settings-input", "placeholder": "Adı", "autocomplete": "off"}),
    )
    last_name = forms.CharField(
        label="Soyad",
        max_length=150,
        required=False,
        widget=forms.TextInput(attrs={"class": "custom-settings-input", "placeholder": "Soyadı", "autocomplete": "off"}),
    )
    email = forms.EmailField(
        label="Kurumsal E-Posta",
        required=False,
        widget=forms.EmailInput(attrs={
            "class": "custom-settings-input",
            "placeholder": "ad.soyad@ziraatkatilim.com.tr",
            "autocomplete": "off",
            "spellcheck": "false",
        }),
    )
    role = forms.ChoiceField(
        label="Sistem Rolü & Yetkilendirme",
        choices=[
            ("Administrator", "Yönetici (Administrator) — Tam Yetkili, Ayarları ve Hesapları Yönetir"),
            ("Operator", "Güvenlik Analisti (Operator) — Oturumları, Alarmları ve Audit Loglarını İzler"),
            ("Viewer", "İzleyici (Viewer) — Salt-Okunur Dashboard & İzleme"),
        ],
        widget=forms.Select(attrs={"class": "custom-settings-input"}),
    )
    password = forms.CharField(
        label="Hesap Parolası",
        widget=forms.PasswordInput(attrs={"class": "custom-settings-input", "placeholder": "••••••••", "autocomplete": "new-password"}),
    )
    password_confirm = forms.CharField(
        label="Parola Tekrarı",
        widget=forms.PasswordInput(attrs={"class": "custom-settings-input", "placeholder": "••••••••", "autocomplete": "new-password"}),
    )
    is_active = forms.BooleanField(
        label="Hesap Aktif",
        initial=True,
        required=False,
        widget=forms.CheckboxInput(attrs={"style": "width:18px;height:18px;cursor:pointer;"}),
    )

    def clean_username(self):
        from django.contrib.auth import get_user_model
        User = get_user_model()
        username = self.cleaned_data["username"].strip()
        if User.objects.filter(username__iexact=username).exists():
            raise forms.ValidationError("Bu kullanıcı adı / sicil numarası ile kayıtlı bir hesap zaten var.")
        return username

    def clean(self):
        cleaned_data = super().clean()
        p1 = cleaned_data.get("password")
        p2 = cleaned_data.get("password_confirm")
        if p1 and p2 and p1 != p2:
            raise forms.ValidationError("Girdiğiniz parolalar birbiriyle eşleşmiyor.")
        return cleaned_data


class UserAccountEditForm(forms.Form):
    """Admin-only form to edit an existing user account."""
    username = forms.CharField(
        label="Sicil No / Kullanıcı Adı",
        max_length=150,
        widget=forms.TextInput(attrs={"class": "custom-settings-input", "autocomplete": "off", "spellcheck": "false"}),
    )
    first_name = forms.CharField(
        label="Ad",
        max_length=150,
        required=False,
        widget=forms.TextInput(attrs={"class": "custom-settings-input", "autocomplete": "off"}),
    )
    last_name = forms.CharField(
        label="Soyad",
        max_length=150,
        required=False,
        widget=forms.TextInput(attrs={"class": "custom-settings-input", "autocomplete": "off"}),
    )
    email = forms.EmailField(
        label="Kurumsal E-Posta",
        required=False,
        widget=forms.EmailInput(attrs={"class": "custom-settings-input", "autocomplete": "off", "spellcheck": "false"}),
    )
    role = forms.ChoiceField(
        label="Sistem Rolü & Yetkilendirme",
        choices=[
            ("Administrator", "Yönetici (Administrator) — Tam Yetkili, Ayarları ve Hesapları Yönetir"),
            ("Operator", "Güvenlik Analisti (Operator) — Oturumları, Alarmları ve Audit Loglarını İzler"),
            ("Viewer", "İzleyici (Viewer) — Salt-Okunur Dashboard & İzleme"),
        ],
        widget=forms.Select(attrs={"class": "custom-settings-input"}),
    )
    new_password = forms.CharField(
        label="Yeni Parola (Değiştirmek istemiyorsanız boş bırakın)",
        required=False,
        widget=forms.PasswordInput(attrs={"class": "custom-settings-input", "placeholder": "Değiştirmek için yeni parola yazın", "autocomplete": "new-password"}),
    )
    is_active = forms.BooleanField(
        label="Hesap Aktif",
        required=False,
        widget=forms.CheckboxInput(attrs={"style": "width:18px;height:18px;cursor:pointer;"}),
    )

    def __init__(self, *args, user_instance=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.user_instance = user_instance

    def clean_username(self):
        from django.contrib.auth import get_user_model
        User = get_user_model()
        username = self.cleaned_data["username"].strip()
        qs = User.objects.filter(username__iexact=username)
        if self.user_instance:
            qs = qs.exclude(pk=self.user_instance.pk)
        if qs.exists():
            raise forms.ValidationError("Bu kullanıcı adı / sicil numarası ile kayıtlı başka bir hesap var.")
        return username

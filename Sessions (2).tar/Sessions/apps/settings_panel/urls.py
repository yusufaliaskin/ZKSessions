from django.urls import path

from . import views

app_name = "settings_panel"

urlpatterns = [
    path("", views.index, name="index"),
    path("config/", views.index, name="config"),
    
    # Account Management
    path("accounts/", views.account_list, name="account_list"),
    path("accounts/create/", views.account_create, name="account_create"),
    path("accounts/<int:pk>/edit/", views.account_edit, name="account_edit"),
    path("accounts/<int:pk>/toggle-status/", views.account_toggle_status, name="account_toggle_status"),
    path("accounts/<int:pk>/delete/", views.account_delete, name="account_delete"),
]

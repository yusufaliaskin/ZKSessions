"""Shared helpers for dashboard views: pagination, search, severity."""
from django.core.paginator import Paginator
from django.utils import timezone


def paginate(request, queryset, per_page=20):
    page_number = request.GET.get("page", 1)
    paginator = Paginator(queryset, per_page)
    return paginator.get_page(page_number)


def apply_search(queryset, request, fields):
    query = request.GET.get("q", "").strip()
    if not query:
        return queryset
    from django.db.models import Q

    condition = Q()
    for field in fields:
        condition |= Q(**{f"{field}__icontains": query})
    return queryset.filter(condition)


def apply_ordering(queryset, request, allowed_fields, default="-login_time"):
    ordering = request.GET.get("sort", default)
    field_name = ordering.lstrip("-")
    if field_name not in allowed_fields:
        ordering = default
    return queryset.order_by(ordering)


def severity_for_duration(duration, limit_hours):
    """Visual-only severity classification (section 49/88) — never used to
    decide business logic, purely for UI color coding."""
    hours = duration.total_seconds() / 3600
    if hours < limit_hours:
        return "green"
    if hours < limit_hours * 2:
        return "orange"
    return "red"


def format_duration(duration):
    total_seconds = int(duration.total_seconds())
    hours, remainder = divmod(total_seconds, 3600)
    minutes, _ = divmod(remainder, 60)
    return f"{hours}h {minutes}m"


def apply_date_filter(queryset, request, date_field="login_time"):
    """
    Applies pre-set (today, 24h, 7d, 30d) or custom range (start_date, end_date)
    filtering on the specified date_field.
    """
    from datetime import datetime, time
    from django.utils import timezone

    now = timezone.now()
    date_preset = request.GET.get("date", "").strip()
    start_date_str = request.GET.get("start_date", "").strip()
    end_date_str = request.GET.get("end_date", "").strip()

    if date_preset == "today":
        return queryset.filter(**{f"{date_field}__date": now.date()})
    elif date_preset == "24h":
        return queryset.filter(**{f"{date_field}__gte": now - timezone.timedelta(hours=24)})
    elif date_preset == "7d":
        return queryset.filter(**{f"{date_field}__gte": now - timezone.timedelta(days=7)})
    elif date_preset == "30d":
        return queryset.filter(**{f"{date_field}__gte": now - timezone.timedelta(days=30)})

    # Custom Date Range
    if start_date_str:
        try:
            sd = datetime.strptime(start_date_str, "%Y-%m-%d")
            sd_aware = timezone.make_aware(datetime.combine(sd.date(), time.min))
            queryset = queryset.filter(**{f"{date_field}__gte": sd_aware})
        except Exception:
            pass

    if end_date_str:
        try:
            ed = datetime.strptime(end_date_str, "%Y-%m-%d")
            ed_aware = timezone.make_aware(datetime.combine(ed.date(), time.max))
            queryset = queryset.filter(**{f"{date_field}__lte": ed_aware})
        except Exception:
            pass

    return queryset


def now():
    return timezone.now()

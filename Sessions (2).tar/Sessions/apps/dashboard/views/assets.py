import csv
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import Count, Max, Q
from django.http import HttpResponse, JsonResponse
from django.shortcuts import redirect, render
from django.views.decorators.http import require_POST
from django.utils import timezone


from apps.accounts.decorators import administrator_required
from apps.sessions.models import Session
from apps.system_status.services import get_system_status

from ..utils import apply_search, format_duration, paginate, severity_for_duration


@login_required
def computers(request):
    limit_hours = get_system_status()["session_limit_hours"]
    queryset = (
        Session.objects.values("computer_name")
        .annotate(
            active_sessions=Count("id", filter=Q(logout_time__isnull=True)),
            total_sessions=Count("id"),
            last_login=Max("login_time"),
        )
        .order_by("-active_sessions", "computer_name")
    )
    queryset = apply_search(queryset, request, ["computer_name"])
    page_obj = paginate(request, queryset, per_page=20)

    over_limit_by_computer = dict(
        Session.objects.over_limit(limit_hours)
        .values("computer_name")
        .annotate(c=Count("id"))
        .values_list("computer_name", "c")
    )
    
    comp_names = [r["computer_name"] for r in page_obj]
    recent_by_comp = {}
    for cname in comp_names:
        recent_by_comp[cname] = list(
            Session.objects.filter(computer_name=cname)
            .order_by("-login_time")[:3]
            .values("id", "user_name", "sicil", "login_time", "logout_time", "status", "overdue")
        )

    rows = []
    for index, row in enumerate(page_obj, start=1):
        row = dict(row)
        row["pk"] = index
        row["over_limit"] = over_limit_by_computer.get(row["computer_name"], 0)
        row["recent_sessions"] = recent_by_comp.get(row["computer_name"], [])
        rows.append(row)

    return render(request, "dashboard/assets/computers.html", {
        "rows": rows, "page_obj": page_obj, "active_page": "assets-computers", "limit_hours": limit_hours,
    })


@login_required
@administrator_required
@require_POST
def clear_demo_computers(request):
    """Delete only locally seeded preview sessions and their cascading children."""
    deleted_count, _ = Session.objects.filter(is_demo=True).delete()
    messages.success(request, f"Demo verileri temizlendi ({deleted_count} kayıt silindi).")
    return redirect("dashboard:computers")


@login_required
def users(request):
    limit_hours = get_system_status()["session_limit_hours"]
    now = timezone.now()
    tab = request.GET.get("tab", "all")

    # Global KPI stats across all users (Cached / Optimized)
    total_users_count = Session.objects.values("user_name").distinct().count()
    active_users_count = Session.objects.filter(logout_time__isnull=True).values("user_name").distinct().count()
    overdue_unames = set(Session.objects.over_limit(limit_hours).values_list("user_name", flat=True).distinct())
    overdue_users_count = len(overdue_unames)
    sicil_users_count = Session.objects.exclude(sicil="").exclude(sicil__isnull=True).values("user_name").distinct().count()

    base_qs = (
        Session.objects.values("user_name", "sicil")
        .annotate(
            active_sessions=Count("id", filter=Q(logout_time__isnull=True)),
            total_sessions=Count("id"),
            last_login=Max("login_time"),
            last_logout=Max("logout_time"),
        )
        .order_by("-active_sessions", "user_name")
    )

    if tab == "active":
        base_qs = base_qs.filter(active_sessions__gt=0)
    elif tab == "overdue":
        base_qs = base_qs.filter(user_name__in=overdue_unames)

    queryset = apply_search(base_qs, request, ["user_name", "sicil"])
    page_obj = paginate(request, queryset, per_page=20)

    over_limit_by_user = dict(
        Session.objects.over_limit(limit_hours)
        .values("user_name")
        .annotate(c=Count("id"))
        .values_list("user_name", "c")
    )

    user_names = [r["user_name"] for r in page_obj]
    latest_sessions_by_user = {}
    if user_names:
        # Crash-proof single bulk query instead of N separate queries
        latest_sessions = (
            Session.objects.filter(user_name__in=user_names)
            .order_by("user_name", "-login_time")
        )
        for sess in latest_sessions:
            if sess.user_name not in latest_sessions_by_user:
                latest_sessions_by_user[sess.user_name] = sess

    rows = []
    for index, row in enumerate(page_obj, start=1):
        row = dict(row)
        row["pk"] = index
        sess = latest_sessions_by_user.get(row["user_name"])
        row["over_limit"] = over_limit_by_user.get(row["user_name"], 0)
        if sess:
            row["latest_session_id"] = sess.id
            row["computer_name"] = sess.computer_name
            row["is_active"] = sess.is_active
            dur = sess.duration(now=now)
            row["duration"] = format_duration(dur)
            row["severity"] = severity_for_duration(dur, limit_hours) if sess.is_active else "gray"
        else:
            row["latest_session_id"] = None
            row["computer_name"] = "—"
            row["is_active"] = False
            row["duration"] = "—"
            row["severity"] = "gray"
        rows.append(row)

    return render(request, "dashboard/assets/users.html", {
        "rows": rows,
        "page_obj": page_obj,
        "active_page": "assets-users",
        "limit_hours": limit_hours,
        "current_tab": tab,
        "total_users_count": total_users_count,
        "active_users_count": active_users_count,
        "overdue_users_count": overdue_users_count,
        "sicil_users_count": sicil_users_count,
    })


@login_required
def export_users_list(request):
    """Export aggregated users directory list as CSV (UTF-8 BOM) or JSON format."""
    limit_hours = get_system_status()["session_limit_hours"]
    now = timezone.now()
    tab = request.GET.get("tab", "all")
    fmt = request.GET.get("format", "csv").lower()

    overdue_unames = set(Session.objects.over_limit(limit_hours).values_list("user_name", flat=True).distinct())

    base_qs = (
        Session.objects.values("user_name", "sicil")
        .annotate(
            active_sessions=Count("id", filter=Q(logout_time__isnull=True)),
            total_sessions=Count("id"),
            last_login=Max("login_time"),
            last_logout=Max("logout_time"),
        )
        .order_by("-active_sessions", "user_name")
    )

    if tab == "active":
        base_qs = base_qs.filter(active_sessions__gt=0)
    elif tab == "overdue":
        base_qs = base_qs.filter(user_name__in=overdue_unames)

    queryset = apply_search(base_qs, request, ["user_name", "sicil"])

    over_limit_by_user = dict(
        Session.objects.over_limit(limit_hours)
        .values("user_name")
        .annotate(c=Count("id"))
        .values_list("user_name", "c")
    )

    user_names = [r["user_name"] for r in queryset]
    latest_sessions_by_user = {}
    if user_names:
        latest_sessions = (
            Session.objects.filter(user_name__in=user_names)
            .order_by("user_name", "-login_time")
        )
        for sess in latest_sessions:
            if sess.user_name not in latest_sessions_by_user:
                latest_sessions_by_user[sess.user_name] = sess

    if fmt == "json":
        data = {
            "export_time": now.isoformat(),
            "total_users": len(queryset),
            "users": [
                {
                    "user_name": r["user_name"],
                    "sicil": r["sicil"] or "",
                    "active_sessions": r["active_sessions"],
                    "total_sessions": r["total_sessions"],
                    "last_login": r["last_login"].isoformat() if r["last_login"] else None,
                    "last_computer": latest_sessions_by_user[r["user_name"]].computer_name if r["user_name"] in latest_sessions_by_user else None,
                    "over_limit_count": over_limit_by_user.get(r["user_name"], 0),
                    "is_currently_active": r["active_sessions"] > 0,
                }
                for r in queryset
            ]
        }
        response = JsonResponse(data, json_dumps_params={"indent": 2})
        response["Content-Disposition"] = f'attachment; filename="kullanicilar_dizini_{now.strftime("%Y%m%d_%H%M%S")}.json"'
        return response

    # Default CSV with UTF-8 BOM for cross-platform Excel on Windows/Mac/Linux
    response = HttpResponse(content_type="text/csv; charset=utf-8-sig")
    response["Content-Disposition"] = f'attachment; filename="kullanicilar_dizini_{now.strftime("%Y%m%d_%H%M%S")}.csv"'
    writer = csv.writer(response)
    writer.writerow(["Kullanici Adi", "Sicil No", "Son Bagli Cihaz", "Son Giris Zamani", "Aktif Oturum Sayisi", "Toplam Oturum", "12H Asim Sayisi", "Genel Durum"])

    for r in queryset:
        sess = latest_sessions_by_user.get(r["user_name"])
        comp = sess.computer_name if sess else "—"
        last_login_str = r["last_login"].strftime("%d.%m.%Y %H:%M:%S") if r["last_login"] else "—"
        over_count = over_limit_by_user.get(r["user_name"], 0)
        status_str = "AKTİF" if r["active_sessions"] > 0 else "KAPALI"
        writer.writerow([
            r["user_name"],
            r["sicil"] or "—",
            comp,
            last_login_str,
            r["active_sessions"],
            r["total_sessions"],
            over_count,
            status_str,
        ])
    return response


@login_required
def user_detail(request, username):
    """Comprehensive single-page dossier for a user: all sessions, audit logs, computers, and alarms."""
    limit_hours = get_system_status()["session_limit_hours"]
    now = timezone.now()

    sessions_qs = Session.objects.filter(user_name=username).order_by("-login_time")
    if not sessions_qs.exists():
        from django.http import Http404
        raise Http404("Kullanıcı bulunamadı.")

    latest_sess = sessions_qs.first()
    sicil = latest_sess.sicil if latest_sess else ""
    is_active = sessions_qs.filter(logout_time__isnull=True).exists()

    # Formatted session list
    formatted_sessions = []
    over_limit_count = 0
    for sess in sessions_qs:
        dur = sess.duration(now=now)
        is_over = bool(sess.overdue or (sess.is_active and sess.is_over_limit(limit_hours, now=now)))
        if is_over:
            over_limit_count += 1
        formatted_sessions.append({
            "session": sess,
            "duration": format_duration(dur),
            "severity": severity_for_duration(dur, limit_hours) if sess.is_active else "gray",
            "is_over_limit": is_over,
        })

    # Audit events
    from apps.audit.models import AuditEventRecord
    audit_events = AuditEventRecord.objects.filter(user_name=username).order_by("-event_time")[:50]

    # Computers used
    computers_used = (
        sessions_qs.values("computer_name")
        .annotate(total=Count("id"), last_seen=Max("login_time"))
        .order_by("-total")
    )

    # Reports
    from apps.reporting.models import ReportHistory
    reports = ReportHistory.objects.filter(session__user_name=username).order_by("-created_at")[:20]

    context = {
        "username": username,
        "sicil": sicil,
        "is_active": is_active,
        "total_sessions": sessions_qs.count(),
        "over_limit_count": over_limit_count,
        "latest_session": latest_sess,
        "sessions": formatted_sessions,
        "audit_events": audit_events,
        "computers_used": computers_used,
        "reports": reports,
        "limit_hours": limit_hours,
        "active_page": "assets-users",
    }
    return render(request, "dashboard/assets/user_detail.html", context)


@login_required
def export_user_data(request, username):
    """Export all session and telemetry records for a specific user as CSV or JSON."""
    import csv
    from django.http import HttpResponse, JsonResponse, Http404

    sessions_qs = Session.objects.filter(user_name=username).order_by("-login_time")
    if not sessions_qs.exists():
        raise Http404("Kullanıcı bulunamadı.")

    fmt = request.GET.get("format", "csv").lower()
    now = timezone.now()
    limit_hours = get_system_status()["session_limit_hours"]

    if fmt == "json":
        data = {
            "username": username,
            "total_sessions": sessions_qs.count(),
            "export_time": now.isoformat(),
            "sessions": [
                {
                    "session_id": s.session_id,
                    "computer_name": s.computer_name,
                    "sicil": s.sicil,
                    "login_time": s.login_time.isoformat() if s.login_time else None,
                    "logout_time": s.logout_time.isoformat() if s.logout_time else None,
                    "duration": format_duration(s.duration(now=now)),
                    "status": s.get_status_display(),
                    "is_over_limit": bool(s.overdue or (s.is_active and s.is_over_limit(limit_hours, now=now))),
                }
                for s in sessions_qs
            ]
        }
        response = JsonResponse(data, json_dumps_params={"indent": 2})
        response["Content-Disposition"] = f'attachment; filename="kullanici_{username}_oturumlar.json"'
        return response

    # Default CSV
    response = HttpResponse(content_type="text/csv; charset=utf-8-sig")
    response["Content-Disposition"] = f'attachment; filename="kullanici_{username}_oturumlar.csv"'
    writer = csv.writer(response)
    writer.writerow(["Session ID", "Kullanici Adi", "Sicil No", "Cihaz (Host)", "Giris Zamani", "Cikis Zamani", "Sure", "Durum", "12H Asim"])

    for s in sessions_qs:
        dur = s.duration(now=now)
        is_over = bool(s.overdue or (s.is_active and s.is_over_limit(limit_hours, now=now)))
        writer.writerow([
            s.session_id,
            s.user_name,
            s.sicil or "",
            s.computer_name,
            s.login_time.strftime("%d.%m.%Y %H:%M:%S") if s.login_time else "",
            s.logout_time.strftime("%d.%m.%Y %H:%M:%S") if s.logout_time else "Aktif",
            format_duration(dur),
            s.get_status_display(),
            "EVET" if is_over else "HAYIR",
        ])
    return response



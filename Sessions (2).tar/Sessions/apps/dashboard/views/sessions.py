import csv
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.http import Http404, HttpResponse, JsonResponse
from django.shortcuts import render
from django.utils import timezone

from apps.sessions.models import Session
from apps.system_status.services import get_system_status

from ..utils import apply_date_filter, apply_ordering, apply_search, format_duration, paginate, severity_for_duration

SEARCH_FIELDS = ["user_name", "sicil", "computer_name", "session_id"]
SORTABLE_FIELDS = ["login_time", "user_name", "computer_name", "status", "report_time", "logout_time"]


def _render_session_list(request, queryset, title, subtitle, active_page, scope="active"):
    limit_hours = get_system_status()["session_limit_hours"]
    now = timezone.now()

    queryset = apply_search(queryset, request, SEARCH_FIELDS)
    queryset = apply_ordering(queryset, request, SORTABLE_FIELDS)
    queryset = apply_date_filter(queryset, request, "login_time")

    report_filter = request.GET.get("report")
    if report_filter == "reported":
        queryset = queryset.filter(report_send=True)
    elif report_filter == "pending":
        queryset = queryset.filter(report_send=False)
    elif report_filter == "failed":
        queryset = queryset.filter(report_send=False, report_attempts__gt=0)

    page_obj = paginate(request, queryset, per_page=20)

    rows = []
    for session in page_obj:
        duration = session.duration(now=now)
        rows.append({
            "session": session,
            "duration": format_duration(duration),
            "severity": severity_for_duration(duration, limit_hours) if session.is_active else "gray",
        })

    context = {
        "title": title,
        "subtitle": subtitle,
        "rows": rows,
        "page_obj": page_obj,
        "active_page": active_page,
        "scope": scope,
        "limit_hours": limit_hours,
        "total_count": queryset.count(),
        "query_params": request.GET.urlencode(),
    }
    return render(request, "dashboard/sessions/list.html", context)


@login_required
def active_sessions(request):
    return _render_session_list(
        request, Session.objects.active(),
        "Aktif Oturumlar", "Çıkış kaydı bulunmayan tüm canlı istemci oturumları",
        "sessions-active", scope="active"
    )


@login_required
def over_12h_sessions(request):
    limit_hours = get_system_status()["session_limit_hours"]
    qs = Session.objects.over_limit(limit_hours)
    return _render_session_list(
        request, qs,
        "12 Saati Aşan Oturumlar", f"{limit_hours} saatlik zaman aşımı eşiğini aşan kritik aktif oturumlar",
        "sessions-over12h", scope="over12h"
    )


@login_required
def recently_logged_out(request):
    qs = Session.objects.logged_out()
    return _render_session_list(
        request, qs,
        "Kapanan Oturumlar", "Audit kaydı ile güvenli çıkışı doğrulanmış oturumlar",
        "sessions-logged-out", scope="logged_out"
    )


@login_required
def export_sessions(request):
    """Export filtered sessions as CSV or JSON format."""
    scope = request.GET.get("scope", "active")
    limit_hours = get_system_status()["session_limit_hours"]
    now = timezone.now()

    if scope == "over12h":
        queryset = Session.objects.over_limit(limit_hours)
    elif scope == "logged_out":
        queryset = Session.objects.logged_out()
    elif scope == "all":
        queryset = Session.objects.all()
    else:
        queryset = Session.objects.active()

    queryset = apply_search(queryset, request, SEARCH_FIELDS)
    queryset = apply_ordering(queryset, request, SORTABLE_FIELDS)
    queryset = apply_date_filter(queryset, request, "login_time")

    report_filter = request.GET.get("report")
    if report_filter == "reported":
        queryset = queryset.filter(report_send=True)
    elif report_filter == "pending":
        queryset = queryset.filter(report_send=False)
    elif report_filter == "failed":
        queryset = queryset.filter(report_send=False, report_attempts__gt=0)

    fmt = request.GET.get("format", "csv").lower()

    if fmt == "json":
        data = {
            "export_time": now.isoformat(),
            "scope": scope,
            "total_records": queryset.count(),
            "sessions": [
                {
                    "session_id": s.session_id,
                    "user_name": s.user_name,
                    "sicil": s.sicil,
                    "computer_name": s.computer_name,
                    "login_time": s.login_time.isoformat() if s.login_time else None,
                    "logout_time": s.logout_time.isoformat() if s.logout_time else None,
                    "duration": format_duration(s.duration(now=now)),
                    "status": s.get_status_display(),
                    "report_sent": s.report_send,
                    "is_over_limit": bool(s.overdue or (s.is_active and s.is_over_limit(limit_hours, now=now))),
                }
                for s in queryset
            ]
        }
        response = JsonResponse(data, json_dumps_params={"indent": 2})
        response["Content-Disposition"] = f'attachment; filename="oturumlar_{scope}_{now.strftime("%Y%m%d_%H%M%S")}.json"'
        return response

    # Default CSV
    response = HttpResponse(content_type="text/csv; charset=utf-8-sig")
    response["Content-Disposition"] = f'attachment; filename="oturumlar_{scope}_{now.strftime("%Y%m%d_%H%M%S")}.csv"'
    writer = csv.writer(response)
    writer.writerow(["Session ID", "Kullanici", "Sicil", "Cihaz (Host)", "Giris Zamani", "Cikis Zamani", "Sure", "Durum", "Rapor Durumu", f"{limit_hours}h Asim"])

    for s in queryset:
        dur = s.duration(now=now)
        is_over = bool(s.overdue or (s.is_active and s.is_over_limit(limit_hours, now=now)))
        writer.writerow([
            s.session_id,
            s.user_name,
            s.sicil or "",
            s.computer_name,
            s.login_time.strftime("%d.%m.%Y %H:%M:%S") if s.login_time else "",
            s.logout_time.strftime("%d.%m.%Y %H:%M:%S") if s.logout_time else "Aktif",
            format_duration(dur),
            s.get_status_display(),
            "Gönderildi" if s.report_send else "Bekliyor",
            "EVET" if is_over else "HAYIR",
        ])
    return response


@login_required
def session_detail(request, pk):
    try:
        session = Session.objects.prefetch_related("timeline", "reports").get(pk=pk)
    except Session.DoesNotExist:
        raise Http404

    limit_hours = get_system_status()["session_limit_hours"]
    now = timezone.now()
    duration = session.duration(now=now)
    severity = severity_for_duration(duration, limit_hours) if session.is_active else "gray"

    context = {
        "session": session,
        "duration": format_duration(duration),
        "severity": severity,
        "limit_hours": limit_hours,
        "is_overdue": session.overdue,
        "timeline_events": session.timeline.all().order_by("-event_time"),
        "reports": session.reports.all().order_by("-created_at"),
    }

    if request.headers.get("x-requested-with") == "XMLHttpRequest":
        return render(request, "dashboard/sessions/_detail_drawer.html", context)

    return render(request, "dashboard/sessions/detail.html", context)

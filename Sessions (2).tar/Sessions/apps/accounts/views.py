from django.contrib.auth import authenticate, get_user_model, login as auth_login, logout as auth_logout
from django.contrib.auth.forms import AuthenticationForm
from django.shortcuts import redirect, render
from django.utils.http import url_has_allowed_host_and_scheme
from django.urls import reverse_lazy
from django.views import View

User = get_user_model()


class SicilAuthenticationForm(AuthenticationForm):
    """Supports login by Sicil No or Username (case-insensitive)."""
    def clean(self):
        username = self.cleaned_data.get("username")
        password = self.cleaned_data.get("password")
        if username and password:
            u_clean = username.strip()
            # Case-insensitive username match (e.g. ya550047, YA550047, admin)
            user_obj = User.objects.filter(username__iexact=u_clean).first()
            actual_username = user_obj.username if user_obj else u_clean

            self.user_cache = authenticate(self.request, username=actual_username, password=password)
            if self.user_cache is None:
                raise self.get_invalid_login_error()
            else:
                self.confirm_login_allowed(self.user_cache)
        return self.cleaned_data


class LoginView(View):
    template_name = "accounts/login.html"

    def get(self, request):
        if request.user.is_authenticated:
            return redirect("dashboard:index")
        form = SicilAuthenticationForm(request)
        return render(request, self.template_name, {"form": form})

    def post(self, request):
        form = SicilAuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            auth_login(request, user)
            if not request.POST.get("remember_me"):
                request.session.set_expiry(0)
            requested_next = request.POST.get("next") or request.GET.get("next")
            next_url = reverse_lazy("dashboard:index")
            if requested_next and url_has_allowed_host_and_scheme(
                requested_next,
                allowed_hosts={request.get_host()},
                require_https=request.is_secure(),
            ):
                next_url = requested_next
            return redirect(next_url)
        return render(request, self.template_name, {"form": form})


def logout_view(request):
    auth_logout(request)
    return redirect("accounts:login")

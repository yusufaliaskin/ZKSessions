"""Create an idempotent, safe-to-preview set of local dashboard demo rows."""

from datetime import timedelta

from django.core.management.base import BaseCommand
from django.utils import timezone

from apps.sessions.models import Session, SessionTimelineEvent


DEMO_COMPUTERS = [f"ZK990NW{number:04d}" for number in range(731, 741)]


class Command(BaseCommand):
    help = "Create or refresh 10 locally generated demo sessions without contacting audit or SMTP services."

    def handle(self, *args, **options):
        now = timezone.now().replace(second=0, microsecond=0)
        created_count = 0

        for index, computer_name in enumerate(DEMO_COMPUTERS, start=1):
            session_id = f"demo-session-{computer_name.lower()}"
            login_time = now - timedelta(hours=(index * 2) + 1)
            logout_time = None
            overdue = False
            status = Session.STATUS_ACTIVE

            # 1-4: active below limit; 5-7: active over limit; 8-10: closed.
            if 5 <= index <= 7:
                login_time = now - timedelta(hours=12 + index)
                overdue = True
                status = Session.STATUS_OVER_LIMIT
            elif index >= 8:
                logout_time = login_time + timedelta(hours=4 if index == 8 else 14)
                overdue = index != 8
                status = Session.STATUS_LOGGED_OUT

            session, created = Session.objects.update_or_create(
                session_id=session_id,
                defaults={
                    "audit_login_event_id": "",
                    "audit_logout_event_id": "",
                    "user_name": f"demo.kullanici{index:02d}",
                    "sicil": f"DEMO{index:04d}",
                    "computer_name": computer_name,
                    "login_time": login_time,
                    "logout_time": logout_time,
                    "overdue": overdue,
                    "is_demo": True,
                    "report_time": None,
                    "report_send": False,
                    "report_attempts": 0,
                    "last_report_error": "",
                    "status": status,
                    "last_seen": logout_time or now,
                    "last_audit_event_time": logout_time or login_time,
                },
            )
            created_count += int(created)

            SessionTimelineEvent.objects.update_or_create(
                session=session,
                event_type=SessionTimelineEvent.LOGIN,
                defaults={"event_time": login_time, "description": "Demo login created for dashboard preview"},
            )
            if overdue:
                SessionTimelineEvent.objects.update_or_create(
                    session=session,
                    event_type=SessionTimelineEvent.OVER_LIMIT,
                    defaults={
                        "event_time": login_time + timedelta(hours=12),
                        "description": "Demo session exceeded the preview threshold",
                    },
                )
            if logout_time:
                SessionTimelineEvent.objects.update_or_create(
                    session=session,
                    event_type=SessionTimelineEvent.LOGOUT,
                    defaults={"event_time": logout_time, "description": "Demo logout created for dashboard preview"},
                )

        self.stdout.write(self.style.SUCCESS(f"Demo sessions ready: {len(DEMO_COMPUTERS)} total, {created_count} newly created."))

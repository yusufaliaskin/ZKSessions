// Ziraat Katılım — Session Monitor Premium v2.0
// Theme Toggle + 60s Live Polling + Glassmorphism SOC Engine

document.addEventListener("DOMContentLoaded", function () {
  var topbarToggleBtn = document.getElementById("sidebarToggleBtn");
  var themeToggleBtn = document.getElementById("themeToggleBtn");
  var globalPortal = document.getElementById("globalMiniFlyoutPortal");
  var searchInput = document.getElementById("topbarGlobalSearch");
  var searchDropdown = document.getElementById("globalSearchDropdown");

  // =========================================================================
  // 1. Sidebar State from LocalStorage
  // =========================================================================
  try {
    var savedState = localStorage.getItem("zk_sidebar_collapsed");
    if (savedState === "true") {
      document.body.classList.add("sidebar-collapsed");
      document.documentElement.classList.add("sidebar-collapsed");
    } else if (savedState === "false") {
      document.body.classList.remove("sidebar-collapsed");
      document.documentElement.classList.remove("sidebar-collapsed");
    }
  } catch (e) {}

  // =========================================================================
  // 2. Sidebar Collapse/Expand Toggle
  // =========================================================================
  function toggleSidebarRail() {
    var isCollapsed = document.body.classList.toggle("sidebar-collapsed");
    document.documentElement.classList.toggle("sidebar-collapsed", isCollapsed);
    if (globalPortal) hideGlobalPortal();
    try {
      localStorage.setItem("zk_sidebar_collapsed", isCollapsed ? "true" : "false");
    } catch (e) {}
  }

  var sidebarCollapseChevron = document.getElementById("sidebarCollapseChevron");
  var menuFilterInput = document.getElementById("sidebarMenuFilter");

  if (topbarToggleBtn) topbarToggleBtn.addEventListener("click", toggleSidebarRail);
  if (sidebarCollapseChevron) sidebarCollapseChevron.addEventListener("click", toggleSidebarRail);

  // In-menu filter search
  if (menuFilterInput) {
    menuFilterInput.addEventListener("input", function (e) {
      var q = e.target.value.toLowerCase().trim();
      var singleItems = document.querySelectorAll(".tree-single-wrap");
      var groups = document.querySelectorAll(".tree-group");

      if (!q) {
        singleItems.forEach(function (el) { el.style.display = ""; });
        groups.forEach(function (el) {
          el.style.display = "";
          el.querySelectorAll(".tree-sub-item").forEach(function (sub) { sub.style.display = ""; });
        });
        return;
      }

      singleItems.forEach(function (el) {
        var text = el.textContent.toLowerCase();
        el.style.display = text.includes(q) ? "" : "none";
      });

      groups.forEach(function (group) {
        var subItems = group.querySelectorAll(".tree-sub-item");
        var groupHeader = group.querySelector(".tree-group-header");
        var headerText = groupHeader ? groupHeader.textContent.toLowerCase() : "";
        var matchCount = 0;

        subItems.forEach(function (sub) {
          var subText = sub.textContent.toLowerCase();
          if (subText.includes(q) || headerText.includes(q)) {
            sub.style.display = "";
            matchCount++;
          } else {
            sub.style.display = "none";
          }
        });

        if (matchCount > 0 || headerText.includes(q)) {
          group.style.display = "";
          group.classList.add("open");
        } else {
          group.style.display = "none";
        }
      });
    });
  }

  // =========================================================================
  // 3. User Dropdown Menu & Theme Toggle
  // =========================================================================
  var userDropdownTrigger = document.getElementById("userDropdownTrigger");
  var userDropdownMenu = document.getElementById("userDropdownMenu");
  var dropdownThemeToggle = document.getElementById("dropdownThemeToggle");

  if (userDropdownTrigger && userDropdownMenu) {
    userDropdownTrigger.addEventListener("click", function (e) {
      e.stopPropagation();
      var isOpen = userDropdownMenu.classList.toggle("show");
      userDropdownTrigger.classList.toggle("active", isOpen);
    });

    document.addEventListener("click", function (e) {
      if (!userDropdownMenu.contains(e.target) && !userDropdownTrigger.contains(e.target)) {
        userDropdownMenu.classList.remove("show");
        userDropdownTrigger.classList.remove("active");
      }
    });
  }

  function getCurrentTheme() {
    return document.documentElement.getAttribute("data-theme") || "dark";
  }

  var transitionTimeout = null;

  function setTheme(theme, animate) {
    if (animate) {
      if (transitionTimeout) clearTimeout(transitionTimeout);
      document.documentElement.classList.add("theme-transitioning");
    }

    document.documentElement.setAttribute("data-theme", theme);
    try { localStorage.setItem("zk_theme", theme); } catch (e) {}

    // Update dropdown theme icon & label
    var themeIconSlot = document.getElementById("themeIconSlot");
    var themeLabelText = document.getElementById("themeLabelText");
    var miniThemeSwitch = document.getElementById("miniThemeSwitch");

    if (miniThemeSwitch) {
      miniThemeSwitch.classList.toggle("active", theme === "light");
    }

    if (themeIconSlot) {
      if (theme === "dark") {
        themeIconSlot.innerHTML = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>';
        if (themeLabelText) themeLabelText.textContent = "Koyu Tema";
      } else {
        themeIconSlot.innerHTML = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line></svg>';
        if (themeLabelText) themeLabelText.textContent = "Açık Tema";
      }
    }

    // Dispatch custom event for chart re-rendering
    window.dispatchEvent(new Event("themeChanged"));

    if (animate) {
      transitionTimeout = setTimeout(function () {
        document.documentElement.classList.remove("theme-transitioning");
      }, 400);
    }
  }

  if (dropdownThemeToggle) {
    dropdownThemeToggle.addEventListener("click", function (e) {
      e.stopPropagation();
      var current = getCurrentTheme();
      setTheme(current === "dark" ? "light" : "dark", true);
    });
  }

  // Initialize theme on load without triggering transition effect
  setTheme(getCurrentTheme(), false);

  // =========================================================================
  // 4. Global Floating Popover (Collapsed Sidebar)
  // =========================================================================
  var portalHideTimeout = null;

  function showGlobalPortal(triggerEl) {
    if (!document.body.classList.contains("sidebar-collapsed") || !globalPortal) return;
    if (portalHideTimeout) {
      clearTimeout(portalHideTimeout);
      portalHideTimeout = null;
    }

    var rect = triggerEl.getBoundingClientRect();
    var html = "";

    if (triggerEl.hasAttribute("data-portal-title")) {
      var title = triggerEl.getAttribute("data-portal-title");
      var url = triggerEl.getAttribute("data-portal-url");
      var isActive = triggerEl.getAttribute("data-portal-active") === "true";
      html = '<a href="' + url + '" class="global-flyout-item ' + (isActive ? "active" : "") + '">' + title + '</a>';
    } else if (triggerEl.hasAttribute("data-portal-group")) {
      var groupTitle = triggerEl.getAttribute("data-portal-group");
      var subItems = triggerEl.querySelectorAll(".tree-sub-item");
      html = '<div class="global-flyout-title">' + groupTitle + '</div>';
      subItems.forEach(function (sub) {
        var subHref = sub.getAttribute("href");
        var subText = sub.textContent.trim();
        var subActive = sub.classList.contains("active") ? "active" : "";
        html += '<a href="' + subHref + '" class="global-flyout-item ' + subActive + '">' + subText + '</a>';
      });
    }

    if (!html) return;

    globalPortal.innerHTML = html;
    globalPortal.style.left = (rect.right + 14) + "px";
    globalPortal.style.top = rect.top + "px";
    globalPortal.classList.add("visible");
  }

  function scheduleHideGlobalPortal() {
    if (portalHideTimeout) clearTimeout(portalHideTimeout);
    portalHideTimeout = setTimeout(function () {
      hideGlobalPortal();
    }, 140);
  }

  function hideGlobalPortal() {
    if (globalPortal) {
      globalPortal.classList.remove("visible");
      globalPortal.innerHTML = "";
    }
  }

  if (globalPortal) {
    globalPortal.addEventListener("mouseenter", function () {
      if (portalHideTimeout) clearTimeout(portalHideTimeout);
    });
    globalPortal.addEventListener("mouseleave", scheduleHideGlobalPortal);
  }

  var portalTriggers = document.querySelectorAll("[data-portal-title], [data-portal-group]");
  portalTriggers.forEach(function (el) {
    el.addEventListener("mouseenter", function () { showGlobalPortal(el); });
    el.addEventListener("mouseleave", scheduleHideGlobalPortal);
  });

  // =========================================================================
  // 5. Tree Accordion
  // =========================================================================
  document.addEventListener("click", function (e) {
    if (document.body.classList.contains("sidebar-collapsed")) return;

    var header = e.target.closest(".tree-group-header");
    if (!header) return;

    var group = header.closest(".tree-group");
    if (!group) return;

    var isOpen = group.classList.contains("open");

    document.querySelectorAll(".tree-group").forEach(function (g) {
      if (g !== group) g.classList.remove("open");
    });

    if (isOpen) {
      group.classList.remove("open");
    } else {
      group.classList.add("open");
    }
  });

  // =========================================================================
  // 6. Universal Table Sorter
  // =========================================================================
  initUniversalTableSorter();

  // =========================================================================
  // 7. Live Search Autocomplete
  // =========================================================================
  var searchDebounceTimer = null;

  function appendSearchText(parent, tagName, className, value) {
    var element = document.createElement(tagName);
    if (className) element.className = className;
    element.textContent = value || "";
    parent.appendChild(element);
    return element;
  }

  function addSearchLabel(container, label) {
    appendSearchText(container, "div", "search-section-label", label);
  }

  function addSessionSearchResult(container, session) {
    var row = document.createElement("div");
    var badgeClass = session.status_code === "LOGGED_OUT" ? "gray" : (session.status_code === "ACTIVE" ? "blue" : "red");
    row.className = "search-item-row";
    row.tabIndex = 0;
    row.setAttribute("role", "button");
    var open = function () {
      window.location.href = "/assets/users/" + encodeURIComponent(session.user_name) + "/";
      searchDropdown.style.display = "none";
    };
    row.addEventListener("click", open);
    row.addEventListener("keydown", function (event) {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        open();
      }
    });
    appendSearchText(row, "div", "search-avatar-box", (session.user_name || "?").charAt(0).toUpperCase());
    var main = document.createElement("div");
    main.className = "search-item-main";
    var title = document.createElement("div");
    title.className = "search-user-title";
    appendSearchText(title, "b", "", session.user_name);
    appendSearchText(title, "span", "search-user-sicil", " Sicil: " + (session.sicil || "-"));
    main.appendChild(title);
    var device = document.createElement("div");
    device.className = "search-device-line";
    appendSearchText(device, "span", "agent-link", session.computer_name);
    device.appendChild(document.createTextNode(" • Giriş: " + (session.login_time || "-") + " • Süre: "));
    appendSearchText(device, "b", "", session.duration);
    main.appendChild(device);
    row.appendChild(main);
    var end = document.createElement("div");
    end.className = "search-item-end";
    appendSearchText(end, "span", "badge " + badgeClass, session.status);
    appendSearchText(end, "span", "search-arrow-icon", "›");
    row.appendChild(end);
    container.appendChild(row);
  }

  function addAuditSearchResult(container, auditEvent) {
    var row = document.createElement("a");
    var isLogin = auditEvent.event_type === "LOGIN";
    row.href = "/audit/" + encodeURIComponent(auditEvent.id) + "/";
    row.className = "search-item-row audit-row";
    row.addEventListener("click", function () { searchDropdown.style.display = "none"; });
    appendSearchText(row, "div", "search-avatar-box audit " + (isLogin ? "login" : "logout"), isLogin ? "IN" : "OUT");
    var main = document.createElement("div");
    main.className = "search-item-main";
    var title = document.createElement("div");
    title.className = "search-user-title";
    appendSearchText(title, "b", "", auditEvent.user_name);
    appendSearchText(title, "span", "search-user-sicil", " ID: " + (auditEvent.event_id || "").slice(0, 14) + "...");
    main.appendChild(title);
    var device = document.createElement("div");
    device.className = "search-device-line";
    appendSearchText(device, "span", "agent-link", auditEvent.computer_name);
    device.appendChild(document.createTextNode(" • Zaman: " + (auditEvent.event_time || "-")));
    main.appendChild(device);
    row.appendChild(main);
    var end = document.createElement("div");
    end.className = "search-item-end";
    appendSearchText(end, "span", "badge " + (isLogin ? "blue" : "gray"), auditEvent.event_type);
    appendSearchText(end, "span", "search-arrow-icon", "›");
    row.appendChild(end);
    container.appendChild(row);
  }

  if (searchInput && searchDropdown) {
    searchInput.addEventListener("input", function (e) {
      var query = e.target.value.trim();

      if (searchDebounceTimer) clearTimeout(searchDebounceTimer);

      if (query.length < 1) {
        searchDropdown.style.display = "none";
        searchDropdown.innerHTML = "";
        return;
      }

      searchDebounceTimer = setTimeout(function () {
        fetch("/api/quick-search/?q=" + encodeURIComponent(query))
          .then(function (res) { return res.json(); })
          .then(function (data) {
            var sessions = data.sessions || [];
            var auditEvents = data.audit_events || [];

            searchDropdown.replaceChildren();
            if (sessions.length === 0 && auditEvents.length === 0) {
              appendSearchText(searchDropdown, "div", "search-empty-note", '"' + query + '" ile eşleşen sonuç bulunamadı.');
              searchDropdown.style.display = "block";
              return;
            }

            if (sessions.length > 0) {
              addSearchLabel(searchDropdown, "Aktif ve Son Oturumlar (" + sessions.length + ")");
              sessions.forEach(function (session) { addSessionSearchResult(searchDropdown, session); });
            }

            if (auditEvents.length > 0) {
              addSearchLabel(searchDropdown, "Audit Güvenlik Günlükleri (" + auditEvents.length + ")");
              auditEvents.forEach(function (auditEvent) { addAuditSearchResult(searchDropdown, auditEvent); });
            }

            var footer = document.createElement("a");
            footer.href = "/sessions/active/?q=" + encodeURIComponent(query);
            footer.className = "search-dropdown-footer";
            footer.textContent = "Tüm Arama Sonuçlarını İncele →";
            searchDropdown.appendChild(footer);
            searchDropdown.style.display = "block";
          })
          .catch(function () {
            searchDropdown.style.display = "none";
          });
      }, 150);
    });

    document.addEventListener("click", function (e) {
      if (!e.target.closest(".topbar-center-zone")) {
        searchDropdown.style.display = "none";
      }
    });
  }

  // =========================================================================
  // 8. Drawer + Escape Key
  // =========================================================================
  var overlay = document.getElementById("drawer-overlay");
  if (overlay) {
    overlay.addEventListener("click", closeDrawer);
  }
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") {
      closeDrawer();
      if (searchDropdown) searchDropdown.style.display = "none";
    }
  });

  // =========================================================================
  // 9. Initial Charts Render from Real Database State
  // =========================================================================
  var statsEl = document.getElementById("dashboardStatsData");
  if (statsEl) {
    var initActive = statsEl.getAttribute("data-active") || 0;
    var initOver = statsEl.getAttribute("data-overlimit") || 0;
    var initLogged = statsEl.getAttribute("data-loggedout") || 0;
    
    var countsScript = document.getElementById("hourlyCountsJson");
    var labelsScript = document.getElementById("hoursLabelsJson");
    var initCounts = [];
    var initLabels = [];
    try {
      if (countsScript) initCounts = JSON.parse(countsScript.textContent);
      if (labelsScript) initLabels = JSON.parse(labelsScript.textContent);
    } catch(e) {}

    renderSessionActivityChart(initLabels, initCounts);
    renderRealDonutChart(initActive, initOver, initLogged);
  }

  window.addEventListener("zk-theme-changed", function() {
    var sEl = document.getElementById("dashboardStatsData");
    if (sEl) {
      var cScript = document.getElementById("hourlyCountsJson");
      var lScript = document.getElementById("hoursLabelsJson");
      var cData = [];
      var lData = [];
      try {
        if (cScript) cData = JSON.parse(cScript.textContent);
        if (lScript) lData = JSON.parse(lScript.textContent);
      } catch(e) {}

      var a = sEl.getAttribute("data-active") || 0;
      var o = sEl.getAttribute("data-overlimit") || 0;
      var l = sEl.getAttribute("data-loggedout") || 0;

      renderSessionActivityChart(lData, cData);
      renderRealDonutChart(a, o, l);
    }
  });

  // =========================================================================
  // 10. Live Polling — Every 60 seconds (audit real-time)
  // =========================================================================
  setInterval(pollLiveStats, 60000);
});

// ============================================================================
// Universal Table Sorter Engine
// ============================================================================
function initUniversalTableSorter() {
  var tables = document.querySelectorAll(".data-table, .wazuh-siem-table");
  tables.forEach(function (table) {
    var headers = table.querySelectorAll("thead th");
    headers.forEach(function (th, colIndex) {
      var text = th.textContent.trim();
      if (!text || th.classList.contains("no-sort") || th.classList.contains("chevron-col")) return;

      th.classList.add("sortable-th");

      if (!th.querySelector(".sort-indicator-icon")) {
        var span = document.createElement("span");
        span.className = "sort-indicator-icon";
        span.innerHTML = "&#8645;";
        th.appendChild(span);
      }

      th.addEventListener("click", function (e) {
        if (e.target.tagName === "A" || e.target.tagName === "BUTTON") return;

        var tbody = table.querySelector("tbody");
        if (!tbody) return;

        var rows = Array.from(tbody.querySelectorAll("tr"));
        if (rows.length <= 1) return;

        var currentDir = th.getAttribute("data-sort-dir") || "none";
        var newDir = currentDir === "asc" ? "desc" : "asc";

        headers.forEach(function (otherTh) {
          otherTh.removeAttribute("data-sort-dir");
          otherTh.classList.remove("sort-asc", "sort-desc");
          var icon = otherTh.querySelector(".sort-indicator-icon");
          if (icon) icon.innerHTML = "&#8645;";
        });

        th.setAttribute("data-sort-dir", newDir);
        th.classList.add(newDir === "asc" ? "sort-asc" : "sort-desc");
        var icon = th.querySelector(".sort-indicator-icon");
        if (icon) icon.innerHTML = newDir === "asc" ? "&#9650;" : "&#9660;";

        rows.sort(function (rowA, rowB) {
          var cellA = rowA.children[colIndex];
          var cellB = rowB.children[colIndex];
          if (!cellA || !cellB) return 0;

          var valA = cellA.textContent.trim();
          var valB = cellB.textContent.trim();

          var dateA = parseDateTimeString(valA);
          var dateB = parseDateTimeString(valB);
          if (dateA !== null && dateB !== null) {
            return newDir === "asc" ? dateA - dateB : dateB - dateA;
          }

          var numA = parseNumberString(valA);
          var numB = parseNumberString(valB);
          if (numA !== null && numB !== null) {
            return newDir === "asc" ? numA - numB : numB - numA;
          }

          var cmp = valA.localeCompare(valB, "tr", { numeric: true, sensitivity: "base" });
          return newDir === "asc" ? cmp : -cmp;
        });

        rows.forEach(function (row) {
          tbody.appendChild(row);
        });
      });
    });
  });
}

function parseDateTimeString(str) {
  var match = str.match(/^(\d{1,2})\.(\d{1,2})\.(\d{4})(?:\s+(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?$/);
  if (match) {
    var d = parseInt(match[1], 10);
    var m = parseInt(match[2], 10) - 1;
    var y = parseInt(match[3], 10);
    var hh = match[4] ? parseInt(match[4], 10) : 0;
    var mm = match[5] ? parseInt(match[5], 10) : 0;
    var ss = match[6] ? parseInt(match[6], 10) : 0;
    return new Date(y, m, d, hh, mm, ss).getTime();
  }
  return null;
}

function parseNumberString(str) {
  var clean = str.replace(/,/g, "").replace(/[^\d.-]/g, "");
  if (!clean || isNaN(clean)) return null;
  return parseFloat(clean);
}

// ============================================================================
// Live Telemetry
// ============================================================================
function triggerLiveRefresh() {
  var spinIcon = document.getElementById("refreshSpinIcon");
  if (spinIcon) {
    spinIcon.classList.add("refresh-spinning");
    setTimeout(function () {
      spinIcon.classList.remove("refresh-spinning");
    }, 600);
  }
  pollLiveStats(true);
}

function pollLiveStats(isManual) {
  var timeRangeSelect = document.getElementById("dashboardTimeRange");
  var timeRange = timeRangeSelect ? timeRangeSelect.value : "24h";

  fetch("/api/live-stats/?time_range=" + encodeURIComponent(timeRange), {
    headers: { "X-Requested-With": "XMLHttpRequest" }
  })
    .then(function (r) { return r.ok ? r.json() : null; })
    .then(function (data) {
      if (!data) return;

      var kpiActive = document.getElementById("kpiActive");
      var kpiOver = document.getElementById("kpiOverLimit");
      var kpiSent = document.getElementById("kpiSent");
      var kpiTotal = document.getElementById("kpiTotal");

      if (kpiActive && data.active_sessions !== undefined) animateValue(kpiActive, data.active_sessions);
      if (kpiOver && data.over_limit !== undefined) animateValue(kpiOver, data.over_limit);
      if (kpiSent && data.reports_sent !== undefined) animateValue(kpiSent, data.reports_sent);
      if (kpiTotal && data.total_sessions !== undefined) animateValue(kpiTotal, data.total_sessions);

      // Update Donut Graph & Legend
      renderRealDonutChart(data.active_sessions, data.over_limit, data.logged_out_count);
    })
    .catch(function () {});
}

// ============================================================================
// Interactive Chart.js Engines (Session Activity & Real Donut Distribution)
// ============================================================================
var activityChartInstance = null;
var donutChartInstance = null;

function isDarkMode() {
  return document.documentElement.getAttribute("data-theme") === "dark";
}

function renderSessionActivityChart(labels, counts) {
  var canvas = document.getElementById("sessionActivityChart");
  if (!canvas || typeof Chart === "undefined") return;

  var dark = isDarkMode();
  var textColor = dark ? "#94A3B8" : "#64748B";
  var gridColor = dark ? "rgba(255, 255, 255, 0.06)" : "rgba(0, 0, 0, 0.05)";

  var ctx = canvas.getContext("2d");
  
  if (activityChartInstance) {
    activityChartInstance.destroy();
    activityChartInstance = null;
  }

  // Create smooth gradient
  var gradient = ctx.createLinearGradient(0, 0, 0, 180);
  if (dark) {
    gradient.addColorStop(0, "rgba(227, 6, 19, 0.35)");
    gradient.addColorStop(1, "rgba(227, 6, 19, 0.0)");
  } else {
    gradient.addColorStop(0, "rgba(227, 6, 19, 0.20)");
    gradient.addColorStop(1, "rgba(227, 6, 19, 0.0)");
  }

  activityChartInstance = new Chart(ctx, {
    type: "line",
    data: {
      labels: labels && labels.length ? labels : ["00:00"],
      datasets: [
        {
          label: "Oturum / Olay",
          data: counts && counts.length ? counts : [0],
          borderColor: "#E30613",
          borderWidth: 2.5,
          pointBackgroundColor: "#E30613",
          pointBorderColor: dark ? "#111622" : "#FFFFFF",
          pointBorderWidth: 2,
          pointRadius: 4,
          pointHoverRadius: 6,
          pointHoverBackgroundColor: "#FFFFFF",
          pointHoverBorderColor: "#E30613",
          pointHoverBorderWidth: 2.5,
          fill: true,
          backgroundColor: gradient,
          tension: 0.35,
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: {
        duration: 400,
        easing: "easeOutQuart"
      },
      interaction: {
        mode: "index",
        intersect: false
      },
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: dark ? "#1E293B" : "#0F172A",
          titleColor: "#F8FAFC",
          bodyColor: "#CBD5E1",
          padding: 10,
          cornerRadius: 8,
          borderColor: dark ? "rgba(255,255,255,0.12)" : "rgba(0,0,0,0.1)",
          borderWidth: 1,
          displayColors: false,
          callbacks: {
            label: function(context) {
              return " " + context.parsed.y + " Aktif Oturum / Olay";
            }
          }
        }
      },
      scales: {
        x: {
          grid: { display: false },
          ticks: {
            color: textColor,
            font: { size: 11, family: "Inter, sans-serif" },
            maxRotation: 0
          }
        },
        y: {
          beginAtZero: true,
          grid: { color: gridColor },
          ticks: {
            color: textColor,
            font: { size: 11, family: "Inter, sans-serif" },
            precision: 0
          }
        }
      }
    }
  });
}

function renderRealDonutChart(active, overlimit, loggedout) {
  var canvas = document.getElementById("sessionDistributionChart");
  var donutCenter = document.getElementById("donutCenterCount");
  var legActive = document.getElementById("legendActiveCount");
  var legOver = document.getElementById("legendOverlimitCount");
  var legLogged = document.getElementById("legendLoggedoutCount");

  var activeVal = parseInt(active, 10) || 0;
  var overVal = parseInt(overlimit, 10) || 0;
  var loggedVal = parseInt(loggedout, 10) || 0;

  var safeActive = Math.max(0, activeVal - overVal);
  var total = safeActive + overVal + loggedVal;

  if (donutCenter) donutCenter.textContent = activeVal;
  if (legActive) legActive.textContent = "(" + activeVal + ")";
  if (legOver) legOver.textContent = "(" + overVal + ")";
  if (legLogged) legLogged.textContent = "(" + loggedVal + ")";

  if (!canvas || typeof Chart === "undefined") return;

  var dark = isDarkMode();
  var ctx = canvas.getContext("2d");

  if (donutChartInstance) {
    donutChartInstance.destroy();
    donutChartInstance = null;
  }

  var chartData = total > 0 ? [safeActive, overVal, loggedVal] : [0, 0, 1];
  var chartColors = total > 0 ? ["#10B981", "#E30613", "#94A3B8"] : (dark ? ["#1E293B", "#1E293B", "#334155"] : ["#E2E8F0", "#E2E8F0", "#CBD5E1"]);

  donutChartInstance = new Chart(ctx, {
    type: "doughnut",
    data: {
      labels: ["Aktif Oturumlar", "12 Saat Aşım", "Kapanan Oturumlar"],
      datasets: [
        {
          data: chartData,
          backgroundColor: chartColors,
          borderWidth: 0,
          hoverOffset: 6
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: {
        duration: 400,
        easing: "easeOutQuart"
      },
      cutout: "75%",
      plugins: {
        legend: { display: false },
        tooltip: {
          enabled: total > 0,
          backgroundColor: dark ? "#1E293B" : "#0F172A",
          titleColor: "#F8FAFC",
          bodyColor: "#CBD5E1",
          padding: 8,
          cornerRadius: 8,
          displayColors: true,
          callbacks: {
            label: function(context) {
              var val = context.raw || 0;
              var pct = total > 0 ? Math.round((val / total) * 100) : 0;
              return " " + context.label + ": " + val + " (% " + pct + ")";
            }
          }
        }
      }
    }
  });
}

// Dynamic Dashboard Time Filter Handler (Real Backend Audit Querying)
function onDashboardTimeFilterChange(timeRange) {
  var select1 = document.getElementById("dashboardTimeRange");
  var select2 = document.getElementById("donutTimeRangeSelect");

  // Sync both dropdowns
  if (select1 && select1.value !== timeRange) select1.value = timeRange;
  if (select2 && select2.value !== timeRange) select2.value = timeRange;

  fetch("/api/live-stats/?time_range=" + encodeURIComponent(timeRange), {
    headers: { "X-Requested-With": "XMLHttpRequest" }
  })
    .then(function (r) { return r.json(); })
    .then(function (data) {
      if (data) {
        var counts = data.hourly_counts || [];
        var labels = data.hours_labels || [];
        renderSessionActivityChart(labels, counts);
        renderRealDonutChart(data.active_sessions, data.over_limit, data.logged_out_count);
      }
    })
    .catch(function (err) {});
}

// Smooth number animation for KPI values
function animateValue(el, newVal) {
  var currentVal = parseInt(el.textContent, 10) || 0;
  if (currentVal === newVal) return;
  el.textContent = newVal;
  el.style.transition = "transform 0.25s ease, opacity 0.25s ease";
  el.style.transform = "scale(1.08)";
  el.style.opacity = "0.7";
  setTimeout(function() {
    el.style.transform = "scale(1)";
    el.style.opacity = "1";
  }, 250);
}

// ============================================================================
// Expandable Table Accordion for /sessions/active/
// ============================================================================
function toggleSessionAccordion(sessionId) {
  var accordionRow = document.getElementById("accordion-" + sessionId);
  var chevron = document.getElementById("chevron-" + sessionId);
  if (!accordionRow) return;

  var isHidden = accordionRow.style.display === "none" || !accordionRow.style.display;
  if (isHidden) {
    accordionRow.style.display = "table-row";
    if (chevron) chevron.style.transform = "rotate(90deg)";
  } else {
    accordionRow.style.display = "none";
    if (chevron) chevron.style.transform = "rotate(0deg)";
  }
}

// ============================================================================
// Telemetry Modal Tabs Switcher
// ============================================================================
function switchTelemetryTab(btn, tabId) {
  var container = btn.closest(".telemetry-detail-container");
  if (!container) return;

  var allBtns = container.querySelectorAll(".telemetry-tab-btn");
  var allPanes = container.querySelectorAll(".telemetry-tab-pane");

  allBtns.forEach(function (b) { b.classList.remove("active"); });
  allPanes.forEach(function (p) { p.classList.remove("active"); });

  btn.classList.add("active");
  var target = document.getElementById(tabId);
  if (target) target.classList.add("active");
}

// ============================================================================
// Centered Telemetry Modal Functions
// ============================================================================
function openSessionDrawer(sessionId) {
  openDrawer("/sessions/" + sessionId + "/");
}

function openDrawer(url) {
  var drawer = document.getElementById("drawer");
  var overlay = document.getElementById("drawer-overlay");
  var body = document.getElementById("drawer-body-content");
  if (!drawer || !body) return;

  body.innerHTML = '<div class="empty-state" style="padding:40px 20px;">Oturum güvenlik telemetrisi yükleniyor...</div>';
  overlay.classList.add("open");
  drawer.classList.add("open");

  fetch(url, { headers: { "X-Requested-With": "XMLHttpRequest" } })
    .then(function (r) { return r.text(); })
    .then(function (html) { body.innerHTML = html; })
    .catch(function () {
      body.innerHTML = '<div class="empty-state">Oturum detayları yüklenemedi.</div>';
    });
}

function closeDrawer() {
  var drawer = document.getElementById("drawer");
  var overlay = document.getElementById("drawer-overlay");
  if (drawer) drawer.classList.remove("open");
  if (overlay) overlay.classList.remove("open");
}

// Close modal on Escape key or backdrop click
document.addEventListener("keydown", function (e) {
  if (e.key === "Escape") closeDrawer();
});

var drawerOverlay = document.getElementById("drawer-overlay");
if (drawerOverlay) {
  drawerOverlay.addEventListener("click", closeDrawer);
}

// ============================================================================
// Chart & Data Export Handlers (PNG, CSV, JSON)
// ============================================================================
function toggleExportMenu(menuId) {
  var menu = document.getElementById(menuId);
  if (!menu) return;
  
  // Close other open export menus
  document.querySelectorAll(".export-menu-pane").forEach(function(el) {
    if (el.id !== menuId) el.classList.remove("show");
  });

  menu.classList.toggle("show");
}

// Close export menu when clicking outside
document.addEventListener("click", function(e) {
  if (!e.target.closest(".card-export-wrapper")) {
    document.querySelectorAll(".export-menu-pane").forEach(function(el) {
      el.classList.remove("show");
    });
  }
});

function exportChartAsPNG(canvasId, filename) {
  var canvas = document.getElementById(canvasId);
  if (!canvas) return;

  var tempCanvas = document.createElement("canvas");
  tempCanvas.width = canvas.width;
  tempCanvas.height = canvas.height;
  var ctx = tempCanvas.getContext("2d");

  // Solid background
  ctx.fillStyle = isDarkMode() ? "#141926" : "#FFFFFF";
  ctx.fillRect(0, 0, tempCanvas.width, tempCanvas.height);
  ctx.drawImage(canvas, 0, 0);

  var link = document.createElement("a");
  link.download = filename || "chart-export.png";
  link.href = tempCanvas.toDataURL("image/png");
  link.click();
}

function exportActivityAsCSV() {
  var countsScript = document.getElementById("hourlyCountsJson");
  var labelsScript = document.getElementById("hoursLabelsJson");
  var counts = [];
  var labels = [];
  try {
    if (countsScript) counts = JSON.parse(countsScript.textContent);
    if (labelsScript) labels = JSON.parse(labelsScript.textContent);
  } catch(e) {}

  var csvContent = "data:text/csv;charset=utf-8,Zaman Dilimi,Oturum ve Audit Olay Sayisi\n";
  for (var i = 0; i < labels.length; i++) {
    csvContent += '"' + (labels[i] || "") + '",' + (counts[i] || 0) + "\n";
  }

  var encodedUri = encodeURI(csvContent);
  var link = document.createElement("a");
  link.setAttribute("href", encodedUri);
  link.setAttribute("download", "oturum-aktivite-verileri.csv");
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

function exportActivityAsJSON() {
  var countsScript = document.getElementById("hourlyCountsJson");
  var labelsScript = document.getElementById("hoursLabelsJson");
  var counts = [];
  var labels = [];
  try {
    if (countsScript) counts = JSON.parse(countsScript.textContent);
    if (labelsScript) labels = JSON.parse(labelsScript.textContent);
  } catch(e) {}

  var data = [];
  for (var i = 0; i < labels.length; i++) {
    data.push({ time_bucket: labels[i], count: counts[i] || 0 });
  }

  var blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  var link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = "oturum-aktivite-verileri.json";
  link.click();
}

function exportDonutAsCSV() {
  var statsEl = document.getElementById("dashboardStatsData");
  var active = statsEl ? statsEl.getAttribute("data-active") || 0 : 0;
  var overlimit = statsEl ? statsEl.getAttribute("data-overlimit") || 0 : 0;
  var loggedout = statsEl ? statsEl.getAttribute("data-loggedout") || 0 : 0;
  var total = statsEl ? statsEl.getAttribute("data-total") || 0 : 0;

  var csvContent = "data:text/csv;charset=utf-8,Durum Kategorisi,Adet\n";
  csvContent += '"Aktif Oturumlar (Limit Ici)",' + Math.max(0, parseInt(active, 10) - parseInt(overlimit, 10)) + "\n";
  csvContent += '"12 Saat Limit Asimi",' + overlimit + "\n";
  csvContent += '"Kapanan Oturumlar",' + loggedout + "\n";
  csvContent += '"Toplam Gozlem",' + total + "\n";

  var encodedUri = encodeURI(csvContent);
  var link = document.createElement("a");
  link.setAttribute("href", encodedUri);
  link.setAttribute("download", "oturum-durum-dagilimi.csv");
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

function exportDonutAsJSON() {
  var statsEl = document.getElementById("dashboardStatsData");
  var active = statsEl ? statsEl.getAttribute("data-active") || 0 : 0;
  var overlimit = statsEl ? statsEl.getAttribute("data-overlimit") || 0 : 0;
  var loggedout = statsEl ? statsEl.getAttribute("data-loggedout") || 0 : 0;
  var total = statsEl ? statsEl.getAttribute("data-total") || 0 : 0;

  var data = {
    active_within_limit: Math.max(0, parseInt(active, 10) - parseInt(overlimit, 10)),
    over_limit_hours: parseInt(overlimit, 10),
    logged_out: parseInt(loggedout, 10),
    total_sessions: parseInt(total, 10)
  };

  var blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  var link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = "oturum-durum-dagilimi.json";
  link.click();
}

// ============================================================================
// Custom 60FPS Animated Select Dropdown Engine
// ============================================================================
function toggleCustomDropdown(menuId, e) {
  if (e) {
    if (e.stopPropagation) e.stopPropagation();
    if (e.preventDefault) e.preventDefault();
  }
  var menu = document.getElementById(menuId);
  if (!menu) return;

  var isOpen = menu.classList.contains("open");

  // Close all open menus first
  var allMenus = document.querySelectorAll(".custom-select-menu");
  for (var i = 0; i < allMenus.length; i++) {
    allMenus[i].classList.remove("open");
  }
  var allTriggers = document.querySelectorAll(".custom-select-trigger");
  for (var j = 0; j < allTriggers.length; j++) {
    allTriggers[j].classList.remove("active");
  }

  if (!isOpen) {
    menu.classList.add("open");
    var parent = menu.parentElement;
    if (parent) {
      var trigger = parent.querySelector(".custom-select-trigger");
      if (trigger) trigger.classList.add("active");
    }
  }
}

function selectCustomOption(inputId, labelId, value, labelText, menuId, autoSubmit, e) {
  if (e) {
    if (e.stopPropagation) e.stopPropagation();
    if (e.preventDefault) e.preventDefault();
  }
  var input = document.getElementById(inputId);
  var label = document.getElementById(labelId);
  var menu = document.getElementById(menuId);

  if (input) input.value = value;
  if (label) label.textContent = labelText;

  if (menu) {
    var opts = menu.querySelectorAll(".custom-option");
    for (var i = 0; i < opts.length; i++) {
      opts[i].classList.remove("selected");
    }
    if (e && e.currentTarget) {
      e.currentTarget.classList.add("selected");
    }
    menu.classList.remove("open");
    var parent = menu.parentElement;
    if (parent) {
      var trigger = parent.querySelector(".custom-select-trigger");
      if (trigger) trigger.classList.remove("active");
    }
  }

  if (autoSubmit && input && input.form) {
    input.form.submit();
  }
}

document.addEventListener("click", function(e) {
  if (!e.target.closest || !e.target.closest(".custom-select-wrapper")) {
    var allMenus = document.querySelectorAll(".custom-select-menu");
    for (var i = 0; i < allMenus.length; i++) {
      allMenus[i].classList.remove("open");
    }
    var allTriggers = document.querySelectorAll(".custom-select-trigger");
    for (var j = 0; j < allTriggers.length; j++) {
      allTriggers[j].classList.remove("active");
    }
  }
});

// ============================================================================
// Custom Date Range & Table Loading Engine
// ============================================================================
function openCustomDateRangePicker(panelId, e) {
  if (e) {
    if (e.stopPropagation) e.stopPropagation();
    if (e.preventDefault) e.preventDefault();
  }
  var panel = document.getElementById(panelId);
  if (panel) {
    panel.style.display = panel.style.display === "none" ? "block" : "none";
  }
}

function applyCustomDateRange(startInputId, endInputId, hiddenStartId, hiddenEndId, formId, dateFilterInputId, dateLabelId, menuId) {
  var startEl = document.getElementById(startInputId);
  var endEl = document.getElementById(endInputId);
  var hiddenStart = document.getElementById(hiddenStartId);
  var hiddenEnd = document.getElementById(hiddenEndId);
  var datePreset = document.getElementById(dateFilterInputId);
  var dateLabel = document.getElementById(dateLabelId);

  var startVal = startEl ? startEl.value : "";
  var endVal = endEl ? endEl.value : "";

  if (hiddenStart) hiddenStart.value = startVal;
  if (hiddenEnd) hiddenEnd.value = endVal;
  if (datePreset) datePreset.value = "";

  if (dateLabel) {
    if (startVal && endVal) {
      dateLabel.textContent = startVal + " — " + endVal;
    } else if (startVal) {
      dateLabel.textContent = startVal + " Sonrası";
    } else if (endVal) {
      dateLabel.textContent = endVal + " Öncesi";
    } else {
      dateLabel.textContent = "Özel Tarih";
    }
  }

  showTableLoading();

  var form = document.getElementById(formId);
  if (form) {
    form.submit();
  }
}

function showTableLoading(overlayId) {
  var overlay = overlayId ? document.getElementById(overlayId) : document.querySelector(".table-loading-overlay");
  if (overlay) {
    overlay.classList.add("active");
  }
}

document.addEventListener("DOMContentLoaded", function() {
  document.querySelectorAll("form.wazuh-kql-query-bar, form.table-filter-form").forEach(function(f) {
    f.addEventListener("submit", function() {
      showTableLoading();
    });
  });
});



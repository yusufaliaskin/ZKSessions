from django.contrib.auth.models import User
from django.test import TestCase
from django.urls import reverse


class SystemViewsTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_superuser(username="admin", password="password123", email="admin@example.local")
        self.client.login(username="admin", password="password123")

    def test_status_view(self):
        response = self.client.get(reverse("dashboard:system_status"))
        self.assertEqual(response.status_code, 200)
        self.assertIn("status", response.context)


    def test_settings_view(self):
        response = self.client.get(reverse("settings_panel:index"))
        self.assertEqual(response.status_code, 200)
        self.assertIn("smtp_info", response.context)
        self.assertIn("audit_info", response.context)

    def test_system_logs_view(self):
        response = self.client.get(reverse("dashboard:system_logs"))
        self.assertEqual(response.status_code, 200)
        self.assertIn("page_obj", response.context)
        self.assertIn("stats", response.context)


from datetime import timedelta
from pathlib import Path
from unittest.mock import patch

from django.contrib.auth.models import User
from django.core.management import call_command
from django.test import Client, TestCase
from django.urls import reverse
from django.utils import timezone

from apps.monitoring.services.session_monitor import SessionMonitorEngine
from apps.sessions.models import Session


class DemoDataAndSecurityTests(TestCase):
    def session(self, session_id, *, is_demo=False, login_time=None):
        return Session.objects.create(
            session_id=session_id,
            user_name="test.user",
            sicil="TEST0001",
            computer_name="REAL-DEVICE-001",
            login_time=login_time or timezone.now() - timedelta(hours=1),
            is_demo=is_demo,
        )

    def test_demo_seed_is_idempotent_and_uses_expected_computer_names(self):
        call_command("seed_demo_sessions")
        call_command("seed_demo_sessions")

        demo_sessions = Session.objects.filter(is_demo=True).order_by("computer_name")
        self.assertEqual(demo_sessions.count(), 10)
        self.assertEqual(
            list(demo_sessions.values_list("computer_name", flat=True)),
            [f"ZK990NW{number:04d}" for number in range(731, 741)],
        )
        self.assertEqual(demo_sessions.filter(logout_time__isnull=True, overdue=False).count(), 4)
        self.assertEqual(demo_sessions.filter(logout_time__isnull=True, overdue=True).count(), 3)
        self.assertEqual(demo_sessions.filter(logout_time__isnull=False).count(), 3)

    def test_demo_records_never_enter_notification_processing(self):
        self.session("real-over-limit", login_time=timezone.now() - timedelta(hours=13))
        self.session("demo-over-limit", is_demo=True, login_time=timezone.now() - timedelta(hours=14))
        engine = SessionMonitorEngine(limit_hours=12)

        with patch.object(engine.report_service, "send_over_limit_report", return_value=True) as send_report:
            over_limit_count, _, _ = engine._process_over_limit_sessions()

        self.assertEqual(over_limit_count, 1)
        send_report.assert_called_once()
        self.assertFalse(Session.objects.get(session_id="demo-over-limit").overdue)

    def test_demo_clear_requires_administrator_and_preserves_real_records(self):
        call_command("seed_demo_sessions")
        self.session("real-session")
        regular_user = User.objects.create_user(username="viewer", password="password123")
        self.client.login(username="viewer", password="password123")

        response = self.client.post(reverse("dashboard:clear_demo_computers"))
        self.assertEqual(response.status_code, 302)
        self.assertEqual(Session.objects.filter(is_demo=True).count(), 10)

        admin = User.objects.create_superuser(username="admin", password="password123", email="admin@example.local")
        self.client.force_login(admin)
        response = self.client.post(reverse("dashboard:clear_demo_computers"))
        self.assertRedirects(response, reverse("dashboard:computers"))
        self.assertEqual(Session.objects.filter(is_demo=True).count(), 0)
        self.assertTrue(Session.objects.filter(session_id="real-session").exists())

    def test_demo_clear_rejects_get_and_missing_csrf_token(self):
        admin = User.objects.create_superuser(username="admin", password="password123", email="admin@example.local")
        self.client.force_login(admin)
        self.assertEqual(self.client.get(reverse("dashboard:clear_demo_computers")).status_code, 405)

        csrf_client = Client(enforce_csrf_checks=True)
        csrf_client.force_login(admin)
        self.assertEqual(csrf_client.post(reverse("dashboard:clear_demo_computers")).status_code, 403)

    def test_login_rejects_external_redirect_target(self):
        User.objects.create_user(username="user", password="password123")
        response = self.client.post(
            reverse("accounts:login") + "?next=https://example.invalid/",
            {"username": "user", "password": "password123"},
        )
        self.assertRedirects(response, reverse("dashboard:index"), fetch_redirect_response=False)

    def test_login_autofocus_uses_neutral_focus_style_until_a_login_fails(self):
        response = self.client.get(reverse("accounts:login"))
        self.assertEqual(response.status_code, 200)
        self.assertNotContains(response, 'class="has-login-error"')

        response = self.client.post(reverse("accounts:login"), {"username": "missing", "password": "wrong"})
        self.assertContains(response, 'class="has-login-error"')

    def test_live_search_client_code_does_not_inject_database_values_as_html(self):
        script = Path("static/js/app.js").read_text(encoding="utf-8")
        self.assertIn("function appendSearchText", script)
        self.assertIn("element.textContent = value || \"\"", script)
        self.assertNotIn("searchDropdown.innerHTML = html", script)

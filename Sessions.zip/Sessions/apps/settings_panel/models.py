"""
Operational settings editable from the dashboard (section 58).

Only the two operational knobs explicitly called out as "changeable from
the UI in the future" (section 24) are persisted here: the session hour
limit and the scan interval. SMTP/Audit connection settings remain
environment-managed (.env) — never persisted in the database — so that
credentials are never stored outside of the standard secret-management
mechanism (RULE / section 32, 61).
"""
from django.conf import settings
from django.db import models


class SystemSettings(models.Model):
    session_limit_hours = models.PositiveIntegerField(default=12)
    monitor_interval_seconds = models.PositiveIntegerField(default=3600)

    updated_at = models.DateTimeField(auto_now=True)
    updated_by = models.CharField(max_length=150, blank=True, default="")

    class Meta:
        verbose_name = "System Settings"
        verbose_name_plural = "System Settings"

    def __str__(self):
        return "System Settings"

    def save(self, *args, **kwargs):
        self.pk = 1  # enforce singleton
        super().save(*args, **kwargs)

    @classmethod
    def load(cls) -> "SystemSettings":
        obj, _ = cls.objects.get_or_create(
            pk=1,
            defaults={
                "session_limit_hours": settings.SESSION_LIMIT_HOURS,
                "monitor_interval_seconds": settings.MONITOR_INTERVAL,
            },
        )
        return obj

from django import forms

from .models import SystemSettings


class SystemSettingsForm(forms.ModelForm):
    class Meta:
        model = SystemSettings
        fields = ["session_limit_hours", "monitor_interval_seconds"]
        widgets = {
            "session_limit_hours": forms.NumberInput(attrs={"class": "form-input", "min": 1}),
            "monitor_interval_seconds": forms.NumberInput(attrs={"class": "form-input", "min": 60}),
        }

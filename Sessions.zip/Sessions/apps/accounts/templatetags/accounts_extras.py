from django import template

from apps.accounts.roles import is_administrator as _is_administrator
from apps.accounts.roles import is_operator_or_above as _is_operator_or_above
from apps.accounts.roles import user_role as _user_role

register = template.Library()


@register.filter
def is_administrator(user):
    return _is_administrator(user)


@register.filter
def is_operator_or_above(user):
    return _is_operator_or_above(user)


@register.filter
def user_role(user):
    return _user_role(user) or "User"

from django.conf import settings
from django.shortcuts import redirect
from django.urls import reverse


class LoginRequiredMiddleware:
    """The dashboard must never be publicly accessible (section 62)."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        path = request.path

        # /api/ is exempted from the redirect-based check: DRF enforces
        # authentication itself (session or token) and should return a
        # proper 401/403 JSON response instead of an HTML redirect.
        is_public = (
            path.startswith("/django-admin/")
            or path.startswith("/api/")
            or any(path.startswith(p) for p in settings.PUBLIC_URL_PATTERNS)
        )

        if not is_public and not request.user.is_authenticated:
            login_url = reverse("accounts:login")
            return redirect(f"{login_url}?next={path}")

        return self.get_response(request)

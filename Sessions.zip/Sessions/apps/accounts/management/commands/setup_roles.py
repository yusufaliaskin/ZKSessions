"""Creates the three role groups referenced by apps.accounts.roles
(section 63) so they can be assigned to users from the Django admin."""
from django.contrib.auth.models import Group
from django.core.management.base import BaseCommand

from apps.accounts.roles import ALL_ROLES


class Command(BaseCommand):
    help = "Create the Administrator / Operator / Viewer role groups."

    def handle(self, *args, **options):
        for role in ALL_ROLES:
            _, created = Group.objects.get_or_create(name=role)
            self.stdout.write(self.style.SUCCESS(f"{'Created' if created else 'Exists'}: {role}"))

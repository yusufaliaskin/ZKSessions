from django.contrib.auth import login as auth_login
from django.contrib.auth import logout as auth_logout
from django.contrib.auth.forms import AuthenticationForm
from django.shortcuts import redirect, render
from django.urls import reverse_lazy
from django.views import View


class LoginView(View):
    template_name = "accounts/login.html"

    def get(self, request):
        if request.user.is_authenticated:
            return redirect("dashboard:index")
        form = AuthenticationForm(request)
        return render(request, self.template_name, {"form": form})

    def post(self, request):
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            auth_login(request, user)
            if not request.POST.get("remember_me"):
                request.session.set_expiry(0)
            next_url = request.GET.get("next") or reverse_lazy("dashboard:index")
            return redirect(next_url)
        return render(request, self.template_name, {"form": form})


def logout_view(request):
    auth_logout(request)
    return redirect("accounts:login")

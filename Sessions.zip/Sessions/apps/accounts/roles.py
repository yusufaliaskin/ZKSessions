"""
Role-based authorization (section 63-64).

Roles are implemented as plain Django Groups so they show up in the
standard admin and don't require a custom user model:

    Administrator — full access: Settings, SMTP, Audit config, Monitoring config
    Operator      — Sessions, Reports, Audit (read-only), Assets
    Viewer        — Dashboard, Sessions, Reports (read-only everywhere)

Superusers are always treated as Administrators.
"""
ADMINISTRATOR = "Administrator"
OPERATOR = "Operator"
VIEWER = "Viewer"

ALL_ROLES = [ADMINISTRATOR, OPERATOR, VIEWER]


def user_role(user) -> str | None:
    if not user.is_authenticated:
        return None
    if user.is_superuser:
        return ADMINISTRATOR
    group_names = set(user.groups.values_list("name", flat=True))
    for role in ALL_ROLES:
        if role in group_names:
            return role
    return VIEWER


def is_administrator(user) -> bool:
    return user_role(user) == ADMINISTRATOR


def is_operator_or_above(user) -> bool:
    return user_role(user) in (ADMINISTRATOR, OPERATOR)

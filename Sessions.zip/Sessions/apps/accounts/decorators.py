from functools import wraps

from django.contrib import messages
from django.shortcuts import redirect

from .roles import is_administrator, is_operator_or_above


def administrator_required(view_func):
    @wraps(view_func)
    def _wrapped(request, *args, **kwargs):
        if not is_administrator(request.user):
            messages.error(request, "Administrator privileges required.")
            return redirect("dashboard:index")
        return view_func(request, *args, **kwargs)
    return _wrapped


def operator_required(view_func):
    @wraps(view_func)
    def _wrapped(request, *args, **kwargs):
        if not is_operator_or_above(request.user):
            messages.error(request, "Operator privileges required.")
            return redirect("dashboard:index")
        return view_func(request, *args, **kwargs)
    return _wrapped

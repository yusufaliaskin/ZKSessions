from django.contrib import admin

from .models import AuditCheckpoint, AuditEventRecord


@admin.register(AuditEventRecord)
class AuditEventRecordAdmin(admin.ModelAdmin):
    """Strictly read-only: audit data must never be edited or deleted
    from within this application (RULE 1 / RULE 2)."""

    list_display = ("event_time", "event_type", "user_name", "computer_name", "session_ref")
    list_filter = ("event_type",)
    search_fields = ("user_name", "sicil", "computer_name", "session_ref", "event_id")
    ordering = ("-event_time",)

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(AuditCheckpoint)
class AuditCheckpointAdmin(admin.ModelAdmin):
    list_display = ("source_name", "is_connected", "last_successful_scan", "last_event_time")

    def has_add_permission(self, request):
        return False

    def has_delete_permission(self, request, obj=None):
        return False

"""
Database audit reader for real-world SQL audit sources (MSSQL, PostgreSQL, MySQL, SQLite, Oracle).

🔴 RULE 1 / RULE 2 — READ-ONLY SOURCE OF TRUTH.
This adapter only executes SELECT queries and connectivity checks. It never alters
or mutates the external audit database.
"""
from __future__ import annotations

import importlib
import logging
from datetime import datetime
from django.conf import settings
from django.utils import timezone

from .base import AuditEvent, AuditEventType, AuditFetchResult, AuditReader

logger = logging.getLogger("session_monitor")


class DatabaseAuditReader(AuditReader):
    """
    Read-only adapter that connects to an external SQL audit database.
    
    Configuration (via .env / settings):
    - AUDIT_HOST: Server IP or hostname
    - AUDIT_PORT: Port (e.g., 1433 for MSSQL, 5432 for Postgres, 3306 for MySQL)
    - AUDIT_USERNAME: Read-only username
    - AUDIT_PASSWORD: Password
    - AUDIT_DB_NAME: Database name
    - AUDIT_DB_TYPE: Driver type (mssql, postgresql, mysql, sqlite)
    - AUDIT_TABLE_NAME: Table/View name (default: "audit_events")
    """

    def __init__(self):
        self.host = getattr(settings, "AUDIT_HOST", "")
        self.port = getattr(settings, "AUDIT_PORT", "")
        self.username = getattr(settings, "AUDIT_USERNAME", "")
        self.password = getattr(settings, "AUDIT_PASSWORD", "")
        self.db_name = getattr(settings, "AUDIT_DB_NAME", "")
        self.db_type = getattr(settings, "AUDIT_DB_TYPE", "mssql").lower()
        self.table_name = getattr(settings, "AUDIT_TABLE_NAME", "audit_events")

    def _get_connection(self):
        """Constructs a database connection depending on configured driver with dynamic imports."""
        if not self.host or not self.db_name:
            raise ConnectionError("Audit database connection parameters (AUDIT_HOST, AUDIT_DB_NAME) are not configured.")

        if self.db_type in ("postgres", "postgresql"):
            psycopg2 = importlib.import_module("psycopg2")
            return psycopg2.connect(
                host=self.host,
                port=self.port or 5432,
                user=self.username,
                password=self.password,
                dbname=self.db_name,
                connect_timeout=5,
            )
        elif self.db_type in ("mssql", "sqlserver"):
            pymssql = importlib.import_module("pymssql")
            return pymssql.connect(
                server=self.host,
                port=str(self.port or 1433),
                user=self.username,
                password=self.password,
                database=self.db_name,
                login_timeout=5,
                timeout=10,
            )
        elif self.db_type in ("mysql", "mariadb"):
            pymysql = importlib.import_module("pymysql")
            return pymysql.connect(
                host=self.host,
                port=int(self.port or 3306),
                user=self.username,
                password=self.password,
                database=self.db_name,
                connect_timeout=5,
            )
        else:
            raise ValueError(f"Unsupported AUDIT_DB_TYPE: {self.db_type}")

    def check_connection(self) -> bool:
        """Lightweight connectivity check."""
        if not self.host:
            return False
        try:
            conn = self._get_connection()
            with conn.cursor() as cursor:
                cursor.execute("SELECT 1")
            conn.close()
            return True
        except Exception as exc:
            logger.warning("AUDIT_DB_CONNECTION_CHECK_FAILED: %s", exc)
            return False

    def fetch_events(
        self,
        start_time: datetime,
        end_time: datetime,
        cursor: str | None = None,
        page_size: int = 500,
    ) -> AuditFetchResult:
        """
        Fetches audit events between start_time and end_time with cursor pagination.
        Expects columns: event_id, event_type, username, sicil, computer_name, event_time, session_id, raw_payload.
        """
        if not self.host:
            return AuditFetchResult(
                events=[],
                connected=False,
                error="Audit DB parameters are not configured in .env",
            )

        offset = int(cursor) if cursor else 0
        events: list[AuditEvent] = []

        query = f"""
            SELECT event_id, event_type, username, sicil, computer_name, event_time, session_id, raw_payload
            FROM {self.table_name}
            WHERE event_time >= %s AND event_time <= %s
            ORDER BY event_time ASC
            LIMIT %s OFFSET %s
        """

        try:
            conn = self._get_connection()
            with conn.cursor() as cur:
                cur.execute(query, (start_time, end_time, page_size + 1, offset))
                rows = cur.fetchall()
            conn.close()

            has_more = len(rows) > page_size
            data_rows = rows[:page_size]

            for row in data_rows:
                e_id, e_type, u_name, sicil, comp, e_time, s_id, payload = row
                
                # Normalize event type
                ev_type_enum = AuditEventType.LOGIN if str(e_type).upper() == "LOGIN" else AuditEventType.LOGOUT
                
                # Ensure event_time is timezone-aware
                if timezone.is_naive(e_time):
                    e_time = timezone.make_aware(e_time, timezone.utc)

                events.append(
                    AuditEvent(
                        event_id=str(e_id),
                        event_type=ev_type_enum,
                        username=str(u_name or ""),
                        sicil=str(sicil or ""),
                        computer_name=str(comp or ""),
                        event_time=e_time,
                        session_id=str(s_id) if s_id else None,
                        raw_payload=payload if isinstance(payload, dict) else {},
                    )
                )

            next_cursor = str(offset + len(data_rows)) if has_more else None

            return AuditFetchResult(
                events=events,
                next_cursor=next_cursor,
                has_more=has_more,
                connected=True,
            )

        except Exception as exc:
            logger.error("AUDIT_DB_FETCH_FAILED: %s", exc)
            return AuditFetchResult(
                events=[],
                connected=False,
                error=str(exc),
            )

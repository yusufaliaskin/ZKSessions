"""
Audit adapter abstraction.

🔴 RULE 1 / RULE 2 — The audit system is a READ-ONLY source of truth.
No adapter implementation is allowed to INSERT, UPDATE, DELETE, terminate
sessions, or modify audit data in any way. Adapters only ever *fetch*.

This module intentionally has zero knowledge of a specific vendor's audit
API/schema. When the real audit system's connection details are provided,
implement a new adapter class next to `MockAuditReader` and point
`AUDIT_BACKEND` at it. Nothing in `apps.monitoring` or `apps.dashboard`
needs to change.
"""
from __future__ import annotations

import dataclasses
import enum
from datetime import datetime


class AuditEventType(str, enum.Enum):
    LOGIN = "LOGIN"
    LOGOUT = "LOGOUT"


@dataclasses.dataclass(frozen=True)
class AuditEvent:
    """A single, normalized audit event as read from the audit source.

    `raw_payload` preserves whatever the upstream audit system returned so
    it can be displayed verbatim on the Audit Event Detail screen.
    """

    event_id: str
    event_type: AuditEventType
    username: str
    sicil: str
    computer_name: str
    event_time: datetime
    session_id: str | None = None
    raw_payload: dict | None = None


@dataclasses.dataclass(frozen=True)
class AuditFetchResult:
    """Result of a single fetch_events() call, pagination-aware."""

    events: list[AuditEvent]
    next_cursor: str | None = None
    has_more: bool = False
    connected: bool = True
    error: str | None = None


class AuditReader:
    """Abstract, read-only interface onto the external audit system.

    Concrete adapters MUST NOT implement any mutating operation. There is
    deliberately no `delete_event`, `acknowledge_event`, `terminate_session`,
    etc. on this interface.
    """

    def fetch_events(
        self,
        start_time: datetime,
        end_time: datetime,
        cursor: str | None = None,
        page_size: int = 500,
    ) -> AuditFetchResult:
        """Fetch a page of audit events between start_time and end_time.

        Implementations should support cursor-based pagination so that
        5000+ device audit histories are never re-fetched in full on every
        monitoring cycle (see RULE 12 / section 28-29).
        """
        raise NotImplementedError

    def check_connection(self) -> bool:
        """Cheap connectivity/health check used by the System Status page."""
        raise NotImplementedError

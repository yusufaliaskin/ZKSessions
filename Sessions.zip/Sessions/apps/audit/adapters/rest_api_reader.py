"""
REST API audit reader for real-world HTTP/HTTPS audit endpoints.

🔴 RULE 1 / RULE 2 — READ-ONLY SOURCE OF TRUTH.
This adapter only performs GET requests and connectivity checks. It never alters
or mutates the upstream audit system.
"""
from __future__ import annotations

import json
import logging
import urllib.parse
import urllib.request
from datetime import datetime
from django.conf import settings
from django.utils import timezone
from django.utils.dateparse import parse_datetime

from .base import AuditEvent, AuditEventType, AuditFetchResult, AuditReader

logger = logging.getLogger("session_monitor")


class RestApiAuditReader(AuditReader):
    """
    Read-only adapter that connects to an external REST API audit service.
    
    Configuration (via .env / settings):
    - AUDIT_API_URL: Base URL (e.g. "https://audit-gateway.corp.local/api/v1/sessions")
    - AUDIT_API_KEY: Bearer token or API key
    - AUDIT_USERNAME / AUDIT_PASSWORD: Basic auth (optional alternative)
    """

    def __init__(self):
        self.api_url = getattr(settings, "AUDIT_API_URL", "")
        self.api_key = getattr(settings, "AUDIT_API_KEY", "")
        self.username = getattr(settings, "AUDIT_USERNAME", "")
        self.password = getattr(settings, "AUDIT_PASSWORD", "")
        self.timeout = 10

    def _build_request(self, params: dict | None = None) -> urllib.request.Request:
        url = self.api_url
        if params:
            query_string = urllib.parse.urlencode(params)
            delimiter = "&" if "?" in url else "?"
            url = f"{url}{delimiter}{query_string}"

        req = urllib.request.Request(url, method="GET")
        req.add_header("Accept", "application/json")
        req.add_header("User-Agent", "SessionMonitor/1.0")

        if self.api_key:
            req.add_header("Authorization", f"Bearer {self.api_key}")
        elif self.username and self.password:
            import base64
            auth_str = f"{self.username}:{self.password}"
            b64_auth = base64.b64encode(auth_str.encode()).decode()
            req.add_header("Authorization", f"Basic {b64_auth}")

        return req

    def check_connection(self) -> bool:
        """Ping the API health or root endpoint."""
        if not self.api_url:
            return False
        try:
            health_url = getattr(settings, "AUDIT_API_HEALTH_URL", None) or f"{self.api_url.rstrip('/')}/health"
            req = urllib.request.Request(health_url, method="GET")
            req.add_header("User-Agent", "SessionMonitor/1.0")
            if self.api_key:
                req.add_header("Authorization", f"Bearer {self.api_key}")
            with urllib.request.urlopen(req, timeout=5) as response:
                return 200 <= response.status < 300
        except Exception as exc:
            # Fallback: try querying a 1-item window
            try:
                req = self._build_request({"limit": 1})
                with urllib.request.urlopen(req, timeout=5) as response:
                    return 200 <= response.status < 300
            except Exception as exc2:
                logger.warning("AUDIT_API_CONNECTION_CHECK_FAILED: %s | %s", exc, exc2)
                return False

    def fetch_events(
        self,
        start_time: datetime,
        end_time: datetime,
        cursor: str | None = None,
        page_size: int = 500,
    ) -> AuditFetchResult:
        if not self.api_url:
            return AuditFetchResult(
                events=[],
                connected=False,
                error="AUDIT_API_URL is not configured in .env",
            )

        params = {
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "limit": page_size,
        }
        if cursor:
            params["cursor"] = cursor

        try:
            req = self._build_request(params)
            with urllib.request.urlopen(req, timeout=self.timeout) as response:
                if response.status != 200:
                    return AuditFetchResult(
                        events=[],
                        connected=False,
                        error=f"HTTP {response.status}: {response.reason}",
                    )
                raw_data = json.loads(response.read().decode("utf-8"))

            items = raw_data.get("events") or raw_data.get("data") or []
            has_more = raw_data.get("has_more", False)
            next_cursor = raw_data.get("next_cursor")

            events: list[AuditEvent] = []
            for item in items:
                event_type_str = str(item.get("event_type", item.get("type", "LOGIN"))).upper()
                ev_type = AuditEventType.LOGIN if event_type_str == "LOGIN" else AuditEventType.LOGOUT
                
                raw_time = item.get("event_time") or item.get("timestamp")
                if isinstance(raw_time, str):
                    ev_time = parse_datetime(raw_time) or timezone.now()
                elif isinstance(raw_time, (int, float)):
                    ev_time = datetime.fromtimestamp(raw_time, tz=timezone.utc)
                else:
                    ev_time = timezone.now()

                if timezone.is_naive(ev_time):
                    ev_time = timezone.make_aware(ev_time, timezone.utc)

                events.append(
                    AuditEvent(
                        event_id=str(item.get("event_id", item.get("id", ""))),
                        event_type=ev_type,
                        username=str(item.get("username", item.get("user", ""))),
                        sicil=str(item.get("sicil", item.get("employee_id", ""))),
                        computer_name=str(item.get("computer_name", item.get("hostname", ""))),
                        event_time=ev_time,
                        session_id=str(item.get("session_id")) if item.get("session_id") else None,
                        raw_payload=item,
                    )
                )

            return AuditFetchResult(
                events=events,
                next_cursor=next_cursor,
                has_more=has_more,
                connected=True,
            )

        except Exception as exc:
            logger.error("AUDIT_API_FETCH_FAILED: %s", exc)
            return AuditFetchResult(
                events=[],
                connected=False,
                error=str(exc),
            )

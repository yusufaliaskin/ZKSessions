"""Resolves the configured AuditReader implementation from settings."""
from django.conf import settings
from django.utils.module_loading import import_string

from .base import AuditReader

_instance: AuditReader | None = None


def get_audit_reader() -> AuditReader:
    """Return a (cached) instance of the configured AuditReader.

    Controlled entirely by `settings.AUDIT_BACKEND` — a dotted path to an
    `AuditReader` subclass. Swapping in a real adapter never requires
    touching the monitoring engine or dashboard code.
    """
    global _instance
    if _instance is None:
        reader_class = import_string(settings.AUDIT_BACKEND)
        _instance = reader_class()
    return _instance


def reset_audit_reader_cache():
    """Used by tests to force re-resolution of the adapter."""
    global _instance
    _instance = None

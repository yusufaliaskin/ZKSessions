"""
Mock audit reader used for local development and tests (section 27).

This lets the whole session-monitoring pipeline — login detection, the 12
hour engine, SMTP reporting, dashboards — be exercised end-to-end without a
real audit backend. It is READ-ONLY, exactly like a real adapter must be:
it only ever *generates/returns* events, never persists anything.

Swap `AUDIT_BACKEND` in settings to a real adapter once the actual audit
system's connection details are available; nothing else in the codebase
needs to change.
"""
from __future__ import annotations

import hashlib
import random
from datetime import datetime, timedelta

from django.utils import timezone

from .base import AuditEvent, AuditEventType, AuditFetchResult, AuditReader

_COMPUTERS = [f"PC-{i:03d}" for i in range(1, 61)]
_FIRST_NAMES = ["ahmet", "mehmet", "ali", "veli", "ayse", "fatma", "elif", "burak", "cem", "deniz"]
_LAST_NAMES = ["yilmaz", "kaya", "demir", "sahin", "celik", "yildiz", "aydin", "ozturk"]


def _build_virtual_sessions(seed: int, count: int, horizon_hours: int):
    """Deterministically build a fixed population of virtual login sessions
    anchored to *now*, so repeated calls within the same process return a
    stable, growing timeline instead of new random data every time.
    """
    rng = random.Random(seed)
    now = timezone.now()
    sessions = []
    for i in range(count):
        username = f"{rng.choice(_FIRST_NAMES)}.{rng.choice(_LAST_NAMES)}"
        sicil = str(100000 + int(hashlib.sha1(f"{username}{i}".encode()).hexdigest(), 16) % 900000)
        computer = rng.choice(_COMPUTERS)
        login_offset_minutes = rng.randint(0, horizon_hours * 60)
        login_time = now - timedelta(minutes=login_offset_minutes)

        # Roughly a third of sessions have already logged out (short lived),
        # a third are still active under 12h, a third exceed 12h.
        bucket = i % 3
        logout_time = None
        if bucket == 0:
            duration_minutes = rng.randint(15, 11 * 60)
            candidate_logout = login_time + timedelta(minutes=duration_minutes)
            if candidate_logout < now:
                logout_time = candidate_logout
        # bucket 1 & 2 stay active (bucket 2 skews to logins far enough in
        # the past that they naturally exceed the 12h threshold).
        if bucket == 2:
            login_time = now - timedelta(hours=rng.randint(12, 30), minutes=rng.randint(0, 59))

        session_id = hashlib.sha1(f"{username}{computer}{login_time.isoformat()}".encode()).hexdigest()[:20]
        sessions.append(
            {
                "session_id": session_id,
                "username": username,
                "sicil": sicil,
                "computer": computer,
                "login_time": login_time,
                "logout_time": logout_time,
            }
        )
    return sessions


class MockAuditReader(AuditReader):
    """Generates a stable, realistic mix of LOGIN/LOGOUT events."""

    SEED = 42
    POPULATION_SIZE = 90
    HORIZON_HOURS = 36

    def __init__(self):
        self._sessions = _build_virtual_sessions(self.SEED, self.POPULATION_SIZE, self.HORIZON_HOURS)

    def check_connection(self) -> bool:
        return True

    def fetch_events(
        self,
        start_time: datetime,
        end_time: datetime,
        cursor: str | None = None,
        page_size: int = 500,
    ) -> AuditFetchResult:
        events: list[AuditEvent] = []
        for session in self._sessions:
            login_time = session["login_time"]
            if start_time <= login_time <= end_time:
                events.append(
                    AuditEvent(
                        event_id=f"{session['session_id']}-login",
                        event_type=AuditEventType.LOGIN,
                        username=session["username"],
                        sicil=session["sicil"],
                        computer_name=session["computer"],
                        event_time=login_time,
                        session_id=session["session_id"],
                        raw_payload={
                            "event": "LOGIN",
                            "session_id": session["session_id"],
                            "username": session["username"],
                            "sicil": session["sicil"],
                            "computer": session["computer"],
                            "timestamp": login_time.isoformat(),
                        },
                    )
                )
            logout_time = session["logout_time"]
            if logout_time and start_time <= logout_time <= end_time:
                events.append(
                    AuditEvent(
                        event_id=f"{session['session_id']}-logout",
                        event_type=AuditEventType.LOGOUT,
                        username=session["username"],
                        sicil=session["sicil"],
                        computer_name=session["computer"],
                        event_time=logout_time,
                        session_id=session["session_id"],
                        raw_payload={
                            "event": "LOGOUT",
                            "session_id": session["session_id"],
                            "username": session["username"],
                            "sicil": session["sicil"],
                            "computer": session["computer"],
                            "timestamp": logout_time.isoformat(),
                        },
                    )
                )

        events.sort(key=lambda e: e.event_time)

        # Simple offset-based pagination via cursor="<index>".
        offset = int(cursor) if cursor else 0
        page = events[offset : offset + page_size]
        next_offset = offset + page_size
        has_more = next_offset < len(events)

        return AuditFetchResult(
            events=page,
            next_cursor=str(next_offset) if has_more else None,
            has_more=has_more,
            connected=True,
        )

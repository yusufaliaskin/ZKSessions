"""
Local, read-only mirror of audit data consumed by SESSION MONITOR.

🔴 IMPORTANT: These models never write back to the external audit system.
They exist purely so that:
  1. The monitoring engine has a durable checkpoint (RULE 14 / section 29)
     to resume reading from after a restart, without re-scanning the full
     audit history for 5000+ devices every cycle.
  2. The dashboard's "Audit / Events" screens have something to display,
     since a real external audit datastore does not exist in this
     environment yet.

Nothing in the UI is allowed to edit/delete rows here — see
apps/audit/admin.py and apps/dashboard/views for the read-only enforcement.
"""
from django.db import models


class AuditCheckpoint(models.Model):
    """Singleton-per-source checkpoint of the last successful audit read.

    Section 29: program restart must be able to resume safely from here.
    """

    source_name = models.CharField(max_length=100, unique=True, default="default")
    last_cursor = models.CharField(max_length=255, blank=True, default="")
    last_event_time = models.DateTimeField(null=True, blank=True)
    last_successful_scan = models.DateTimeField(null=True, blank=True)
    is_connected = models.BooleanField(default=False)
    last_error = models.TextField(blank=True, default="")
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Audit Checkpoint"
        verbose_name_plural = "Audit Checkpoints"

    def __str__(self):
        return f"Checkpoint[{self.source_name}] @ {self.last_successful_scan}"


class AuditEventRecord(models.Model):
    """Local, append-only copy of a normalized audit event.

    READ-ONLY from the UI's perspective. Written to exactly once by the
    monitoring engine when the event is first observed (idempotent on
    `event_id`, see RULE 8 / section 72-73).
    """

    LOGIN = "LOGIN"
    LOGOUT = "LOGOUT"
    EVENT_TYPE_CHOICES = [(LOGIN, "Login"), (LOGOUT, "Logout")]

    event_id = models.CharField(max_length=255, unique=True, db_index=True)
    event_type = models.CharField(max_length=10, choices=EVENT_TYPE_CHOICES, db_index=True)

    session_ref = models.CharField(max_length=255, blank=True, default="", db_index=True)
    user_name = models.CharField(max_length=150, db_index=True)
    sicil = models.CharField(max_length=50, db_index=True)
    computer_name = models.CharField(max_length=150, db_index=True)

    event_time = models.DateTimeField(db_index=True)
    raw_payload = models.JSONField(default=dict, blank=True)

    received_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Audit Event"
        verbose_name_plural = "Audit Events"
        ordering = ["-event_time"]
        indexes = [
            models.Index(fields=["event_type", "event_time"]),
            models.Index(fields=["user_name", "computer_name"]),
        ]

    def __str__(self):
        return f"{self.event_type} {self.user_name}@{self.computer_name} {self.event_time}"

from django.contrib import admin

from .models import Session, SessionTimelineEvent


class TimelineInline(admin.TabularInline):
    model = SessionTimelineEvent
    extra = 0
    readonly_fields = ("event_type", "event_time", "description")
    can_delete = False

    def has_add_permission(self, request, obj=None):
        return False


@admin.register(Session)
class SessionAdmin(admin.ModelAdmin):
    list_display = (
        "user_name", "sicil", "computer_name", "login_time", "logout_time",
        "report_send", "status",
    )
    list_filter = ("status", "report_send")
    search_fields = ("user_name", "sicil", "computer_name", "session_id")
    date_hierarchy = "login_time"
    inlines = [TimelineInline]
    readonly_fields = [f.name for f in Session._meta.fields]

    def has_add_permission(self, request):
        # Sessions are only ever created by the monitoring engine from
        # audit data — never manually through the admin.
        return False

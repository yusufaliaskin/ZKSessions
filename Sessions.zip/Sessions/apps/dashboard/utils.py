"""Shared helpers for dashboard views: pagination, search, severity."""
from django.core.paginator import Paginator
from django.utils import timezone


def paginate(request, queryset, per_page=20):
    page_number = request.GET.get("page", 1)
    paginator = Paginator(queryset, per_page)
    return paginator.get_page(page_number)


def apply_search(queryset, request, fields):
    query = request.GET.get("q", "").strip()
    if not query:
        return queryset
    from django.db.models import Q

    condition = Q()
    for field in fields:
        condition |= Q(**{f"{field}__icontains": query})
    return queryset.filter(condition)


def apply_ordering(queryset, request, allowed_fields, default="-login_time"):
    ordering = request.GET.get("sort", default)
    field_name = ordering.lstrip("-")
    if field_name not in allowed_fields:
        ordering = default
    return queryset.order_by(ordering)


def severity_for_duration(duration, limit_hours):
    """Visual-only severity classification (section 49/88) — never used to
    decide business logic, purely for UI color coding."""
    hours = duration.total_seconds() / 3600
    if hours < limit_hours:
        return "green"
    if hours < limit_hours * 2:
        return "orange"
    return "red"


def format_duration(duration):
    total_seconds = int(duration.total_seconds())
    hours, remainder = divmod(total_seconds, 3600)
    minutes, _ = divmod(remainder, 60)
    return f"{hours}h {minutes}m"


def now():
    return timezone.now()

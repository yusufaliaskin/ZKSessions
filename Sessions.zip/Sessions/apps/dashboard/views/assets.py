from django.contrib.auth.decorators import login_required
from django.db.models import Count, Max, Q
from django.shortcuts import render

from apps.sessions.models import Session
from apps.system_status.services import get_system_status

from ..utils import apply_search, paginate


@login_required
def computers(request):
    limit_hours = get_system_status()["session_limit_hours"]
    queryset = (
        Session.objects.values("computer_name")
        .annotate(
            active_sessions=Count("id", filter=Q(logout_time__isnull=True)),
            total_sessions=Count("id"),
            last_login=Max("login_time"),
        )
        .order_by("-active_sessions", "computer_name")
    )
    queryset = apply_search(queryset, request, ["computer_name"])
    page_obj = paginate(request, queryset, per_page=20)

    over_limit_by_computer = dict(
        Session.objects.over_limit(limit_hours)
        .values("computer_name")
        .annotate(c=Count("id"))
        .values_list("computer_name", "c")
    )
    rows = []
    for row in page_obj:
        row = dict(row)
        row["over_limit"] = over_limit_by_computer.get(row["computer_name"], 0)
        rows.append(row)

    return render(request, "dashboard/assets/computers.html", {
        "rows": rows, "page_obj": page_obj, "active_page": "assets-computers",
    })


@login_required
def users(request):
    limit_hours = get_system_status()["session_limit_hours"]
    queryset = (
        Session.objects.values("user_name", "sicil")
        .annotate(
            active_sessions=Count("id", filter=Q(logout_time__isnull=True)),
            last_login=Max("login_time"),
            last_logout=Max("logout_time"),
        )
        .order_by("user_name")
    )
    queryset = apply_search(queryset, request, ["user_name", "sicil"])
    page_obj = paginate(request, queryset, per_page=20)

    over_limit_by_user = dict(
        Session.objects.over_limit(limit_hours)
        .values("user_name")
        .annotate(c=Count("id"))
        .values_list("user_name", "c")
    )
    rows = []
    for row in page_obj:
        row = dict(row)
        row["over_limit"] = over_limit_by_user.get(row["user_name"], 0)
        rows.append(row)

    return render(request, "dashboard/assets/users.html", {
        "rows": rows, "page_obj": page_obj, "active_page": "assets-users",
    })

from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.shortcuts import render

from apps.monitoring.models import MonitoringCycleRun
from apps.system_status.models import SystemLogEntry
from apps.system_status.services import get_system_status

from ..utils import paginate


@login_required
def status(request):
    system_status = get_system_status(use_cache=False)
    recent_cycles = MonitoringCycleRun.objects.order_by("-started_at")[:15]
    return render(request, "dashboard/system/status.html", {
        "status": system_status,
        "recent_cycles": recent_cycles,
        "active_page": "system-status",
    })


@login_required
def logs(request):
    queryset = SystemLogEntry.objects.all().order_by("-created_at")
    
    # Calculate stats
    total_count = SystemLogEntry.objects.count()
    error_count = SystemLogEntry.objects.filter(level__in=["ERROR", "CRITICAL"]).count()
    warning_count = SystemLogEntry.objects.filter(level="WARNING").count()
    info_count = SystemLogEntry.objects.filter(level__in=["INFO", "DEBUG"]).count()

    level = request.GET.get("level", "").strip()
    if level in dict(SystemLogEntry.LEVEL_CHOICES):
        queryset = queryset.filter(level=level)

    q = request.GET.get("q", "").strip()
    if q:
        queryset = queryset.filter(Q(message__icontains=q) | Q(logger_name__icontains=q))

    page_obj = paginate(request, queryset, per_page=20)
    return render(request, "dashboard/system/logs.html", {
        "page_obj": page_obj,
        "selected_level": level,
        "levels": SystemLogEntry.LEVEL_CHOICES,
        "active_page": "system-logs",
        "q": q,
        "stats": {
            "total": total_count,
            "errors": error_count,
            "warnings": warning_count,
            "info": info_count,
        }
    })


@login_required
def smtp_status(request):
    from apps.reporting.models import ReportHistory

    system_status = get_system_status()
    recent_failures = ReportHistory.objects.filter(status=ReportHistory.FAILED).select_related("session").order_by("-updated_at")[:20]
    return render(request, "dashboard/system/smtp.html", {
        "status": system_status,
        "recent_failures": recent_failures,
        "active_page": "system-smtp",
    })

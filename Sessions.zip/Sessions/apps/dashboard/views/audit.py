"""Audit event views — STRICTLY READ-ONLY (RULE 1/2, section 52-53).

No view in this module (or any template it renders) exposes edit/delete
actions on audit data.
"""
from django.contrib.auth.decorators import login_required
from django.http import Http404
from django.shortcuts import render
from django.utils import timezone
from datetime import timedelta

from apps.audit.models import AuditCheckpoint, AuditEventRecord

from ..utils import apply_search, paginate

SEARCH_FIELDS = ["user_name", "sicil", "computer_name", "session_ref", "event_id"]


def _render_event_list(request, queryset, title, subtitle, active_page):
    now = timezone.now()
    total_events = AuditEventRecord.objects.count()
    login_count = AuditEventRecord.objects.filter(event_type=AuditEventRecord.LOGIN).count()
    logout_count = AuditEventRecord.objects.filter(event_type=AuditEventRecord.LOGOUT).count()

    # 12-hour hourly buckets for mini chart
    base_time = now - timedelta(hours=11)
    chart_hours = []
    chart_counts = []
    for i in range(12):
        slot_start = base_time + timedelta(hours=i)
        slot_end = slot_start + timedelta(hours=1)
        cnt = AuditEventRecord.objects.filter(event_time__gte=slot_start, event_time__lt=slot_end).count()
        chart_hours.append(slot_start.strftime("%H:00"))
        chart_counts.append(cnt)

    queryset = apply_search(queryset, request, SEARCH_FIELDS)
    page_obj = paginate(request, queryset, per_page=20)
    checkpoint = AuditCheckpoint.objects.filter(source_name="default").first()

    context = {
        "title": title,
        "subtitle": subtitle,
        "page_obj": page_obj,
        "active_page": active_page,
        "checkpoint": checkpoint,
        "total_events": total_events,
        "login_count": login_count,
        "logout_count": logout_count,
        "chart_hours": chart_hours,
        "chart_counts": chart_counts,
        "query_params": request.GET.urlencode(),
    }
    return render(request, "dashboard/audit/list.html", context)


@login_required
def all_events(request):
    return _render_event_list(
        request, AuditEventRecord.objects.all().order_by("-event_time"),
        "Audit Events", "Read-only mirror of events observed from the audit source", "audit-events",
    )


@login_required
def login_events(request):
    return _render_event_list(
        request, AuditEventRecord.objects.filter(event_type=AuditEventRecord.LOGIN).order_by("-event_time"),
        "Login Events", "LOGIN events read from audit", "audit-login",
    )


@login_required
def logout_events(request):
    return _render_event_list(
        request, AuditEventRecord.objects.filter(event_type=AuditEventRecord.LOGOUT).order_by("-event_time"),
        "Logout Events", "LOGOUT events read from audit", "audit-logout",
    )


@login_required
def event_detail(request, pk):
    try:
        event = AuditEventRecord.objects.get(pk=pk)
    except AuditEventRecord.DoesNotExist:
        raise Http404
    import json
    raw_json = json.dumps(event.raw_payload, indent=2, ensure_ascii=False, default=str)
    return render(request, "dashboard/audit/detail.html", {
        "event": event, "raw_json": raw_json, "active_page": "audit-events",
    })

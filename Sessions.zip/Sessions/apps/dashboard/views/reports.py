from django.contrib.auth.decorators import login_required
from django.http import Http404
from django.shortcuts import render

from apps.reporting.models import ReportHistory

from ..utils import apply_ordering, apply_search, paginate

SEARCH_FIELDS = ["session__user_name", "session__sicil", "session__computer_name", "recipient"]
SORTABLE_FIELDS = ["created_at", "sent_at", "status", "attempt_count"]


def _render_report_list(request, queryset, title, subtitle, active_page):
    queryset = queryset.select_related("session")
    queryset = apply_search(queryset, request, SEARCH_FIELDS)
    queryset = apply_ordering(queryset, request, SORTABLE_FIELDS, default="-created_at")
    page_obj = paginate(request, queryset, per_page=20)

    context = {
        "title": title,
        "subtitle": subtitle,
        "page_obj": page_obj,
        "active_page": active_page,
        "query_params": request.GET.urlencode(),
    }
    return render(request, "dashboard/reports/list.html", context)


@login_required
def sent_reports(request):
    return _render_report_list(
        request, ReportHistory.objects.filter(status=ReportHistory.SENT),
        "Sent Reports", "Successfully delivered 12-hour alert reports", "reports-sent",
    )


@login_required
def pending_reports(request):
    return _render_report_list(
        request, ReportHistory.objects.filter(status__in=[ReportHistory.PENDING, ReportHistory.SENDING]),
        "Pending Reports", "Reports queued or currently being sent", "reports-pending",
    )


@login_required
def failed_reports(request):
    return _render_report_list(
        request, ReportHistory.objects.filter(status=ReportHistory.FAILED),
        "Failed Reports", "SMTP delivery failures — automatically retried next cycle", "reports-failed",
    )


@login_required
def report_detail(request, pk):
    try:
        report = ReportHistory.objects.select_related("session").get(pk=pk)
    except ReportHistory.DoesNotExist:
        raise Http404
    return render(request, "dashboard/reports/detail.html", {"report": report, "active_page": "reports-sent"})

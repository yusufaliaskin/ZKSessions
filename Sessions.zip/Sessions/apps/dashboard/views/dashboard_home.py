from django.contrib.auth.decorators import login_required
from django.db.models import Count, Q
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
from django.utils import timezone
from datetime import timedelta
import csv

from apps.audit.models import AuditEventRecord
from apps.reporting.models import ReportHistory
from apps.sessions.models import Session
from apps.system_status.services import get_system_status

from ..utils import format_duration, severity_for_duration


@login_required
def index(request):
    status = get_system_status(use_cache=False)
    limit_hours = status.get("session_limit_hours", 12)
    now = timezone.now()

    # Time Range Filtering
    time_range = request.GET.get("time_range", "24h").strip()
    if time_range == "1h":
        start_filter = now - timedelta(hours=1)
        time_range_label = "Son 1 Saat"
    elif time_range == "7d":
        start_filter = now - timedelta(days=7)
        time_range_label = "Son 7 Gün"
    elif time_range == "today":
        start_filter = now.replace(hour=0, minute=0, second=0, microsecond=0)
        time_range_label = "Bugün"
    else:
        time_range = "24h"
        start_filter = now - timedelta(hours=24)
        time_range_label = "Son 24 Saat"

    # 1. 100% Real Live Database Queries
    active_qs = Session.objects.active()
    over_limit_qs = Session.objects.over_limit(limit_hours, now=now)
    total_sessions_count = Session.objects.count()
    logged_out_count = Session.objects.filter(logout_time__isnull=False).count()
    reports_sent_count = ReportHistory.objects.filter(status=ReportHistory.SENT).count()
    reports_failed_count = ReportHistory.objects.filter(status=ReportHistory.FAILED).count()
    reports_pending_count = Session.objects.pending_report(limit_hours, now=now).count()

    stats = {
        "total_sessions": total_sessions_count,
        "active_sessions": active_qs.count(),
        "over_limit": over_limit_qs.count(),
        "reports_sent": reports_sent_count,
        "reports_pending": reports_pending_count,
        "reports_failed": reports_failed_count,
        "logged_out_count": logged_out_count,
        "auth_success": active_qs.count() + logged_out_count,
    }

    # 2. Real Donut Chart Breakdown (Live Security Distribution)
    safe_active_count = max(0, stats["active_sessions"] - stats["over_limit"])
    chart_distribution = {
        "Active Under 12h": safe_active_count,
        "Over 12h Alert": stats["over_limit"],
        "Closed / Logged Out": stats["logged_out_count"],
        "Report Dispatched": stats["reports_sent"],
    }

    # 3. Real Activity Histogram based on selected time range
    hours_labels = []
    hourly_counts = []
    
    if time_range == "1h":
        base_time = now - timedelta(minutes=55)
        for i in range(12):
            slot_start = base_time + timedelta(minutes=i*5)
            slot_end = slot_start + timedelta(minutes=5)
            cnt = Session.objects.filter(login_time__gte=slot_start, login_time__lt=slot_end).count()
            hours_labels.append(slot_start.strftime("%H:%M"))
            hourly_counts.append(cnt)
    elif time_range == "7d":
        base_time = now - timedelta(days=6)
        for i in range(7):
            slot_start = (base_time + timedelta(days=i)).replace(hour=0, minute=0, second=0)
            slot_end = slot_start + timedelta(days=1)
            cnt = Session.objects.filter(login_time__gte=slot_start, login_time__lt=slot_end).count()
            hours_labels.append(slot_start.strftime("%d.%m"))
            hourly_counts.append(cnt)
    else:
        base_time = now - timedelta(hours=23)
        for i in range(24):
            slot_start = base_time + timedelta(hours=i)
            slot_end = slot_start + timedelta(hours=1)
            session_hits = Session.objects.filter(login_time__lt=slot_end).filter(
                Q(logout_time__isnull=True) | Q(logout_time__gte=slot_start)
            ).count()
            audit_hits = AuditEventRecord.objects.filter(event_time__gte=slot_start, event_time__lt=slot_end).count()
            hours_labels.append(slot_start.strftime("%H:00"))
            hourly_counts.append(session_hits + audit_hits)

    # 4. Latest Dispatched Reports & Security Alerts for Dashboard Bottom Table
    recent_reports = ReportHistory.objects.select_related("session").order_by("-sent_at", "-created_at")[:15]
    latest_reports_list = []
    for r in recent_reports:
        s = r.session
        dur = s.duration(now=now)
        latest_reports_list.append({
            "report": r,
            "session": s,
            "duration": format_duration(dur),
            "sent_at": r.sent_at or r.created_at,
            "status": r.status,
            "status_display": r.get_status_display(),
            "attempt_count": r.attempt_count,
            "recipient": r.recipient,
        })

    if not latest_reports_list:
        target_sessions = list(over_limit_qs.order_by("login_time")[:15])
        if len(target_sessions) < 15:
            existing_ids = [s.id for s in target_sessions]
            more_sessions = list(active_qs.exclude(id__in=existing_ids).order_by("-login_time")[:15 - len(target_sessions)])
            target_sessions.extend(more_sessions)

        for s in target_sessions:
            dur = s.duration(now=now)
            latest_reports_list.append({
                "report": None,
                "session": s,
                "duration": format_duration(dur),
                "sent_at": s.report_time or s.login_time,
                "status": "SENT" if s.report_send else ("FAILED" if s.report_attempts > 0 else "PENDING"),
                "status_display": "GÖNDERİLDİ" if s.report_send else ("HATA" if s.report_attempts > 0 else "BEKLİYOR"),
                "attempt_count": s.report_attempts,
                "recipient": status.get("smtp_recipients", "soc-team@ziraatkatilim.local"),
            })

    context = {
        "stats": stats,
        "chart_distribution": chart_distribution,
        "hours_labels": hours_labels,
        "hourly_counts": hourly_counts,
        "latest_reports_list": latest_reports_list,
        "status": status,
        "time_range": time_range,
        "time_range_label": time_range_label,
        "active_page": "dashboard",
    }
    return render(request, "dashboard/index.html", context)


@login_required
def quick_search_api(request):
    """Real-time enterprise banking search API returning both sessions and audit events."""
    query = request.GET.get("q", "").strip()
    if not query or len(query) < 1:
        return JsonResponse({"sessions": [], "audit_events": [], "total_found": 0})

    now = timezone.now()

    # 1. Search Sessions
    sessions_qs = Session.objects.filter(
        Q(user_name__icontains=query) |
        Q(sicil__icontains=query) |
        Q(computer_name__icontains=query) |
        Q(session_id__icontains=query)
    ).order_by("-login_time")[:6]

    session_results = []
    for s in sessions_qs:
        dur = s.duration(now=now)
        session_results.append({
            "id": s.id,
            "user_name": s.user_name,
            "sicil": s.sicil,
            "computer_name": s.computer_name,
            "status": s.get_status_display(),
            "status_code": s.status,
            "duration": format_duration(dur),
            "login_time": s.login_time.strftime("%d.%m.%Y %H:%M:%S") if s.login_time else "",
            "is_over_limit": s.is_over_limit(12, now=now),
            "report_sent": s.report_send,
            "detail_url": f"/sessions/{s.id}/",
        })

    # 2. Search Audit Events
    audit_qs = AuditEventRecord.objects.filter(
        Q(user_name__icontains=query) |
        Q(sicil__icontains=query) |
        Q(computer_name__icontains=query) |
        Q(event_id__icontains=query) |
        Q(session_ref__icontains=query)
    ).order_by("-event_time")[:6]

    audit_results = []
    for a in audit_qs:
        audit_results.append({
            "id": a.id,
            "event_id": a.event_id,
            "event_type": a.event_type,
            "user_name": a.user_name,
            "sicil": a.sicil,
            "computer_name": a.computer_name,
            "event_time": a.event_time.strftime("%d.%m.%Y %H:%M:%S") if a.event_time else "",
            "session_ref": a.session_ref,
            "detail_url": f"/audit/{a.id}/",
        })

    total_found = len(session_results) + len(audit_results)

    return JsonResponse({
        "sessions": session_results,
        "audit_events": audit_results,
        "total_found": total_found,
    })


@login_required
def export_csv(request):
    """Direct CSV download for active and audit session events."""
    now = timezone.now()
    response = HttpResponse(content_type="text/csv; charset=utf-8")
    response["Content-Disposition"] = f'attachment; filename="ziraat_oturum_guvenlik_{now.strftime("%Y%m%d_%H%M%S")}.csv"'
    response.write("\ufeff")  # BOM for Excel compatibility

    writer = csv.writer(response)
    writer.writerow(["ID", "Kullanıcı Adı", "Sicil", "Cihaz Adı", "Giriş Zamanı", "Çıkış Zamanı", "Durum", "Rapor Gönderildi"])

    sessions = Session.objects.all().order_by("-login_time")[:5000]
    for s in sessions:
        writer.writerow([
            s.id,
            s.user_name,
            s.sicil,
            s.computer_name,
            s.login_time.strftime("%d.%m.%Y %H:%M:%S") if s.login_time else "",
            s.logout_time.strftime("%d.%m.%Y %H:%M:%S") if s.logout_time else "Aktif",
            s.get_status_display(),
            "Evet" if s.report_send else "Hayır",
        ])

    return response


@login_required
def live_stats_api(request):
    """Real-time JSON endpoint polled by the frontend for live Wazuh refresh."""
    status = get_system_status(use_cache=False)
    limit_hours = status.get("session_limit_hours", 12)
    now = timezone.now()

    active_count = Session.objects.active().count()
    over_limit_count = Session.objects.over_limit(limit_hours, now=now).count()
    reports_sent = ReportHistory.objects.filter(status=ReportHistory.SENT).count()
    reports_failed = ReportHistory.objects.filter(status=ReportHistory.FAILED).count()
    
    return JsonResponse({
        "timestamp": now.strftime("%Y-%m-%d %H:%M:%S"),
        "active_sessions": active_count,
        "over_limit": over_limit_count,
        "reports_sent": reports_sent,
        "reports_failed": reports_failed,
        "audit_connected": status.get("audit_connected", True),
        "worker_status": status.get("worker_status", "running"),
        "smtp_status": status.get("smtp_status", "connected"),
    })

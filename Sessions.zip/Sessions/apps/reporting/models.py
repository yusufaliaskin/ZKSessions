"""Report history (section 34-36) — an auditable record of every SMTP
report attempt made for a 12h+ session, independent from the read-only
audit system itself."""
from django.db import models

from apps.sessions.models import Session


class ReportHistory(models.Model):
    PENDING = "PENDING"
    SENDING = "SENDING"
    SENT = "SENT"
    FAILED = "FAILED"
    STATUS_CHOICES = [
        (PENDING, "Pending"),
        (SENDING, "Sending"),
        (SENT, "Sent"),
        (FAILED, "Failed"),
    ]

    session = models.ForeignKey(Session, related_name="reports", on_delete=models.CASCADE)
    recipient = models.CharField(max_length=500)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default=PENDING, db_index=True)
    attempt_count = models.PositiveIntegerField(default=0)
    error_message = models.TextField(blank=True, default="")

    sent_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["status", "created_at"]),
            models.Index(fields=["session", "status"]),
        ]

    def __str__(self):
        return f"Report[{self.session_id}] {self.status}"

"""
SMTP reporting engine (sections 32-37, 51, RULE 8/9/10).

Responsible for actually sending the "session exceeded N hours" alert and
recording the outcome in `ReportHistory`. All session/report state
mutations happen inside a single DB transaction with `select_for_update()`
so that two concurrent monitoring workers can never send a duplicate report
for the same session (RULE 8, section 71/72 — idempotency & concurrency).
"""
from __future__ import annotations

import logging

from django.conf import settings
from django.core.mail import EmailMultiAlternatives
from django.db import transaction
from django.template.loader import render_to_string
from django.utils import timezone

from apps.reporting.models import ReportHistory
from apps.sessions.models import Session, SessionTimelineEvent

logger = logging.getLogger("session_monitor")


class SMTPReportError(Exception):
    pass


class EmailReportService:
    def __init__(self, limit_hours: int | None = None):
        self.limit_hours = limit_hours or settings.SESSION_LIMIT_HOURS

    def _render_email(self, session: Session):
        deadline = session.login_time + timezone.timedelta(hours=self.limit_hours)
        report_time = timezone.now()
        context = {
            "session": session,
            "limit_hours": self.limit_hours,
            "login_time_local": timezone.localtime(session.login_time),
            "deadline_local": timezone.localtime(deadline),
            "report_time_local": timezone.localtime(report_time),
        }
        html_body = render_to_string("reporting/email/session_alert.html", context)
        text_body = (
            f"SESSION MONITORING ALERT\n\n"
            f"User: {session.user_name}\n"
            f"Sicil: {session.sicil}\n"
            f"Computer: {session.computer_name}\n"
            f"Login: {context['login_time_local']}\n"
            f"{self.limit_hours} Hour Limit: {context['deadline_local']}\n"
            f"Report Time: {context['report_time_local']}\n"
            f"Current Status: ACTIVE / OVER {self.limit_hours} HOURS\n"
        )
        return html_body, text_body

    def send_over_limit_report(self, session_id: int) -> bool:
        """Send (or skip, if already sent) the over-limit report for a
        session, keyed by primary key so a fresh row is loaded and locked.

        Returns True if a report is SENT (either just now, or already sent
        previously — both are "no further action needed" outcomes for the
        caller). Returns False only when sending genuinely failed and a
        retry is still warranted.
        """
        recipients = settings.SESSION_REPORT_RECIPIENTS
        max_attempts = settings.REPORT_MAX_ATTEMPTS

        with transaction.atomic():
            session = Session.objects.select_for_update().get(pk=session_id)

            # RULE 8 — never send a duplicate report once report_send=True.
            if session.report_send:
                return True

            if not recipients:
                logger.warning("REPORT_SKIPPED_NO_RECIPIENTS session_id=%s", session.session_id)
                return False

            if session.report_attempts >= max_attempts:
                # Avoid uncontrolled retry spam (section 36) — still flagged
                # as pending/failed for visibility, but we stop re-sending
                # every cycle once max_attempts is hit.
                return False

            report = self._get_or_create_open_report(session, recipients)
            report.status = ReportHistory.SENDING
            report.attempt_count += 1
            report.save(update_fields=["status", "attempt_count", "updated_at"])

            session.report_attempts += 1

            html_body, text_body = self._render_email(session)
            subject = (
                f"[SESSION MONITOR] {session.user_name} @ {session.computer_name} "
                f"exceeded {self.limit_hours}h"
            )

            try:
                message = EmailMultiAlternatives(
                    subject=subject,
                    body=text_body,
                    from_email=settings.DEFAULT_FROM_EMAIL,
                    to=recipients,
                )
                message.attach_alternative(html_body, "text/html")
                message.send(fail_silently=False)
            except Exception as exc:  # noqa: BLE001 — must never crash the cycle
                logger.error("REPORT_FAILED session_id=%s error=%s", session.session_id, exc)
                report.status = ReportHistory.FAILED
                report.error_message = str(exc)
                report.save(update_fields=["status", "error_message", "updated_at"])

                session.report_send = False
                session.report_time = None
                session.last_report_error = str(exc)
                session.save(update_fields=[
                    "report_send", "report_time", "report_attempts",
                    "last_report_error", "updated_at",
                ])
                return False

            now = timezone.now()
            report.status = ReportHistory.SENT
            report.sent_at = now
            report.error_message = ""
            report.save(update_fields=["status", "sent_at", "error_message", "updated_at"])

            session.report_send = True
            session.report_time = now
            session.last_report_error = ""
            session.refresh_status(self.limit_hours, now=now)
            session.save(update_fields=[
                "report_send", "report_time", "report_attempts",
                "last_report_error", "status", "updated_at",
            ])

            SessionTimelineEvent.objects.create(
                session=session,
                event_type=SessionTimelineEvent.REPORT_SENT,
                event_time=now,
                description=f"Report sent to {', '.join(recipients)}",
            )

            logger.info("REPORT_SENT session_id=%s recipients=%s", session.session_id, recipients)
            return True

    @staticmethod
    def _get_or_create_open_report(session: Session, recipients: list[str]) -> ReportHistory:
        report = (
            ReportHistory.objects.filter(
                session=session, status__in=[ReportHistory.PENDING, ReportHistory.FAILED]
            )
            .order_by("-created_at")
            .first()
        )
        if report:
            return report
        return ReportHistory.objects.create(
            session=session,
            recipient=", ".join(recipients),
            status=ReportHistory.PENDING,
        )

    @classmethod
    def send_test_email(cls, recipient: str | None = None) -> tuple[bool, str]:
        """Sends a diagnostic test email to verify SMTP configuration."""
        target_recipients = [recipient] if recipient else settings.SESSION_REPORT_RECIPIENTS
        if not target_recipients:
            return False, "No recipient specified and SMTP_TO is empty in .env"
        
        if not settings.EMAIL_HOST:
            return False, "SMTP_HOST is not configured in .env"

        now_str = timezone.now().strftime("%Y-%m-%d %H:%M:%S %Z")
        subject = f"[SESSION MONITOR] SMTP Test Email ({now_str})"
        body = (
            f"This is a test email sent from SESSION MONITOR to verify your SMTP configuration.\n\n"
            f"Timestamp: {now_str}\n"
            f"SMTP Host: {settings.EMAIL_HOST}:{settings.EMAIL_PORT}\n"
            f"TLS: {settings.EMAIL_USE_TLS} | SSL: {getattr(settings, 'EMAIL_USE_SSL', False)}\n"
            f"Sender: {settings.DEFAULT_FROM_EMAIL}\n\n"
            f"If you received this email, your SMTP settings are configured properly."
        )

        try:
            message = EmailMultiAlternatives(
                subject=subject,
                body=body,
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=target_recipients,
            )
            message.send(fail_silently=False)
            return True, f"Test email sent successfully to {', '.join(target_recipients)}"
        except Exception as exc:
            logger.error("SMTP_TEST_FAILED: %s", exc)
            return False, f"SMTP Error: {exc}"

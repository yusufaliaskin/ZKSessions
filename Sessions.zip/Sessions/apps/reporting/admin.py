from django.contrib import admin

from .models import ReportHistory


@admin.register(ReportHistory)
class ReportHistoryAdmin(admin.ModelAdmin):
    list_display = ("session", "status", "attempt_count", "sent_at", "recipient")
    list_filter = ("status",)
    search_fields = ("session__user_name", "session__computer_name", "recipient")

    def has_add_permission(self, request):
        return False

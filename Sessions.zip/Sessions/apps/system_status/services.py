"""Aggregates the health of every subsystem for the top bar / System
Status page / dashboard summary cards (sections 40-41, 56, 67)."""
from __future__ import annotations

from django.conf import settings
from django.core.cache import cache
from django.db import connection
from django.utils import timezone

from apps.audit.models import AuditCheckpoint
from apps.monitoring.models import MonitoringCycleRun

CACHE_KEY = "system_status_summary"


def get_system_status(use_cache: bool = True) -> dict:
    if use_cache:
        cached = cache.get(CACHE_KEY)
        if cached:
            return cached

    checkpoint = AuditCheckpoint.objects.filter(source_name="default").first()
    audit_connected = bool(checkpoint and checkpoint.is_connected)

    last_run = MonitoringCycleRun.objects.order_by("-started_at").first()

    smtp_configured = bool(settings.EMAIL_HOST and settings.SESSION_REPORT_RECIPIENTS)
    smtp_recent_failure = False
    if last_run and last_run.reports_failed and not last_run.reports_sent:
        smtp_recent_failure = True

    worker_status = "stopped"
    if last_run:
        expected_next = last_run.started_at + timezone.timedelta(seconds=settings.MONITOR_INTERVAL * 2)
        worker_status = "running" if timezone.now() < expected_next else "stalled"

    db_connected = True
    try:
        connection.ensure_connection()
    except Exception:  # noqa: BLE001
        db_connected = False

    next_scan = None
    if last_run and last_run.finished_at:
        next_scan = last_run.finished_at + timezone.timedelta(seconds=settings.MONITOR_INTERVAL)

    result = {
        "audit_connected": audit_connected,
        "audit_error": checkpoint.last_error if checkpoint else "",
        "smtp_configured": smtp_configured,
        "smtp_status": "failed" if smtp_recent_failure else ("connected" if smtp_configured else "not_configured"),
        "worker_status": worker_status,
        "db_connected": db_connected,
        "last_scan": last_run.finished_at if last_run else None,
        "next_scan": next_scan,
        "last_run": last_run,
        "monitor_interval": settings.MONITOR_INTERVAL,
        "session_limit_hours": settings.SESSION_LIMIT_HOURS,
    }
    cache.set(CACHE_KEY, result, settings.DASHBOARD_CACHE_SECONDS)
    return result

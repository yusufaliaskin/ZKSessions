"""Custom logging handler that mirrors application log records into the
database so they're browsable from the dashboard (section 57)."""
import logging


class DatabaseLogHandler(logging.Handler):
    def emit(self, record):
        try:
            from django.db import connections

            from .models import SystemLogEntry

            # Avoid writing during migrations / before tables exist.
            if "default" not in connections:
                return

            SystemLogEntry.objects.create(
                level=record.levelname if record.levelname in dict(SystemLogEntry.LEVEL_CHOICES) else "INFO",
                logger_name=record.name,
                message=self.format(record) if self.formatter else record.getMessage(),
            )
        except Exception:  # noqa: BLE001 — logging must never raise
            pass

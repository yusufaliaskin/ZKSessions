from .services import get_system_status


def system_status_context(request):
    """Feeds the top status bar (section 40) on every authenticated page."""
    if not request.path.startswith("/accounts/"):
        try:
            return {"topbar_status": get_system_status()}
        except Exception:  # noqa: BLE001 — never break page rendering
            return {"topbar_status": None}
    return {"topbar_status": None}

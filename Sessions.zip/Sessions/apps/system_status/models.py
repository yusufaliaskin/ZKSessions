"""Application log storage backing the System > Logs dashboard page
(section 57, 99) — paginated, filterable, never loaded in full into the
browser."""
from django.db import models


class SystemLogEntry(models.Model):
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"
    LEVEL_CHOICES = [
        (DEBUG, "Debug"), (INFO, "Info"), (WARNING, "Warning"),
        (ERROR, "Error"), (CRITICAL, "Critical"),
    ]

    level = models.CharField(max_length=10, choices=LEVEL_CHOICES, db_index=True)
    logger_name = models.CharField(max_length=100, blank=True, default="")
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [models.Index(fields=["level", "created_at"])]

    def __str__(self):
        return f"[{self.level}] {self.message[:80]}"

from django.contrib import admin

from .models import SystemLogEntry


@admin.register(SystemLogEntry)
class SystemLogEntryAdmin(admin.ModelAdmin):
    list_display = ("created_at", "level", "logger_name", "message")
    list_filter = ("level",)
    search_fields = ("message", "logger_name")

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

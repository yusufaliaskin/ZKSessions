from django.apps import AppConfig


class SystemStatusConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.system_status"
    label = "system_status"
    verbose_name = "System Status"

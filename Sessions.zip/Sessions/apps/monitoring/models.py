"""Observability record for each monitoring cycle run (section 99, 23-25).

Backs the System Status page's "Last Successful Scan / Next Scan" and the
top bar's scan timers, without needing to parse the free-form log file.
"""
from django.db import models


class MonitoringCycleRun(models.Model):
    RUNNING = "RUNNING"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    STATUS_CHOICES = [(RUNNING, "Running"), (SUCCESS, "Success"), (FAILED, "Failed")]

    started_at = models.DateTimeField(db_index=True)
    finished_at = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default=RUNNING)
    triggered_by = models.CharField(max_length=50, default="scheduler")

    audit_connected = models.BooleanField(default=False)
    events_fetched = models.PositiveIntegerField(default=0)
    logins_detected = models.PositiveIntegerField(default=0)
    logouts_detected = models.PositiveIntegerField(default=0)
    over_limit_found = models.PositiveIntegerField(default=0)
    reports_sent = models.PositiveIntegerField(default=0)
    reports_failed = models.PositiveIntegerField(default=0)
    errors_count = models.PositiveIntegerField(default=0)
    error_detail = models.TextField(blank=True, default="")

    class Meta:
        ordering = ["-started_at"]

    def __str__(self):
        return f"Cycle@{self.started_at} [{self.status}]"

    @property
    def duration_seconds(self):
        if not self.finished_at:
            return None
        return (self.finished_at - self.started_at).total_seconds()

"""Celery tasks — background worker entry points (section 22-25).

The dashboard NEVER triggers monitoring directly; it only reads the
results the worker already wrote to the database (RULE 13).
"""
import logging

from celery import shared_task

logger = logging.getLogger("session_monitor")


@shared_task(bind=True, max_retries=0)
def run_monitoring_cycle(self, triggered_by: str = "celery-beat"):
    from apps.monitoring.services.session_monitor import SessionMonitorEngine

    engine = SessionMonitorEngine()
    run = engine.run_cycle(triggered_by=triggered_by)
    return {
        "status": run.status,
        "logins_detected": run.logins_detected,
        "logouts_detected": run.logouts_detected,
        "reports_sent": run.reports_sent,
        "reports_failed": run.reports_failed,
    }

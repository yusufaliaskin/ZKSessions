from django.contrib import admin

from .models import MonitoringCycleRun


@admin.register(MonitoringCycleRun)
class MonitoringCycleRunAdmin(admin.ModelAdmin):
    list_display = (
        "started_at", "status", "triggered_by", "audit_connected",
        "logins_detected", "logouts_detected", "reports_sent", "reports_failed",
    )
    list_filter = ("status", "triggered_by")

    def has_add_permission(self, request):
        return False

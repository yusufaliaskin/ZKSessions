"""
Lightweight, dependency-free background scheduler (section 22 alternative).

For small deployments without Celery/Redis, this command performs the
mandatory INITIAL SCAN immediately on startup (section 25), then keeps
running monitoring cycles forever at MONITOR_INTERVAL seconds — entirely
independent of whether anyone has the dashboard open (RULE 13).

Usage:
    python manage.py run_scheduler
"""
import signal
import time

from django.conf import settings
from django.core.management.base import BaseCommand

from apps.monitoring.services.session_monitor import SessionMonitorEngine


class Command(BaseCommand):
    help = "Run the SESSION MONITOR background scheduler (Celery-free fallback)."

    def add_arguments(self, parser):
        parser.add_argument("--interval", type=int, default=None, help="Override MONITOR_INTERVAL (seconds)")
        parser.add_argument("--once", action="store_true", help="Run a single cycle and exit")

    def handle(self, *args, **options):
        override_interval = options["interval"]
        engine = SessionMonitorEngine()

        self._stop = False
        signal.signal(signal.SIGINT, self._handle_stop)
        signal.signal(signal.SIGTERM, self._handle_stop)

        self.stdout.write(self.style.SUCCESS("Running initial scan..."))
        engine.run_cycle(triggered_by="initial-scan")

        if options["once"]:
            return

        self.stdout.write(self.style.SUCCESS("Scheduler running. Ctrl+C to stop."))
        while not self._stop:
            interval = override_interval or self._current_interval()
            for _ in range(interval):
                if self._stop:
                    break
                time.sleep(1)
            if self._stop:
                break
            engine = SessionMonitorEngine()  # re-resolve limit hours each cycle
            engine.run_cycle(triggered_by="scheduler")

    @staticmethod
    def _current_interval() -> int:
        try:
            from apps.settings_panel.models import SystemSettings

            return SystemSettings.load().monitor_interval_seconds
        except Exception:  # noqa: BLE001
            return settings.MONITOR_INTERVAL

    def _handle_stop(self, signum, frame):
        self._stop = True
        self.stdout.write(self.style.WARNING("Stopping scheduler..."))

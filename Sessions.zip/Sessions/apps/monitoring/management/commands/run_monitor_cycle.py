from django.core.management.base import BaseCommand

from apps.monitoring.services.session_monitor import SessionMonitorEngine


class Command(BaseCommand):
    help = "Run a single SESSION MONITOR monitoring cycle immediately (section 25 — initial scan)."

    def handle(self, *args, **options):
        engine = SessionMonitorEngine()
        run = engine.run_cycle(triggered_by="management-command")
        self.stdout.write(
            self.style.SUCCESS(
                f"Cycle finished: status={run.status} logins={run.logins_detected} "
                f"logouts={run.logouts_detected} over_limit={run.over_limit_found} "
                f"reports_sent={run.reports_sent} reports_failed={run.reports_failed}"
            )
        )

from rest_framework import serializers

from apps.audit.models import AuditEventRecord
from apps.reporting.models import ReportHistory
from apps.sessions.models import Session, SessionTimelineEvent


class SessionTimelineEventSerializer(serializers.ModelSerializer):
    class Meta:
        model = SessionTimelineEvent
        fields = ["event_type", "event_time", "description"]


class SessionSerializer(serializers.ModelSerializer):
    duration_seconds = serializers.SerializerMethodField()

    class Meta:
        model = Session
        fields = [
            "id", "session_id", "user_name", "sicil", "computer_name",
            "login_time", "logout_time", "report_time", "report_send",
            "report_attempts", "last_report_error", "status",
            "duration_seconds", "created_at", "updated_at",
        ]

    def get_duration_seconds(self, obj):
        return obj.duration().total_seconds()


class SessionDetailSerializer(SessionSerializer):
    timeline = SessionTimelineEventSerializer(many=True, read_only=True)

    class Meta(SessionSerializer.Meta):
        fields = SessionSerializer.Meta.fields + ["timeline"]


class ReportHistorySerializer(serializers.ModelSerializer):
    user_name = serializers.CharField(source="session.user_name", read_only=True)
    computer_name = serializers.CharField(source="session.computer_name", read_only=True)

    class Meta:
        model = ReportHistory
        fields = [
            "id", "session", "user_name", "computer_name", "recipient",
            "status", "attempt_count", "error_message", "sent_at", "created_at",
        ]


class AuditEventRecordSerializer(serializers.ModelSerializer):
    class Meta:
        model = AuditEventRecord
        fields = [
            "id", "event_id", "event_type", "session_ref", "user_name",
            "sicil", "computer_name", "event_time", "raw_payload", "received_at",
        ]
        read_only_fields = fields  # RULE 1/2 — audit data is never writable via API

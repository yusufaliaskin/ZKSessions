"""
REST API (section 66-67).

Everything here is READ-ONLY with respect to Session/Audit/Report data —
mutations only ever happen inside the monitoring engine
(apps.monitoring.services.session_monitor). This mirrors and enforces
RULE 1/2 (audit read-only) and RULE 13 (dashboard never drives monitoring)
at the API boundary as well.
"""
from django.utils import timezone
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.audit.models import AuditEventRecord
from apps.reporting.models import ReportHistory
from apps.sessions.models import Session
from apps.system_status.services import get_system_status

from .filters import ReportHistoryFilter, SessionFilter
from .serializers import (
    AuditEventRecordSerializer,
    ReportHistorySerializer,
    SessionDetailSerializer,
    SessionSerializer,
)


class SessionViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Session.objects.all()
    serializer_class = SessionSerializer
    permission_classes = [IsAuthenticated]
    filterset_class = SessionFilter
    search_fields = ["user_name", "sicil", "computer_name", "session_id"]
    ordering_fields = ["login_time", "logout_time", "status", "report_time"]

    def get_serializer_class(self):
        if self.action == "retrieve":
            return SessionDetailSerializer
        return SessionSerializer

    @action(detail=False, methods=["get"], url_path="over-12h")
    def over_12h(self, request):
        status_ = get_system_status()
        qs = Session.objects.over_limit(status_["session_limit_hours"])
        page = self.paginate_queryset(qs)
        serializer = self.get_serializer(page or qs, many=True)
        if page is not None:
            return self.get_paginated_response(serializer.data)
        return Response(serializer.data)


class ReportHistoryViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = ReportHistory.objects.select_related("session").all()
    serializer_class = ReportHistorySerializer
    permission_classes = [IsAuthenticated]
    filterset_class = ReportHistoryFilter
    search_fields = ["session__user_name", "session__computer_name", "recipient"]
    ordering_fields = ["created_at", "sent_at", "status"]


class AuditEventViewSet(viewsets.ReadOnlyModelViewSet):
    """RULE 1/2 — strictly read-only, no create/update/delete actions
    exist on this ViewSet by design (ReadOnlyModelViewSet)."""

    queryset = AuditEventRecord.objects.all()
    serializer_class = AuditEventRecordSerializer
    permission_classes = [IsAuthenticated]
    filterset_fields = ["event_type", "user_name", "computer_name"]
    search_fields = ["user_name", "sicil", "computer_name", "session_ref", "event_id"]
    ordering_fields = ["event_time"]


class DashboardSummaryView(APIView):
    """Optimized single-call summary for the dashboard (section 67)."""

    permission_classes = [IsAuthenticated]

    def get(self, request):
        status_ = get_system_status()
        now = timezone.now()
        limit_hours = status_["session_limit_hours"]

        data = {
            "active_sessions": Session.objects.active().count(),
            "over_12_hours": Session.objects.over_limit(limit_hours, now=now).count(),
            "reports_sent": ReportHistory.objects.filter(status=ReportHistory.SENT).count(),
            "reports_pending": Session.objects.pending_report(limit_hours, now=now).count(),
            "reports_failed": ReportHistory.objects.filter(status=ReportHistory.FAILED).count(),
            "audit_status": "connected" if status_["audit_connected"] else "disconnected",
            "smtp_status": status_["smtp_status"],
            "worker_status": status_["worker_status"],
        }
        return Response(data)


class SystemStatusView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        status_ = get_system_status()

        def fmt(dt):
            return timezone.localtime(dt).strftime("%H:%M:%S") if dt else None

        return Response({
            "audit_connected": status_["audit_connected"],
            "smtp_status": status_["smtp_status"],
            "worker_status": status_["worker_status"],
            "db_connected": status_["db_connected"],
            "last_scan": fmt(status_["last_scan"]),
            "next_scan": fmt(status_["next_scan"]),
            "monitor_interval": status_["monitor_interval"],
            "session_limit_hours": status_["session_limit_hours"],
        })

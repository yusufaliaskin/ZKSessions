import django_filters

from apps.reporting.models import ReportHistory
from apps.sessions.models import Session


class SessionFilter(django_filters.FilterSet):
    status = django_filters.CharFilter(field_name="status")
    report_send = django_filters.BooleanFilter(field_name="report_send")
    active = django_filters.BooleanFilter(method="filter_active")

    class Meta:
        model = Session
        fields = ["status", "report_send", "user_name", "computer_name"]

    def filter_active(self, queryset, name, value):
        return queryset.filter(logout_time__isnull=value)


class ReportHistoryFilter(django_filters.FilterSet):
    class Meta:
        model = ReportHistory
        fields = ["status"]

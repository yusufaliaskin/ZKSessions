from django.urls import include, path
from rest_framework.routers import DefaultRouter

from . import views

router = DefaultRouter()
router.register(r"sessions", views.SessionViewSet, basename="api-session")
router.register(r"reports", views.ReportHistoryViewSet, basename="api-report")
router.register(r"audit/events", views.AuditEventViewSet, basename="api-audit-event")

urlpatterns = [
    path("dashboard/", views.DashboardSummaryView.as_view(), name="api-dashboard"),
    path("system/status/", views.SystemStatusView.as_view(), name="api-system-status"),
    path("", include(router.urls)),
]

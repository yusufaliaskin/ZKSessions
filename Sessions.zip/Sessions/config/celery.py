"""
Celery application for SESSION MONITOR.

Background monitoring MUST NOT depend on any browser request. This module
wires Celery + Celery Beat so the monitoring cycle keeps running as long as
the worker/beat processes are alive, independent of the Django dashboard.
"""
import os

from celery import Celery
from celery.schedules import schedule

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings.development")

app = Celery("session_monitor")
app.config_from_object("django.conf:settings", namespace="CELERY")


@app.on_after_configure.connect
def setup_periodic_tasks(sender, **kwargs):
    """Register the recurring monitoring cycle.

    The interval is read from Django settings (MONITOR_INTERVAL, seconds)
    so it can be controlled entirely from the environment / settings panel.
    """
    from django.conf import settings

    interval = getattr(settings, "MONITOR_INTERVAL", 3600)
    sender.add_periodic_task(
        schedule(run_every=interval),
        _run_monitoring_cycle_signature(),
        name="session-monitoring-cycle",
    )


def _run_monitoring_cycle_signature():
    from apps.monitoring.tasks import run_monitoring_cycle

    return run_monitoring_cycle.s()


app.autodiscover_tasks()

// Ziraat Katılım — Oturum ve Güvenlik İzleme Portalı
// $50,000 Enterprise Grade Banking SOC Engine & Universal Sorter

document.addEventListener("DOMContentLoaded", function () {
  var topbarToggleBtn = document.getElementById("sidebarToggleBtn");
  var globalPortal = document.getElementById("globalMiniFlyoutPortal");
  var searchInput = document.getElementById("topbarGlobalSearch");
  var searchDropdown = document.getElementById("globalSearchDropdown");

  // 1. Initialize Sidebar State from LocalStorage (Single Source of Truth)
  try {
    var savedState = localStorage.getItem("zk_sidebar_collapsed");
    if (savedState === "true") {
      document.body.classList.add("sidebar-collapsed");
      document.documentElement.classList.add("sidebar-collapsed");
    } else if (savedState === "false") {
      document.body.classList.remove("sidebar-collapsed");
      document.documentElement.classList.remove("sidebar-collapsed");
    }
  } catch (e) {}

  // 2. Sidebar Collapse/Expand Toggle with Persistence
  function toggleSidebarRail() {
    var isCollapsed = document.body.classList.toggle("sidebar-collapsed");
    document.documentElement.classList.toggle("sidebar-collapsed", isCollapsed);
    if (globalPortal) hideGlobalPortal();
    try {
      localStorage.setItem("zk_sidebar_collapsed", isCollapsed ? "true" : "false");
    } catch (e) {}
  }

  if (topbarToggleBtn) topbarToggleBtn.addEventListener("click", toggleSidebarRail);

  // 3. Global Floating Popover Engine for Mini-Rail Mode (14px Offset & Zero-Clipping)
  var portalHideTimeout = null;

  function showGlobalPortal(triggerEl) {
    if (!document.body.classList.contains("sidebar-collapsed") || !globalPortal) return;
    if (portalHideTimeout) {
      clearTimeout(portalHideTimeout);
      portalHideTimeout = null;
    }

    var rect = triggerEl.getBoundingClientRect();
    var html = "";

    if (triggerEl.hasAttribute("data-portal-title")) {
      var title = triggerEl.getAttribute("data-portal-title");
      var url = triggerEl.getAttribute("data-portal-url");
      var isActive = triggerEl.getAttribute("data-portal-active") === "true";
      html = '<a href="' + url + '" class="global-flyout-item ' + (isActive ? "active" : "") + '">' + title + '</a>';
    } else if (triggerEl.hasAttribute("data-portal-group")) {
      var groupTitle = triggerEl.getAttribute("data-portal-group");
      var subItems = triggerEl.querySelectorAll(".tree-sub-item");
      html = '<div class="global-flyout-title">' + groupTitle + '</div>';
      subItems.forEach(function (sub) {
        var subHref = sub.getAttribute("href");
        var subText = sub.textContent.trim();
        var subActive = sub.classList.contains("active") ? "active" : "";
        html += '<a href="' + subHref + '" class="global-flyout-item ' + subActive + '">' + subText + '</a>';
      });
    }

    if (!html) return;

    globalPortal.innerHTML = html;
    globalPortal.style.left = (rect.right + 14) + "px";
    globalPortal.style.top = rect.top + "px";
    globalPortal.classList.add("visible");
  }

  function scheduleHideGlobalPortal() {
    if (portalHideTimeout) clearTimeout(portalHideTimeout);
    portalHideTimeout = setTimeout(function () {
      hideGlobalPortal();
    }, 140);
  }

  function hideGlobalPortal() {
    if (globalPortal) {
      globalPortal.classList.remove("visible");
      globalPortal.innerHTML = "";
    }
  }

  if (globalPortal) {
    globalPortal.addEventListener("mouseenter", function () {
      if (portalHideTimeout) clearTimeout(portalHideTimeout);
    });
    globalPortal.addEventListener("mouseleave", scheduleHideGlobalPortal);
  }

  var portalTriggers = document.querySelectorAll("[data-portal-title], [data-portal-group]");
  portalTriggers.forEach(function (el) {
    el.addEventListener("mouseenter", function () {
      showGlobalPortal(el);
    });
    el.addEventListener("mouseleave", scheduleHideGlobalPortal);
  });

  // 4. Animated Tree Accordion Click Handler (in expanded mode)
  document.addEventListener("click", function (e) {
    if (document.body.classList.contains("sidebar-collapsed")) return;

    var header = e.target.closest(".tree-group-header");
    if (!header) return;

    var group = header.closest(".tree-group");
    if (!group) return;

    var isOpen = group.classList.contains("open");

    document.querySelectorAll(".tree-group").forEach(function (g) {
      if (g !== group) g.classList.remove("open");
    });

    if (isOpen) {
      group.classList.remove("open");
    } else {
      group.classList.add("open");
    }
  });

  // 5. Universal Interactive Table Sorter (A-Z, Numbers, Dates)
  initUniversalTableSorter();

  // 6. Enterprise Banking Autocomplete Dropdown Search Engine (Pure Dropdown — No Table Hiding!)
  var searchDebounceTimer = null;

  if (searchInput && searchDropdown) {
    searchInput.addEventListener("input", function (e) {
      var query = e.target.value.trim();

      if (searchDebounceTimer) clearTimeout(searchDebounceTimer);

      if (query.length < 1) {
        searchDropdown.style.display = "none";
        searchDropdown.innerHTML = "";
        return;
      }

      searchDebounceTimer = setTimeout(function () {
        fetch("/api/quick-search/?q=" + encodeURIComponent(query))
          .then(function (res) { return res.json(); })
          .then(function (data) {
            var sessions = data.sessions || [];
            var auditEvents = data.audit_events || [];

            if (sessions.length === 0 && auditEvents.length === 0) {
              searchDropdown.innerHTML = '<div class="search-empty-note">"' + query + '" ile eşleşen kullanıcı, oturum veya audit kaydı bulunamadı.</div>';
              searchDropdown.style.display = "block";
              return;
            }

            var html = '';

            // Section 1: Sessions
            if (sessions.length > 0) {
              html += '<div class="search-section-label">Aktif &amp; Son Oturumlar (' + sessions.length + ')</div>';
              sessions.forEach(function (s) {
                var badgeCls = s.status_code === 'LOGGED_OUT' ? 'gray' : (s.status_code === 'ACTIVE' ? 'blue' : 'red');
                html += '<div class="search-item-row" onclick="openSessionDrawer(' + s.id + '); document.getElementById(\'globalSearchDropdown\').style.display=\'none\';">' +
                  '<div class="search-avatar-box">' + s.user_name.charAt(0).toUpperCase() + '</div>' +
                  '<div class="search-item-main">' +
                    '<div class="search-user-title"><b>' + s.user_name + '</b> <span class="search-user-sicil">Sicil: ' + s.sicil + '</span></div>' +
                    '<div class="search-device-line"><span class="agent-link">' + s.computer_name + '</span> &bull; Giriş: ' + s.login_time + ' &bull; Süre: <b>' + s.duration + '</b></div>' +
                  '</div>' +
                  '<div class="search-item-end">' +
                    '<span class="badge ' + badgeCls + '">' + s.status + '</span>' +
                    '<span class="search-arrow-icon">&#x203A;</span>' +
                  '</div>' +
                '</div>';
              });
            }

            // Section 2: Audit Logs
            if (auditEvents.length > 0) {
              html += '<div class="search-section-label" style="margin-top:6px;">Audit Güvenlik Günlükleri (' + auditEvents.length + ')</div>';
              auditEvents.forEach(function (a) {
                var isLogin = a.event_type === 'LOGIN';
                html += '<a href="' + a.detail_url + '" class="search-item-row audit-row" onclick="document.getElementById(\'globalSearchDropdown\').style.display=\'none\';">' +
                  '<div class="search-avatar-box audit ' + (isLogin ? 'login' : 'logout') + '">' + (isLogin ? 'IN' : 'OUT') + '</div>' +
                  '<div class="search-item-main">' +
                    '<div class="search-user-title"><b>' + a.user_name + '</b> <span class="search-user-sicil">ID: ' + a.event_id.substring(0, 14) + '...</span></div>' +
                    '<div class="search-device-line"><span class="agent-link">' + a.computer_name + '</span> &bull; Zaman: ' + a.event_time + '</div>' +
                  '</div>' +
                  '<div class="search-item-end">' +
                    '<span class="badge ' + (isLogin ? 'blue' : 'gray') + '">' + a.event_type + '</span>' +
                    '<span class="search-arrow-icon">&#x203A;</span>' +
                  '</div>' +
                '</a>';
              });
            }

            html += '<a href="/sessions/active/?q=' + encodeURIComponent(query) + '" class="search-dropdown-footer">Tüm Arama Sonuçlarını İncele &rarr;</a>';
            searchDropdown.innerHTML = html;
            searchDropdown.style.display = "block";
          })
          .catch(function () {
            searchDropdown.style.display = "none";
          });
      }, 150);
    });

    // Close search dropdown on click outside
    document.addEventListener("click", function (e) {
      if (!e.target.closest(".topbar-center-zone")) {
        searchDropdown.style.display = "none";
      }
    });
  }

  // 7. Drawer Overlay and Escape Key
  var overlay = document.getElementById("drawer-overlay");
  if (overlay) {
    overlay.addEventListener("click", closeDrawer);
  }
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") {
      closeDrawer();
      if (searchDropdown) searchDropdown.style.display = "none";
    }
  });

  // 8. Background Live Polling (every 15s)
  setInterval(pollLiveStats, 15000);
});

// Universal Table Sorter Engine
function initUniversalTableSorter() {
  var tables = document.querySelectorAll(".data-table, .wazuh-siem-table");
  tables.forEach(function (table) {
    var headers = table.querySelectorAll("thead th");
    headers.forEach(function (th, colIndex) {
      var text = th.textContent.trim();
      if (!text || th.classList.contains("no-sort") || th.classList.contains("chevron-col")) return;

      th.classList.add("sortable-th");

      if (!th.querySelector(".sort-indicator-icon")) {
        var span = document.createElement("span");
        span.className = "sort-indicator-icon";
        span.innerHTML = "&#8645;";
        th.appendChild(span);
      }

      th.addEventListener("click", function (e) {
        if (e.target.tagName === "A" || e.target.tagName === "BUTTON") return;

        var tbody = table.querySelector("tbody");
        if (!tbody) return;

        var rows = Array.from(tbody.querySelectorAll("tr"));
        if (rows.length <= 1) return;

        var currentDir = th.getAttribute("data-sort-dir") || "none";
        var newDir = currentDir === "asc" ? "desc" : "asc";

        headers.forEach(function (otherTh) {
          otherTh.removeAttribute("data-sort-dir");
          otherTh.classList.remove("sort-asc", "sort-desc");
          var icon = otherTh.querySelector(".sort-indicator-icon");
          if (icon) icon.innerHTML = "&#8645;";
        });

        th.setAttribute("data-sort-dir", newDir);
        th.classList.add(newDir === "asc" ? "sort-asc" : "sort-desc");
        var icon = th.querySelector(".sort-indicator-icon");
        if (icon) icon.innerHTML = newDir === "asc" ? "&#9650;" : "&#9660;";

        rows.sort(function (rowA, rowB) {
          var cellA = rowA.children[colIndex];
          var cellB = rowB.children[colIndex];
          if (!cellA || !cellB) return 0;

          var valA = cellA.textContent.trim();
          var valB = cellB.textContent.trim();

          var dateA = parseDateTimeString(valA);
          var dateB = parseDateTimeString(valB);
          if (dateA !== null && dateB !== null) {
            return newDir === "asc" ? dateA - dateB : dateB - dateA;
          }

          var numA = parseNumberString(valA);
          var numB = parseNumberString(valB);
          if (numA !== null && numB !== null) {
            return newDir === "asc" ? numA - numB : numB - numA;
          }

          var cmp = valA.localeCompare(valB, "tr", { numeric: true, sensitivity: "base" });
          return newDir === "asc" ? cmp : -cmp;
        });

        rows.forEach(function (row) {
          tbody.appendChild(row);
        });
      });
    });
  });
}

function parseDateTimeString(str) {
  var match = str.match(/^(\d{1,2})\.(\d{1,2})\.(\d{4})(?:\s+(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?$/);
  if (match) {
    var d = parseInt(match[1], 10);
    var m = parseInt(match[2], 10) - 1;
    var y = parseInt(match[3], 10);
    var hh = match[4] ? parseInt(match[4], 10) : 0;
    var mm = match[5] ? parseInt(match[5], 10) : 0;
    var ss = match[6] ? parseInt(match[6], 10) : 0;
    return new Date(y, m, d, hh, mm, ss).getTime();
  }
  return null;
}

function parseNumberString(str) {
  var clean = str.replace(/,/g, "").replace(/[^\d.-]/g, "");
  if (!clean || isNaN(clean)) return null;
  return parseFloat(clean);
}

// Live Telemetry Refresh
function triggerLiveRefresh() {
  var spinIcon = document.getElementById("refreshSpinIcon");
  if (spinIcon) {
    spinIcon.style.transition = "transform 0.6s ease";
    spinIcon.style.transform = "rotate(360deg)";
    setTimeout(function () {
      spinIcon.style.transition = "none";
      spinIcon.style.transform = "rotate(0deg)";
    }, 600);
  }
  pollLiveStats(true);
}

function pollLiveStats(isManual) {
  fetch("/api/live-stats/", { headers: { "X-Requested-With": "XMLHttpRequest" } })
    .then(function (r) { return r.ok ? r.json() : null; })
    .then(function (data) {
      if (!data) return;

      var kpiActive = document.getElementById("kpiActive");
      var kpiOver = document.getElementById("kpiOverLimit");
      var kpiSent = document.getElementById("kpiSent");
      var kpiTotal = document.getElementById("kpiTotal");

      if (kpiActive && data.active_sessions !== undefined) kpiActive.textContent = data.active_sessions;
      if (kpiOver && data.over_limit !== undefined) kpiOver.textContent = data.over_limit;
      if (kpiSent && data.reports_sent !== undefined) kpiSent.textContent = data.reports_sent;
      if (kpiTotal && data.active_sessions !== undefined) kpiTotal.textContent = data.active_sessions;
    })
    .catch(function () {});
}

function openSessionDrawer(sessionId) {
  openDrawer("/sessions/" + sessionId + "/");
}

function openDrawer(url) {
  var drawer = document.getElementById("drawer");
  var overlay = document.getElementById("drawer-overlay");
  var body = document.getElementById("drawer-body-content");
  if (!drawer || !body) return;

  body.innerHTML = '<div class="empty-state" style="padding:40px 20px;">Oturum güvenlik telemetrisi yükleniyor...</div>';
  overlay.classList.add("open");
  drawer.classList.add("open");

  fetch(url, { headers: { "X-Requested-With": "XMLHttpRequest" } })
    .then(function (r) { return r.text(); })
    .then(function (html) { body.innerHTML = html; })
    .catch(function () {
      body.innerHTML = '<div class="empty-state">Oturum detayları yüklenemedi.</div>';
    });
}

function closeDrawer() {
  var drawer = document.getElementById("drawer");
  var overlay = document.getElementById("drawer-overlay");
  if (drawer) drawer.classList.remove("open");
  if (overlay) overlay.classList.remove("open");
}
